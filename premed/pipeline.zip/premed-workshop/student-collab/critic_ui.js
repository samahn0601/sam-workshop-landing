const packet=__PACKET__;
const $=s=>document.querySelector(s);
const form=$('#cf');
$('#request').textContent=packet.request;
$('#say-text').textContent=packet.say_next;
$('#tool').value=packet.critic_tool;
function status(t){$('#critic-status').textContent=t}
function record(){return {schema:'student-critic-response/1',project:packet.project,packet_id:packet.packet_id,request_sha256:packet.request_sha256,tool:$('#tool').value,model_label:$('#model').value.trim(),response:$('#response').value,sent_request:$('#sent').value,reconstructed:$('#reconstructed').checked,attested_by_human:$('#human').checked,source:'local_critic_form',created_at:new Date().toISOString()}}
function warnRoute(){const tool=$('#tool').value;if(packet.route==='multi'&&tool===packet.writer_tool)return '주의: 2개 구독 경로는 다른 제공자의 비평이 필요합니다. 같은 제공자로 받았다면 주 작업 대화에서 단일 경로로 바꾼 사유를 기록해야 합니다.';if(packet.route==='single'&&tool!==packet.writer_tool)return '참고: 1개 구독 경로인데 다른 제공자를 골랐습니다. 실제로 그렇게 했다면 주 작업 대화에 알려 주세요.';return ''}
$('#tool').onchange=()=>status(warnRoute());
$('#copy-request').onclick=async()=>{try{await navigator.clipboard.writeText(packet.request);status('요청을 복사했습니다. 새 대화에 붙여 넣으세요.')}catch{const el=$('#request-fallback');el.hidden=false;$('#request-fallback-label').hidden=false;el.value=packet.request;el.focus();el.select();status('자동 복사가 안 됩니다. 아래 칸의 요청을 직접 복사하세요.')}};
$('#copy-say').onclick=async()=>{try{await navigator.clipboard.writeText(packet.say_next);status('문장을 복사했습니다. 응답을 저장한 뒤 주 작업 대화에 붙여 넣으세요.')}catch{status('자동 복사가 안 됩니다. 위 문장을 직접 입력해도 됩니다.')}};
form.onsubmit=e=>{e.preventDefault();if(!form.reportValidity())return;const name=packet.project+'-H4-critic.json';const u=URL.createObjectURL(new Blob([JSON.stringify(record(),null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);status(('저장을 요청했습니다. 다운로드 폴더의 '+name+' 파일을 확인하고 주 작업 대화에 위 문장을 붙여 넣으세요. '+warnRoute()).trim())};
$('#copy-critic').onclick=async()=>{if(!form.reportValidity())return;const value='다음은 내가 새 비평 대화에서 받아 온 실제 응답 기록이야. 내용을 바꾸지 말고 JSON 파일로 저장한 뒤 critic-import --file로 가져와줘.\n\n'+JSON.stringify(record(),null,2);try{await navigator.clipboard.writeText(value);status('기록문을 복사했습니다. 주 작업 대화에 붙여 넣으세요.')}catch{const el=$('#critic-text');el.hidden=false;$('#critic-text-label').hidden=false;el.value=value;el.focus();el.select();status('자동 복사가 안 됩니다. 아래 기록문을 직접 복사해 주 작업 대화에 붙여 넣으세요.')}};
