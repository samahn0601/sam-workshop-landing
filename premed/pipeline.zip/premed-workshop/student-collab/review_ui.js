const packet=__PACKET__;
const {say_next,...base}=packet;
const form=document.querySelector('#f');
document.querySelector('#say-text').textContent=say_next;
document.querySelector('#teachback-question').textContent='이번 단계의 개념 질문 — '+packet.teachback_prompt;
function decision(){return {...base,decision:document.querySelector('#verdict').value,reason:document.querySelector('#reason').value,teachback:document.querySelector('#teachback').value,uncertainty:document.querySelector('#uncertainty').value,attested_by_human:document.querySelector('#human').checked,created_at:new Date().toISOString()}}
function encoded(){return JSON.stringify(decision(),null,2)}
async function copyText(value,ok,fallback){try{await navigator.clipboard.writeText(value);document.querySelector('#decision-status').textContent=ok;return true}catch{const el=document.querySelector('#decision-text');el.hidden=false;document.querySelector('#decision-text-label').hidden=false;el.value=value;el.focus();el.select();document.querySelector('#decision-status').textContent=fallback;return false}}
form.onsubmit=e=>{e.preventDefault();if(!form.reportValidity())return;const name=packet.project+'-'+packet.stage+'-human.json';const u=URL.createObjectURL(new Blob([encoded()],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);document.querySelector('#decision-status').textContent='저장을 요청했습니다. 다운로드 폴더에 '+name+' 파일이 생겼는지 확인하고, 주 작업 대화에 위 문장을 붙여 넣으세요.'};
document.querySelector('#copy-decision').onclick=()=>{if(!form.reportValidity())return;copyText('다음은 내가 검토 화면에서 직접 작성한 판단입니다. 내용과 packet 정보를 바꾸지 말고 JSON 파일로 저장한 뒤 decide --file로 반영하고 현재 단계를 보여줘.\n\n'+encoded(),'판단문을 복사했습니다. 원래 주 작업 대화에 붙여 넣고 반영 결과를 확인하세요.','자동 복사가 안 됩니다. 아래 내용을 직접 복사해 원래 주 작업 대화에 붙여 넣으세요.')};
document.querySelector('#copy-say').onclick=()=>copyText(say_next,'문장을 복사했습니다. 판단을 저장한 뒤 주 작업 대화에 붙여 넣으세요.','자동 복사가 안 됩니다. 위의 문장을 직접 입력해도 됩니다.');
