"""Extracted unchanged Collab FIFO/HITL primitives. See FORK_PROVENANCE.json."""

class HITLCheckpointPending(Exception):
    """Raised when the pipeline is asked to advance (complete_step / check_gate)
    while a human-in-the-loop checkpoint is still unratified (audit fix F1).

    Collab's whole reason to exist is staged human judgment. The pre-fix
    orchestrator let 9 consecutive complete_step calls walk past H1–H4 with
    zero human_decisions — a silent bypass of every checkpoint. Now the FIRST
    pending checkpoint hard-stops the walk. The message names which hitl_id is
    pending, since when, and how to resume.
    """

def _queue(state: dict) -> list:
    """Return the FIFO checkpoint queue, tolerating legacy scalar state
    (audit fix F3). Never returns None."""
    q = state.get("awaiting_human_queue")
    return q if isinstance(q, list) else []

def _sync_awaiting_scalar(state: dict) -> None:
    """Keep the legacy scalar ``awaiting_human`` mirroring the HEAD of the queue
    so older readers (get_current_step / status / pending / external tools /
    tests) keep working while the queue is the source of truth (audit fix F3)."""
    q = _queue(state)
    state["awaiting_human"] = q[0] if q else None

def _enqueue_checkpoint(state: dict, entry: dict) -> None:
    """Append a checkpoint to the FIFO queue WITHOUT dropping earlier
    unratified ones (audit fix F3 — the scalar overwrite lost H2 when H4 was
    set).

    Dedupe is by hitl_id ALONE (coordinator finding, 2026-07-05): the queue
    holds AT MOST ONE entry per hitl_id. Two pause paths can legitimately map
    to the same checkpoint within one complete_step call — completing
    verify_fix_v1 fires BOTH the next-step COLLAB_PAUSES_AT block
    (coauthor_auto → H2, reason "Paused at ⑥'…") AND the HITL_CHECKPOINTS
    block (verify_fix_v1 → H2, reason "Coauthor Feedback #1"); likewise H4 via
    draft_v2 / critic_3engine. The previous (hitl_id, reason) dedupe let those
    stack as two H2 entries the human had to resolve twice. Now the second
    path MERGES into the existing entry: packet path refreshed, a distinct
    reason appended for context. The original entry keeps its FIFO position.
    """
    q = list(_queue(state))
    for existing in q:
        if existing.get("hitl_id") == entry.get("hitl_id"):
            # same checkpoint already queued — merge, never stack a duplicate
            if entry.get("emitted_packet"):
                existing["emitted_packet"] = entry["emitted_packet"]
            new_reason = entry.get("reason")
            old_reason = existing.get("reason") or ""
            if new_reason and new_reason not in old_reason:
                existing["reason"] = (f"{old_reason} | {new_reason}"
                                      if old_reason else new_reason)
            state["awaiting_human_queue"] = q
            _sync_awaiting_scalar(state)
            return
    q.append(entry)
    state["awaiting_human_queue"] = q
    _sync_awaiting_scalar(state)

def _assert_no_pending_checkpoint(state: dict, project_name: str,
                                  action: str, _bypass_hitl: bool = False) -> None:
    """Fail-closed guard for complete_step / check_gate (audit fix F1).

    Raises HITLCheckpointPending if the queue holds any unratified checkpoint.
    ``_bypass_hitl`` (TEST-ONLY escape hatch) skips the guard so automation
    tests can drive the pipeline without a human in the loop.
    """
    if _bypass_hitl:
        return
    q = _queue(state)
    if not q:
        return
    head = q[0]
    ids = ", ".join(str(e.get("hitl_id")) for e in q)
    raise HITLCheckpointPending(
        f"Cannot {action}: checkpoint decision {head.get('hitl_id')!r} is pending "
        f"since {head.get('timestamp', '?')} "
        f"(reason: {head.get('reason', '?')}). "
        f"Queue = [{ids}]. "
        f"Resolve it first:\n"
        f"  python scripts/orchestrator.py resume {project_name} "
        f"--hitl_id {head.get('hitl_id')} --decision \"<summary>\" "
        f"--input_path <path/to/response>\n"
        f"A researcher may grant scoped delegation; a delegated AI must use "
        f"resolve-delegated with an actual decision and evidence (not automatic approval).\n"
        f"(tests may pass _bypass_hitl=True to skip this guard)."
    )
