"""
Sam AI — Reproducibility Artifact Ledger (RAL)

Records the methodological exhaust that reviewers ask for later: exact search
strings, inclusion/exclusion decisions, representative prompts, model snapshots,
and provenance of external tools. This is intentionally separate from the
claim-evidence ledger: claim ledgers bind assertions to sources, while RAL
binds workflow steps to reproducibility artifacts.

Security invariant: this module never records secret-looking values. Payloads
are recursively redacted before they are written to disk.

v1.1 (AgentOps M1, 2026-08-30 — additive):
  - envelope에 optional 관측 필드 추가: event_id(항상), run_id/stage_id/
    parent_stage_id/git_commit/engine/input_artifacts/output_artifacts.
    필드를 쓰지 않는 기존 호출은 v1.0과 같은 정보 + event_id/run_id만 얹힌다.
    기존 reader(load_events/summarize/render_prisma_md/audit_bundle)는 무수정
    으로 동작한다(스키마 문자열로 필터하지 않음).
  - run 개념: run = 보통 "프로젝트 진행의 한 세션 구간"(OQ-2, planning/
    AGENTOPS_CONFLICT_LOG.md). meta/current_run.json이 SSOT이고, 명시
    begin_run()만 run.begin 이벤트를 남긴다. 자동 부착은 이벤트 없이 파일만
    만들어 기존 이벤트 스트림을 바꾸지 않는다.
  - content_policy: 프롬프트 원문 기록 정책. 기본 "verbatim"(저널 재현성
    대응이라는 v1.0의 설계 목적 유지 — OQ-1 층위 분리: telemetry 채널은
    별도로 무원문). "hash_only"는 원문을 빼고 해시·길이만 남긴다.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCHEMA = "sam-ai/reproducibility-ledger/v1.1"
SCHEMA_V10 = "sam-ai/reproducibility-ledger/v1.0"
DEFAULT_LEDGER_NAME = "reproducibility_ledger.jsonl"
CURRENT_RUN_FILENAME = "current_run.json"
#: 프롬프트 본문 기록 정책 후보 — _resolve_content_policy()가 해석한다.
CONTENT_POLICIES = ("verbatim", "hash_only")

_SECRET_KEY_RE = re.compile(
    r"(api[_-]?key|secret|token|password|credential|oauth|bearer)",
    re.IGNORECASE,
)
_SECRET_VALUE_RE = re.compile(
    r"(sk-[A-Za-z0-9_-]{16,}|AIza[0-9A-Za-z_-]{20,}|"
    r"ant-[A-Za-z0-9_-]{16,}|Bearer\s+[A-Za-z0-9._-]{16,}|"
    r"github_pat_[A-Za-z0-9_]{20,}|gh[pousr]_[A-Za-z0-9_]{20,}|"
    r"AKIA[0-9A-Z]{16}|xox[baprs]-[A-Za-z0-9-]{10,}|"
    r"eyJ[A-Za-z0-9_=-]{20,}\.[A-Za-z0-9_=-]{10,}\.[A-Za-z0-9_=-]{10,}|"
    r"https://hooks\.slack\.com/services/[A-Za-z0-9/_-]+)"
)
_PHI_VALUE_RE = re.compile(
    r"([A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}|"
    r"\b(?:\+?\d{1,3}[-.\s]?)?(?:\(?\d{2,4}\)?[-.\s]?)\d{3,4}[-.\s]?\d{4}\b|"
    r"\b(?:MRN|medical record number|patient id|patient_id)\s*[:#]?\s*[A-Za-z0-9-]{4,}\b|"
    r"\b\d{6}-\d{7}\b)"
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def default_ledger_path(project_dir: Path | str) -> Path:
    project_dir = Path(project_dir)
    return project_dir / "meta" / DEFAULT_LEDGER_NAME


def ensure_ledger(project_dir: Path | str, *,
                  project_id: str = "",
                  pipeline_mode: str = "") -> Path:
    """Create an empty meta/reproducibility_ledger.jsonl file with an opening
    `init` event if it does not yet exist. Idempotent.
    """
    ledger_path = default_ledger_path(project_dir)
    ledger_path.parent.mkdir(parents=True, exist_ok=True)
    if not ledger_path.exists():
        ledger_path.touch()
        append_event(
            ledger_path,
            project_id=project_id or Path(project_dir).name,
            event_type="init",
            actor="orchestrator",
            purpose="ledger_initialized",
            payload={
                "pipeline_mode": pipeline_mode,
                "schema": SCHEMA,
                "created_at": utc_now(),
            },
        )
    return ledger_path


def _hash_text(text: str) -> str:
    return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()


def project_root_for_ledger(ledger_path: Path | str) -> Path:
    """Conventional meta ledger, or a standalone ledger beside its artifacts."""
    parent = Path(ledger_path).resolve().parent
    return parent.parent if parent.name == "meta" else parent


def contained_artifact(project_dir: Path | str, reference: str | Path) -> Path:
    """Resolve a project artifact without following a reference outside the project."""
    root = Path(project_dir).resolve()
    candidate = Path(reference)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    if not resolved.is_relative_to(root):
        raise ValueError("artifact_outside_project")
    return resolved


def artifact_path_hash(path: Path | str) -> str:
    """Stable path identity for policy exclusions even when its label is redacted."""
    normalized = os.path.normcase(str(Path(path).resolve()))
    return _hash_text(normalized)


def capture_response(ledger_path: Path | str, response_text: str, *,
                     content_policy: str, response_artifact: str = "") -> dict:
    """Save a redacted response locally; original and stored hashes stay distinct.

    A caller-supplied path is only a provenance pointer: it is never overwritten.
    hash_only never creates a body file, even if a caller supplies a path.
    """
    result = {"response_hash": _hash_text(response_text or ""),
              "response_chars": len(response_text or ""),
              "response_artifact": "",
              "response_storage": "hash_only" if content_policy == "hash_only" else "missing"}
    root = project_root_for_ledger(ledger_path)
    if response_artifact:
        try:
            path = contained_artifact(root, response_artifact)
            result["source_response_artifact"] = path.relative_to(root).as_posix()
            result["source_response_path_hash"] = artifact_path_hash(path)
        except ValueError:
            result["source_response_artifact_status"] = "outside_project"
    if content_policy == "hash_only":
        return result
    if not response_text:
        return result
    clean_text = redact(response_text)
    try:
        folder = contained_artifact(root, Path(ledger_path).parent / "ai_responses")
        folder.mkdir(parents=True, exist_ok=True)
        path = folder / (uuid.uuid4().hex + ".txt")
        # Store UTF-8 bytes so the hash does not depend on platform newline conversion.
        data = clean_text.encode("utf-8")
        path.write_bytes(data)
        result.update(
            response_artifact=path.relative_to(root).as_posix(),
            stored_response_hash="sha256:" + hashlib.sha256(data).hexdigest(),
            response_storage="redacted_artifact",
            response_redacted=(clean_text != response_text),
        )
    except (OSError, ValueError) as exc:
        result["response_storage"] = "write_failed"
        result["response_storage_error"] = type(exc).__name__
    return result


def redact(value: Any) -> Any:
    """Recursively redact secret-looking keys and values."""
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for k, v in value.items():
            if _SECRET_KEY_RE.search(str(k)):
                out[k] = "[REDACTED]"
            else:
                out[k] = redact(v)
        return out
    if isinstance(value, (list, tuple)):
        return [redact(v) for v in value]
    if isinstance(value, str):
        value = _SECRET_VALUE_RE.sub("[REDACTED_SECRET]", value)
        return _PHI_VALUE_RE.sub("[REDACTED_PHI]", value)
    return value


# ============================================================
# Run context (AgentOps M1, v1.1) — run = 보통 한 세션 구간 (OQ-2)
# ============================================================

def _run_meta_path(ledger_path: Path | str) -> Path:
    return Path(ledger_path).parent / CURRENT_RUN_FILENAME


def _new_run_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"run_{stamp}_{uuid.uuid4().hex[:6]}"


def begin_run(ledger_path: Path | str, *, project_id: str = "",
              session_id: str = "", label: str = "") -> dict:
    """새 run 구간을 연다: meta/current_run.json 갱신 + run.begin 이벤트 1건.

    Claude Code 세션 시작 훅(또는 CLI `run-begin`)이 부르는 것이 정석이다.
    아무도 부르지 않아도 current_run()이 파일만 조용히 만들어 run_id 연속성은
    유지되지만, 그 경우 run 경계가 세션과 어긋날 수 있다(label로 구분 가능).
    """
    ledger_path = Path(ledger_path)
    info = {"run_id": _new_run_id(), "started_at": utc_now(),
            "session_id": session_id, "label": label}
    # 순서 계약 (review CX-6): run.begin 이벤트를 먼저 append하고, 성공한
    # 뒤에만 current_run.json을 회전한다. 이벤트 append가 실패하면 회전도
    # 일어나지 않아 "선언 없는 run"이 생기지 않는다(둘 다 실패 시 예외가
    # 호출자에게 그대로 보인다 — 조용한 부분 회전 금지).
    append_event(
        ledger_path,
        project_id=project_id or Path(ledger_path).parent.parent.name,
        event_type="run.begin",
        actor="orchestrator",
        purpose=label or "run_begin",
        payload={"session_id": session_id, "label": label},
        run_id=info["run_id"],
    )
    meta = _run_meta_path(ledger_path)
    meta.parent.mkdir(parents=True, exist_ok=True)
    meta.write_text(json.dumps(info, ensure_ascii=False, indent=2),
                    encoding="utf-8")
    return info


def current_run(ledger_path: Path | str, *, auto_create: bool = True,
                project_id: str = "") -> dict | None:
    """현재 run 정보를 돌려준다.

    파일이 없으면 auto_create=True일 때 **이벤트 없이** 파일만 생성한다 —
    기존 이벤트 스트림을 바꾸지 않기 위한 additive 보증이다(run.begin
    이벤트는 begin_run()만 남긴다). 어떤 실패도 원장 기록 자체를 막지 않도록
    None을 돌려줄 뿐 예외를 내지 않는다(run 부착은 부가 정보다).

    한계 (review CX-25): current_run.json은 프로젝트당 1개인 mutable
    포인터라, 같은 프로젝트를 두 세션이 **동시에** 진행하면 늦게 회전한
    세션의 run_id가 둘 다에 붙는다. 단일 운영자·프로젝트당 단일 세션이
    이 저장소의 운영 전제다(HITL 구조상 동시 진행이 없음).
    """
    meta = _run_meta_path(ledger_path)
    try:
        if meta.exists():
            info = json.loads(meta.read_text(encoding="utf-8"))
            if isinstance(info, dict) and info.get("run_id"):
                return info
        if not auto_create:
            return None
        info = {"run_id": _new_run_id(), "started_at": utc_now(),
                "session_id": "", "label": "auto_created"}
        meta.parent.mkdir(parents=True, exist_ok=True)
        meta.write_text(json.dumps(info, ensure_ascii=False, indent=2),
                        encoding="utf-8")
        return info
    except Exception:
        return None


def append_event(ledger_path: Path | str, *,
                 project_id: str,
                 event_type: str,
                 actor: str,
                 payload: dict[str, Any],
                 source_tool: str = "",
                 model: str = "",
                 purpose: str = "",
                 related_artifacts: list[str] | None = None,
                 run_id: str | None = None,
                 stage_id: str | None = None,
                 parent_stage_id: str | None = None,
                 git_commit: str | None = None,
                 engine: dict | None = None,
                 input_artifacts: list | None = None,
                 output_artifacts: list | None = None,
                 content_policy: str | None = None,
                 attach_run: bool = True) -> dict:
    """Append one JSONL ledger event and return the sanitized record.

    v1.1 optional 필드는 주어졌을 때만 기록된다(additive). run_id는 명시하지
    않으면 meta/current_run.json에서 자동 부착한다(attach_run=False로 끈다).
    artifact 해시의 정본은 meta/lineage.jsonl(step_contract)이며, 여기의
    input/output_artifacts는 이벤트-단위 참조용이다(중복 기록을 강제하지 않음).
    """
    ledger_path = Path(ledger_path)
    ledger_path.parent.mkdir(parents=True, exist_ok=True)
    clean_payload = redact(payload)
    if attach_run and run_id is None:
        info = current_run(ledger_path, auto_create=True,
                           project_id=project_id)
        run_id = (info or {}).get("run_id")
    record = {
        "schema": SCHEMA,
        "event_id": "evt_" + uuid.uuid4().hex[:12],
        "recorded_at": utc_now(),
        "project_id": project_id,
        "event_type": event_type,
        "actor": actor,
        "source_tool": source_tool,
        "model": model,
        "purpose": purpose,
        "related_artifacts": related_artifacts or [],
        "payload": clean_payload,
        "payload_hash": _hash_text(json.dumps(clean_payload, sort_keys=True,
                                              ensure_ascii=False)),
        "redaction_note": (
            "Secrets and common PHI patterns are best-effort redacted. "
            "Do not log raw patient traces or credentials."
        ),
    }
    if run_id:
        record["run_id"] = run_id
    if stage_id:
        record["stage_id"] = stage_id
    if parent_stage_id:
        record["parent_stage_id"] = parent_stage_id
    if git_commit:
        record["git_commit"] = git_commit
    if engine:
        record["engine"] = redact(engine)
    if input_artifacts:
        record["input_artifacts"] = redact(list(input_artifacts))
    if output_artifacts:
        record["output_artifacts"] = redact(list(output_artifacts))
    if content_policy and content_policy != "verbatim":
        record["content_policy"] = content_policy
    # Metadata supplied by manual recorders is no more trusted than a payload.
    record = redact(record)
    with ledger_path.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record, ensure_ascii=False) + "\n")
    return record


def log_search(ledger_path: Path | str, *,
               project_id: str,
               query: str,
               database: str,
               filters: dict[str, Any] | None = None,
               result_count: int | None = None,
               inclusion_rule: str = "",
               exclusion_rule: str = "",
               actor: str = "sam-ai",
               source_tool: str = "",
               reconstructed: bool = False,
               category: str = "") -> dict:
    payload: dict[str, Any] = {
        "database": database,
        "query": query,
        "filters": filters or {},
        "result_count": result_count,
        "inclusion_rule": inclusion_rule,
        "exclusion_rule": exclusion_rule,
    }
    if category:
        payload["category"] = category
    if reconstructed:
        payload["reconstructed"] = True
    return append_event(
        ledger_path,
        project_id=project_id,
        event_type="search",
        actor=actor,
        source_tool=source_tool or database,
        purpose="literature_discovery",
        payload=payload,
    )


def _resolve_content_policy(explicit: str | None) -> str:
    """content_policy 해석. 우선순위: 명시 인자 > SAM_RAL_CONTENT_POLICY env >
    "verbatim"(v1.0 현행 동작 = 저널 재현성 목적의 의도된 원문 기록, OQ-1).

    미지 값은 **hash_only로 fail-safe 강등**한다 (adversarial review CX-5).
    이 플래그는 프라이버시 통제라서, 오타('hash-only' 등)가 원문·PHI 노출
    쪽으로 조용히 열리면 안 된다. hash_only도 해시·길이는 남기므로 감사
    기능은 유지된다. determinism_flags의 "설정 타입 오류는 차단 권한이
    없다"와 방향이 다른 이유: 그쪽의 안전측은 '차단 안 함'이고, 여기의
    안전측은 '원문 기록 안 함'이다 — 실패는 항상 덜 위험한 쪽으로.
    """
    raw = explicit or os.environ.get("SAM_RAL_CONTENT_POLICY") or "verbatim"
    val = str(raw).strip().lower()
    if val not in CONTENT_POLICIES:
        # ASCII-only warning: this print runs inside the library call path
        # (log_prompt/log_model_call), and a cp949/cp1252 console must never
        # turn a bad env value into a UnicodeEncodeError that kills the append.
        print(f"[Sam AI] unknown content_policy {ascii(raw)} - failing SAFE "
              f"to 'hash_only' (allowed: {CONTENT_POLICIES})")
        return "hash_only"
    return val


def log_prompt(ledger_path: Path | str, *,
               project_id: str,
               prompt_name: str,
               prompt_text: str,
               model: str,
               task: str,
               actor: str = "sam-ai",
               response_artifact: str = "",
               reconstructed: bool = False,
               content_policy: str | None = None) -> dict:
    policy = _resolve_content_policy(content_policy)
    payload = {
        "prompt_name": prompt_name,
        "prompt_text": prompt_text if policy == "verbatim" else None,
        "prompt_hash": _hash_text(prompt_text),
        "response_artifact": response_artifact,
    }
    if policy != "verbatim":
        payload["prompt_chars"] = len(prompt_text or "")
        payload["content_policy"] = policy
    if reconstructed:
        payload["reconstructed"] = True
    return append_event(
        ledger_path,
        project_id=project_id,
        event_type="prompt",
        actor=actor,
        model=model,
        purpose=task,
        related_artifacts=[response_artifact] if response_artifact else [],
        payload=payload,
        content_policy=policy,
    )


def log_model_call(ledger_path: Path | str, *,
                   project_id: str,
                   model: str,
                   system_prompt: str,
                   user_prompt: str,
                   task: str,
                   response_text: str = "",
                   response_metadata: dict | None = None,
                   provider: str = "",
                   actor: str = "sam-ai",
                   response_artifact: str = "",
                   reconstructed: bool = False,
                   content_policy: str | None = None,
                   stage_id: str = "") -> dict:
    """Record a full LLM API call (system + user prompt + response metadata).

    Captures everything reviewers typically demand: exact model snapshot
    (response_metadata['id']/['model']), token usage, system + user
    prompt text with hashes, and a pointer to the saved response artifact.

    With verbatim policy, a best-effort-redacted response copy is saved under
    meta/ai_responses and bound by its own stored hash. hash_only saves no body.

    v1.1: content_policy="hash_only"면 프롬프트 원문 대신 해시·길이만 남긴다
    (기본은 verbatim — OQ-1 층위 분리). response_metadata["applied_params"]가
    있으면(gemini/openai wrapper의 정직 기록) 그 canonical JSON의 sha256을
    engine.config_hash로 envelope에 얹어 실행 설정을 조회 가능하게 한다.
    """
    policy = _resolve_content_policy(content_policy)
    response_record = capture_response(
        ledger_path, response_text, content_policy=policy,
        response_artifact=response_artifact)
    payload: dict[str, Any] = {
        "provider": provider,
        "system_prompt": system_prompt if policy == "verbatim" else None,
        "system_prompt_hash": _hash_text(system_prompt or ""),
        "user_prompt": user_prompt if policy == "verbatim" else None,
        "user_prompt_hash": _hash_text(user_prompt or ""),
        **response_record,
        "response_metadata": response_metadata or {},
        "recording_method": "automatic_wrapper",
        "model_identity": "reported" if model else "unknown",
    }
    if policy != "verbatim":
        payload["system_prompt_chars"] = len(system_prompt or "")
        payload["user_prompt_chars"] = len(user_prompt or "")
        payload["content_policy"] = policy
    if reconstructed:
        payload["reconstructed"] = True
    engine: dict[str, Any] = {"provider": provider or "", "model_id": model}
    applied = (response_metadata or {}).get("applied_params")
    if isinstance(applied, dict) and applied:
        engine["config_hash"] = _hash_text(
            json.dumps(applied, sort_keys=True, ensure_ascii=False,
                       default=str))
    return append_event(
        ledger_path,
        project_id=project_id,
        event_type="model_call",
        actor=actor,
        model=model,
        purpose=task,
        source_tool=provider,
        related_artifacts=([response_record["response_artifact"]]
                           if response_record["response_artifact"] else []),
        payload=payload,
        engine=engine,
        stage_id=stage_id or None,
        content_policy=policy,
    )




def log_stage_completed(ledger_path: Path | str, *,
                        project_id: str,
                        step_id: str,
                        pipeline_mode: str = "",
                        lineage_event: dict | None = None,
                        actor: str = "orchestrator") -> dict:
    """스텝 완주를 RAL 이벤트로 남긴다 (AgentOps M1, T1.2).

    artifact 해시의 정본은 meta/lineage.jsonl이다 — 여기서는 lineage 기록의
    요약(status/source/missing)만 실어 이벤트 스트림에서 step 순서를 재구성할
    수 있게 한다. 호출부(양 파이프라인 complete_step)는 이 함수를 try/except로
    감싸 어떤 실패도 스텝 완료를 되돌리지 않게 한다.
    """
    ev = lineage_event or {}
    payload: dict[str, Any] = {
        "step_id": step_id,
        "pipeline_mode": pipeline_mode,
        "lineage_status": ev.get("status"),
        "lineage_source": ev.get("source"),
        "lineage_outputs": ev.get("outputs") or [],
        "lineage_missing_outputs": ev.get("missing_outputs") or [],
        "lineage_error": ev.get("error"),
    }
    return append_event(
        ledger_path,
        project_id=project_id,
        event_type="stage",
        actor=actor,
        purpose=step_id,
        stage_id=step_id,
        payload=payload,
    )


def log_gate_verdict(ledger_path: Path | str, *,
                     project_id: str,
                     gate_record: dict,
                     pipeline_mode: str = "",
                     actor: str = "orchestrator") -> dict:
    """게이트 판정을 RAL 이벤트로 남긴다 (AgentOps M1, T1.2/T1.4).

    state.json의 gates_passed 레코드가 판정의 정본이고, 이 이벤트는 run_id로
    join되는 조회용 사본이다. results_snapshot 같은 대형 필드는 싣지 않고
    must_fix/should_fix는 앞 20건으로 캡한다(전문은 state.json에 있다).
    """
    g = gate_record or {}
    payload: dict[str, Any] = {
        "gate": g.get("gate"),
        "verdict": g.get("verdict"),
        "passed": g.get("passed"),
        "must_fix_count": len(g.get("must_fix") or []),
        "should_fix_count": len(g.get("should_fix") or []),
        "must_fix": list(g.get("must_fix") or [])[:20],
        "should_fix": list(g.get("should_fix") or [])[:20],
        "iteration": g.get("iteration"),
        "retry_count": g.get("retry_count"),
        "escalated": bool(g.get("escalated", False)),
        "pipeline_mode": pipeline_mode,
    }
    gate_id = g.get("gate")
    return append_event(
        ledger_path,
        project_id=project_id,
        event_type="gate",
        actor=actor,
        purpose=f"gate.{gate_id}",
        stage_id=f"gate.{gate_id}",
        payload=payload,
    )


def log_selection_flow(ledger_path: Path | str, *,
                       project_id: str,
                       stage: str,
                       candidates_seen: int,
                       candidates_included: int,
                       candidates_excluded: int,
                       inclusion_criteria: list[str],
                       exclusion_criteria: list[str],
                       actor: str = "sam-ai",
                       source_artifact: str = "") -> dict:
    return append_event(
        ledger_path,
        project_id=project_id,
        event_type="selection_flow",
        actor=actor,
        purpose=stage,
        related_artifacts=[source_artifact] if source_artifact else [],
        payload={
            "stage": stage,
            "candidates_seen": candidates_seen,
            "candidates_included": candidates_included,
            "candidates_excluded": candidates_excluded,
            "inclusion_criteria": inclusion_criteria,
            "exclusion_criteria": exclusion_criteria,
        },
    )


def load_events(ledger_path: Path | str) -> list[dict]:
    ledger_path = Path(ledger_path)
    if not ledger_path.exists():
        return []
    events = []
    for line in ledger_path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            events.append(json.loads(line))
    return events


def summarize(ledger_path: Path | str) -> dict:
    events = load_events(ledger_path)
    by_type: dict[str, int] = {}
    by_model: dict[str, int] = {}
    reconstructed_count = 0
    for e in events:
        by_type[e["event_type"]] = by_type.get(e["event_type"], 0) + 1
        if e.get("model"):
            by_model[e["model"]] = by_model.get(e["model"], 0) + 1
        payload = e.get("payload") or {}
        if isinstance(payload, dict) and payload.get("reconstructed"):
            reconstructed_count += 1
    return {
        "schema": SCHEMA,
        "ledger_path": str(ledger_path),
        "event_count": len(events),
        "by_type": by_type,
        "by_model": by_model,
        "reconstructed_events": reconstructed_count,
        "has_search_strings": by_type.get("search", 0) > 0,
        "has_representative_prompts": (
            by_type.get("prompt", 0) > 0 or by_type.get("model_call", 0) > 0
        ),
        "has_model_calls": by_type.get("model_call", 0) > 0,
        "has_selection_flow": by_type.get("selection_flow", 0) > 0,
    }


def render_prisma_md(ledger_path: Path | str, *, project_id: str = "") -> str:
    """PRISMA-2020-style flow summary rendered from ledger events (2026-07-12,
    컨설팅 lit-scout 산출물용 — 파이프라인/R&R에서도 재사용 가능).

    Fail-closed rendering rules:
    - ``search`` events with ``result_count=None`` render as "미기록" — never 0
      (an unrecorded count is an honest gap, not a zero).
    - No ``selection_flow`` event at all -> "선정 흐름 미기록 — PRISMA 요약 불가"
      (no fabricated flow numbers).
    - Fixed caveat: this summarizes ALGORITHMIC screening; it does not replace
      a formal systematic review's dual independent human screening.
    """
    events = load_events(ledger_path)
    searches = [e for e in events if e.get("event_type") == "search"]
    flows = [e for e in events if e.get("event_type") == "selection_flow"]

    lines = ["# PRISMA-style 선정 흐름 요약",
             "",
             f"- ledger: `{Path(ledger_path).name}`"
             + (f"  ·  project: {project_id}" if project_id else ""),
             ""]

    # --- Identified, per database ---
    lines.append("## Identification (검색 단계)")
    lines.append("")
    if not searches:
        lines.append("(검색 이벤트 미기록)")
    else:
        per_db: dict[str, dict] = {}
        for e in searches:
            payload = e.get("payload", {}) or {}
            db = payload.get("database") or "(unknown)"
            slot = per_db.setdefault(db, {"queries": 0, "count": 0,
                                          "unrecorded": 0})
            slot["queries"] += 1
            rc = payload.get("result_count")
            if rc is None:
                slot["unrecorded"] += 1
            else:
                slot["count"] += int(rc)
        lines.append("| Database | 검색식 수 | Identified (합산) |")
        lines.append("|---|---|---|")
        for db, slot in sorted(per_db.items()):
            if slot["unrecorded"] and not slot["count"]:
                shown = "미기록"
            elif slot["unrecorded"]:
                shown = f"{slot['count']}+ (일부 미기록)"
            else:
                shown = str(slot["count"])
            lines.append(f"| {db} | {slot['queries']} | {shown} |")
    lines.append("")

    # --- Screening / Included, from the LAST selection_flow ---
    lines.append("## Screening → Included (선정 단계)")
    lines.append("")
    if not flows:
        lines.append("**선정 흐름 미기록 — PRISMA 요약 불가.** "
                     "(`log_selection_flow`가 기록된 뒤 다시 렌더하세요.)")
    else:
        payload = flows[-1].get("payload", {}) or {}
        lines += [
            f"- 검토 대상(candidates_seen): {payload.get('candidates_seen')}",
            f"- 포함(candidates_included): {payload.get('candidates_included')}",
            f"- 제외(candidates_excluded): {payload.get('candidates_excluded')}",
            f"- 단계(stage): {payload.get('stage', '')}",
            "",
            "### 포함 기준 (기록 그대로)",
        ]
        lines += [f"- {c}" for c in (payload.get("inclusion_criteria") or [])] or ["- (미기록)"]
        lines.append("")
        lines.append("### 제외 기준 (기록 그대로)")
        lines += [f"- {c}" for c in (payload.get("exclusion_criteria") or [])] or ["- (미기록)"]
    lines += [
        "",
        "---",
        "> ⚠️ 본 요약은 **알고리즘 스크리닝**의 기록이다. 정식 systematic review가",
        "> 요구하는 2인 독립 인간 스크리닝의 PRISMA 흐름도를 대체하지 않는다.",
        "",
    ]
    return "\n".join(lines)


def _main() -> int:
    ap = argparse.ArgumentParser(description="Sam AI — Reproducibility Artifact Ledger")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("search", help="Append a search-string event")
    s.add_argument("--ledger", required=True)
    s.add_argument("--project-id", required=True)
    s.add_argument("--database", required=True)
    s.add_argument("--query", required=True)
    s.add_argument("--result-count", type=int, default=None)
    s.add_argument("--inclusion-rule", default="")
    s.add_argument("--exclusion-rule", default="")

    p = sub.add_parser("prompt", help="Append a representative prompt event")
    p.add_argument("--ledger", required=True)
    p.add_argument("--project-id", required=True)
    p.add_argument("--prompt-name", required=True)
    p.add_argument("--prompt-file", required=True)
    p.add_argument("--model", required=True)
    p.add_argument("--task", required=True)
    p.add_argument("--response-artifact", default="")

    sm = sub.add_parser("summary", help="Summarize a ledger")
    sm.add_argument("--ledger", required=True)

    pr = sub.add_parser("prisma", help="Render PRISMA-style flow markdown")
    pr.add_argument("--ledger", required=True)
    pr.add_argument("--project-id", default="")
    pr.add_argument("--out", default=None, help="write to file (default stdout)")

    rb = sub.add_parser("run-begin",
                        help="Begin a new run segment (session boundary)")
    rb.add_argument("--ledger", required=True)
    rb.add_argument("--project-id", default="")
    rb.add_argument("--session-id", default="",
                    help="Claude Code session_id (hook stdin)")
    rb.add_argument("--label", default="")

    args = ap.parse_args()
    if args.cmd == "search":
        rec = log_search(
            args.ledger,
            project_id=args.project_id,
            database=args.database,
            query=args.query,
            result_count=args.result_count,
            inclusion_rule=args.inclusion_rule,
            exclusion_rule=args.exclusion_rule,
        )
        print(json.dumps(rec, indent=2, ensure_ascii=False))
        return 0
    if args.cmd == "prompt":
        prompt_text = Path(args.prompt_file).read_text(encoding="utf-8")
        rec = log_prompt(
            args.ledger,
            project_id=args.project_id,
            prompt_name=args.prompt_name,
            prompt_text=prompt_text,
            model=args.model,
            task=args.task,
            response_artifact=args.response_artifact,
        )
        print(json.dumps(rec, indent=2, ensure_ascii=False))
        return 0
    if args.cmd == "summary":
        print(json.dumps(summarize(args.ledger), indent=2, ensure_ascii=False))
        return 0
    if args.cmd == "prisma":
        md = render_prisma_md(args.ledger, project_id=args.project_id)
        if args.out:
            Path(args.out).write_text(md, encoding="utf-8")
            print(f"[ledger] prisma flow written: {args.out}")
        else:
            print(md)
        return 0
    if args.cmd == "run-begin":
        info = begin_run(args.ledger, project_id=args.project_id,
                         session_id=args.session_id, label=args.label)
        print(json.dumps(info, indent=2, ensure_ascii=False))
        return 0
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
