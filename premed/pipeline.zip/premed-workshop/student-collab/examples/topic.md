# 오늘 수업의 공통 사례

이 자료는 수업 진행용 예시이며 실제 연구 결과가 아닙니다.

관심 질문: 힌트를 주는 AI로 연습한 학생(guided)과 그렇지 않은 학생(control)의 퀴즈 점수는 얼마나 다를까?

자료: `statsam-student/data/synthetic_quiz.csv` — 강사가 만든 합성 자료 24명(집단당 12명). guided를 힌트형 AI로 연습한 집단으로 가정합니다. 실제 배정 실험이 아니므로 인과를 말할 수 없습니다.

오늘 범위: 전체 원고 초안. 서론의 근거는 공개 문헌에서 찾고, 결과는 StatSam으로 실제 계산한 값만 씁니다. 새로운 실험이나 설문을 수행했다고 쓰지 않습니다.

배경으로 읽을 공개 문헌 후보:
- Bastani 등. Generative AI without guardrails can harm learning: Evidence from high school mathematics. PNAS 2025. https://doi.org/10.1073/pnas.2422633122

본인 주제나 권한이 확인된 드래프트가 있으면 그것을 우선 사용합니다.
