"""Actual classroom packaging and local browser upload practice. Python stdlib only."""
import argparse, base64, hashlib, html, importlib.util, json, secrets, shutil, sys, tempfile, zipfile
from datetime import datetime,timezone
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from xml.sax.saxutils import escape
from xml.etree import ElementTree as ET
BASE=Path(__file__).resolve().parent
sys.path.insert(0,str(BASE/'student-collab'))
import pipeline as core

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now(): return datetime.now(timezone.utc).isoformat()
def write_json(p,d): Path(p).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def completed(project):
    p=core.folder(project);s=core.state(p);core.require_fresh(p,s)
    if s['stage']!='DONE' or set(s['approved_artifacts'])!=set(core.STAGES) or core.log_integrity(p): raise ValueError('Finish H1-H5 with fresh approved artifacts and intact AI records first')
    return p,s
def docx(src,dest):
    # Plain paragraphs preserve text; no claim of journal template compliance.
    paras=''.join('<w:p><w:r><w:t xml:space="preserve">'+escape(line)+'</w:t></w:r></w:p>' for line in src.splitlines())
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        z.writestr('word/document.xml','<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'+paras+'</w:body></w:document>')
def docx_parity(source,document):
    with zipfile.ZipFile(document) as z:
        tree=ET.fromstring(z.read('word/document.xml'))
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
    lines=[''.join(t.text or '' for t in para.findall('.//w:t',ns)) for para in tree.findall('.//w:body/w:p',ns)]
    if lines!=source.splitlines(): raise ValueError('DOCX main body differs from approved source')
    return True
def prepare(project):
    p,s=completed(project);out=p/'packaging-input'
    if out.exists(): return {'status':'RESUME_INPUTS','folder':str(out)}
    out.mkdir()
    (out/'cover_letter.md').write_text('# Cover letter — classroom draft\n\n[작성: 원고 제목, 수업 실습 제출 목적, 실제 글의 핵심과 한계, 저자 정보]\n\n실제 저널 투고용인 경우 저널 최신 규정과 저자 진술로 별도 수정. 미수행 연구·공저자 동의·IRB·COI·독점 투고를 추정하지 않는다.\n',encoding='utf-8')
    (out/'author_checklist.md').write_text('# Author review\n\n[작성: 마지막 원고와 출처를 확인한 범위, 남은 미확인 사항, AI 사용 공개 확인, 실제 저자·자료 권한, 형식 검토 한계]\n\n교과 실습 완료는 실제 연구 완료·투고 준비 완료를 뜻하지 않는다.\n',encoding='utf-8')
    write_json(out/'author_review.json',{'schema':'student-packaging-review/1','actor':'human','source':'user_direct','instruction':'','reviewed':False,'artifact_sha256':{}})
    return {'status':'DRAFT_REQUIRES_AUTHOR_REVIEW','folder':str(out),'next':'Agent drafts cover letter/checklist from actual author facts, then shows final files to the student; only their real response fills author_review.json and exact file hashes.'}
def bindings(p):
    names=['revision.md','evidence.csv','critic.md','disclosure.md','packaging-input/cover_letter.md','packaging-input/author_checklist.md']
    for n in names:
        f=core.local(p,n)
        if not f.is_file() or '[작성' in core.read(f) or '[CONFIRM' in core.read(f) or len(core.read(f).strip())<30: raise ValueError('Incomplete: '+n)
    return {n:sha(p/n) for n in names}
def package(project):
    p,s=completed(project);b=bindings(p);r=json.loads(core.read(p/'packaging-input/author_review.json'))
    if r.get('actor')!='human' or r.get('source')!='user_direct' or r.get('reviewed') is not True or not r.get('instruction','').strip() or r.get('artifact_sha256')!=b: raise ValueError('Actual author review of exact final files required; stale/missing approval')
    out=p/'submission-training'
    if out.exists(): raise ValueError('Package exists; preserved. Use verify, or a new version/project after reopening affected H stage')
    with tempfile.TemporaryDirectory(prefix='.package-',dir=p) as tmp:
        stage=Path(tmp)/'submission-training';stage.mkdir()
        for n in b: shutil.copyfile(p/n,stage/Path(n).name)
        docx(core.read(p/'revision.md'),stage/'manuscript.docx')
        docx(core.read(p/'packaging-input/cover_letter.md'),stage/'cover_letter.docx')
        write_json(stage/'human-decisions.json',s['decisions'])
        write_json(stage/'AUTHOR_REVIEW.json',r)
        m={'schema':'student-submission-training/1','created_at':now(),'status':'CLASSROOM_PACKAGE_REVIEWED','real_submission_ready':False,'submitted':False,'approved_inputs':b,'files':{f.name:sha(f) for f in stage.iterdir() if f.is_file()},'limitations':['Plain DOCX paragraphs; no target-journal layout validation','Public evidence existence/support must be checked separately','No coauthor/IRB/ethics approval inferred','No raw AI transcripts or student data in upload ZIP']}
        write_json(stage/'manifest.json',m)
        shutil.move(str(stage),str(out))
    with zipfile.ZipFile(out/'upload.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(out.iterdir()):
            if f.name!='upload.zip': z.write(f,f.name)
    core.event(p,'classroom.package_created',{'manifest_sha256':sha(out/'manifest.json'),'upload_sha256':sha(out/'upload.zip'),'author_review':'AUTHOR_ATTESTED','real_submission_ready':False})
    return verify(project)
def verify(project):
    p,s=completed(project);out=p/'submission-training';m=json.loads(core.read(out/'manifest.json'))
    if m['approved_inputs']!=bindings(p): raise ValueError('Final inputs changed after packaging')
    for n,h in m['files'].items():
        if sha(out/n)!=h: raise ValueError('Packaged file changed: '+n)
    docx_parity(core.read(p/'revision.md'),out/'manuscript.docx')
    docx_parity(core.read(p/'packaging-input/cover_letter.md'),out/'cover_letter.docx')
    with zipfile.ZipFile(out/'upload.zip') as z:
        expected=set(m['files'])|{'manifest.json'}
        if set(z.namelist())!=expected: raise ValueError('Upload archive file set changed')
        for n in expected:
            if hashlib.sha256(z.read(n)).hexdigest()!=sha(out/n): raise ValueError('Upload archive changed')
    return {'status':'CLASSROOM_PACKAGE_VERIFIED','folder':str(out),'upload':str(out/'upload.zip'),'upload_sha256':sha(out/'upload.zip'),'docx_main_body_parity':True,'submission_status':'NOT_SUBMITTED','real_submission_ready':False}
def portal(project,port):
    v=verify(project);p=core.folder(project);token=secrets.token_urlsafe(24);receipt=p/'submission-training/TRAINING_RECEIPT.json'
    if receipt.exists(): raise ValueError('Training receipt already exists; preserved')
    page='''<!doctype html><html lang="ko"><meta charset="utf-8"><title>수업 투고 연습</title><h1>수업 투고 연습 — 실제 저널 아님</h1><p>이 페이지는 localhost에서만 동작합니다. 실제 저널·이메일·환자 자료를 입력하지 마세요.</p><form><label>원고 제목 <input id="title" required maxlength="200"></label><p><label>제공된 upload.zip <input id="file" type="file" accept=".zip" required></label></p><label><input id="review" type="checkbox" required>최종 파일과 AI 공개문을 읽었습니다.</label><p><button>연습 제출</button></p></form><pre id="result"></pre><script>document.querySelector('form').onsubmit=async e=>{e.preventDefault();let f=document.querySelector('#file').files[0];if(f.size>5000000){document.querySelector('#result').textContent='파일이 너무 큽니다';return;}let a=new Uint8Array(await f.arrayBuffer());let s='';for(let x of a)s+=String.fromCharCode(x);let r=await fetch('/submit',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token:'TOKEN',title:document.querySelector('#title').value,reviewed:document.querySelector('#review').checked,upload:btoa(s)})});document.querySelector('#result').textContent=JSON.stringify(await r.json(),null,2);};</script></html>'''.replace('TOKEN',token)
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def reply(self,code,data,kind='application/json'):
            blob=data.encode();self.send_response(code);self.send_header('Content-Type',kind+'; charset=utf-8');self.send_header('Content-Length',str(len(blob)));self.end_headers();self.wfile.write(blob)
        def do_GET(self):
            if self.path!='/': return self.reply(404,'{}')
            self.reply(200,page,'text/html')
        def do_POST(self):
            try:
                if self.path!='/submit' or self.headers.get('Origin')!='http://'+self.headers.get('Host','') or self.headers.get('Host')!=f'127.0.0.1:{self.server.server_port}': raise ValueError('Local origin only')
                n=int(self.headers.get('Content-Length','0'))
                if n<1 or n>7_000_000: raise ValueError('Request size')
                d=json.loads(self.rfile.read(n));v=verify(project)
                if d.get('token')!=token or d.get('reviewed') is not True or not 1<=len(d.get('title','').strip())<=200: raise ValueError('Complete title and review')
                uploaded=base64.b64decode(d['upload'],validate=True)
                if hashlib.sha256(uploaded).hexdigest()!=v['upload_sha256']: raise ValueError('Upload differs from reviewed package')
                r={'schema':'student-training-receipt/1','status':'TRAINING_SUBMITTED','real_journal_submission':False,'receipt_id':'TRAINING-'+secrets.token_hex(8),'submitted_at':now(),'title':d['title'],'upload_sha256':v['upload_sha256']}
                with receipt.open('x',encoding='utf-8') as f: json.dump(r,f,ensure_ascii=False,indent=2)
                core.event(p,'classroom.training_submitted',r);self.reply(200,json.dumps(r,ensure_ascii=False))
            except (ValueError,OSError,KeyError) as e: self.reply(400,json.dumps({'status':'HOLD','error':str(e)}))
    server=HTTPServer(('127.0.0.1',port),Handler)
    print(json.dumps({'url':f'http://127.0.0.1:{server.server_port}/','status':'LOCAL_TRAINING_ONLY'}),flush=True)
    server.serve_forever()

def main():
    a=argparse.ArgumentParser();a.add_argument('command',choices=['prepare','package','verify','portal']);a.add_argument('project');a.add_argument('--port',type=int,default=0);x=a.parse_args()
    return portal(x.project,x.port) if x.command=='portal' else globals()[x.command](x.project)
if __name__=='__main__':
    try: print(json.dumps(main(),ensure_ascii=False,indent=2))
    except (ValueError,OSError,KeyError) as e: print(json.dumps({'status':'HOLD','error':str(e)},ensure_ascii=False));sys.exit(2)
