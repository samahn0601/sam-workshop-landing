"""Numeric Provenance JSON — PRD 부록 B 스키마 (Pydantic v2).

모든 통계 결과는 result_id 단위로 이 모델로 직렬화된다.
LLM은 숫자를 직접 생성하지 못하며, Jinja2 placeholder가 이 JSON 값으로 치환된다.
"""

from __future__ import annotations

import hashlib
import json
import math
import subprocess
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator


ModelName = Literal[
    # Phase 1.0 / 1.1
    "ANCOVA", "OLS", "Logistic", "Cox", "GEE", "MixedLM", "tableone",
    # Phase 1.2 — hypothesis tests
    "t_test", "mann_whitney", "wilcoxon_signed_rank",
    "chi_square", "fisher_exact", "mcnemar",
    "one_way_anova", "welch_anova", "kruskal_wallis", "tukey_hsd", "dunn",
    "correlation",
    "pearson", "spearman", "kendall",
    # Phase 1.3 — regression
    "logistic", "firth_logistic", "poisson", "negative_binomial",
    # Phase 1.4 — survival
    "kaplan_meier", "log_rank", "cox", "schoenfeld_ph",
]

# PRD §7.4 — Differential test 상대오차 임계
REL_ERROR_THRESHOLD: float = 0.001


class DifferentialCheck(BaseModel):
    """Python ↔ R differential test 결과."""

    model_config = ConfigDict(extra="forbid")

    engine_alt: str
    estimate_alt: float
    checked_fields: list[str] = Field(default_factory=list, description="Fields actually compared in this execution; empty for legacy evidence.")
    rel_error: float = Field(
        ...,
        description="Relative error vs primary engine. Must be ≤ 0.001.",
    )

    @field_validator("estimate_alt")
    @classmethod
    def _finite_estimate_alt(cls, v: float) -> float:
        if math.isnan(v) or math.isinf(v):
            raise ValueError(
                f"Differential estimate_alt must be finite (got {v!r}). "
                "NaN/Inf indicates a degenerate engine output (convergence "
                "failure, zero events, separation, etc.). Analysis halted."
            )
        return v

    @field_validator("rel_error")
    @classmethod
    def _within_threshold(cls, v: float) -> float:
        if math.isnan(v) or math.isinf(v):
            raise ValueError(
                f"Differential rel_error must be finite (got {v!r}). "
                "NaN/Inf indicates degenerate engine output (e.g., both "
                "engines returned NaN). Analysis halted (PRD §7.4)."
            )
        if v > REL_ERROR_THRESHOLD:
            raise ValueError(
                f"Differential rel_error={v:.6f} exceeds threshold "
                f"{REL_ERROR_THRESHOLD}. Analysis halted (PRD §7.4)."
            )
        return v


class Provenance(BaseModel):
    """Single statistical result — result_id 단위 박제."""

    model_config = ConfigDict(extra="forbid")

    result_id: str
    analysis_id: str
    endpoint: str
    comparison: str
    model: ModelName
    estimate: float
    estimate_unit: str
    n_analyzed: int = Field(..., gt=0)
    display: str = Field(..., description="Pre-formatted string for paper insertion")
    input_data_sha256: str = Field(..., min_length=64, max_length=64)
    code_commit: str
    engine: str

    estimate_status: Literal["estimated", "not_reached"] = Field(
        default="estimated",
        description=(
            "'not_reached' marks a quantity with no value (e.g. a Kaplan-Meier median "
            "never crossed 0.5). `estimate` is then a required placeholder, not a result."
        ),
    )
    ci_95: tuple[float, float] | None = None
    std_error: float | None = Field(default=None, gt=0)
    p_value: float | None = Field(default=None, ge=0, le=1)
    missing_rule: str | None = None
    differential_check: DifferentialCheck | None = None
    # Phase 1.5+ — reproducibility & lineage hardening
    random_seed: int | None = Field(
        default=None,
        description="Random seed used (bootstrap/permutation/MI). None when analysis is deterministic.",
    )
    environment_hash: str | None = Field(
        default=None,
        min_length=64,
        max_length=64,
        description="SHA-256 of (uv.lock || renv.lock) for environment-level reproducibility.",
    )
    raw_input_sha256: str | None = Field(
        default=None,
        min_length=64,
        max_length=64,
        description=(
            "SHA-256 of the raw EMR/source extract before any preprocessing. "
            "Distinct from input_data_sha256 (which is the analysis-ready CSV)."
        ),
    )

    def to_json(self, path: str | Path) -> None:
        """Write provenance to JSON file (UTF-8, indented)."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as f:
            json.dump(self.model_dump(mode="json"), f, ensure_ascii=False, indent=2)

    @classmethod
    def from_json(cls, path: str | Path) -> "Provenance":
        with Path(path).open("r", encoding="utf-8") as f:
            return cls.model_validate(json.load(f))


def sha256_file(path: str | Path) -> str:
    """SHA-256 hash of a file's bytes (input data fingerprint)."""
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def current_git_commit(repo_dir: str | Path | None = None) -> str:
    """Return current git commit SHA (short) or 'uncommitted' if outside repo / no commits."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=str(repo_dir) if repo_dir else None,
            capture_output=True,
            text=True,
            check=False,
            timeout=5,
        )
        if result.returncode == 0:
            return f"git:{result.stdout.strip()}"
    except (subprocess.TimeoutExpired, FileNotFoundError):
        pass
    return "git:uncommitted"


def format_apa_continuous(
    estimate: float,
    ci_low: float,
    ci_high: float,
    p_value: float,
    unit: str = "",
) -> str:
    """APA-ish display string for continuous adjusted mean difference."""
    unit_str = f" {unit}" if unit else ""
    return (
        f"adjusted mean difference {estimate:.2f}{unit_str}, "
        f"95% CI {ci_low:.2f} to {ci_high:.2f}, p{format_apa_pvalue(p_value)}"
    )


def format_apa_effect_ci(
    label: str,
    estimate: float,
    ci_low: float,
    ci_high: float,
    p_value: float | None,
    *,
    unit: str = "",
    estimate_decimals: int = 3,
) -> str:
    """Phase 1.5.1+: canonical 'X (95% CI Y to Z), p<APA>' display string.

    Used by all run_* functions (t-test, Mann-Whitney HL, Wilcoxon SR, chi-sq
    OR, Fisher OR, ANOVA F-with-df, regression, Cox HR, KM median, etc.) to
    produce a journal-ready display compliant with ICMJE / AMA Manual of
    Style. The inner numerics use {estimate_decimals}-digit rounding.
    """
    fmt = f"{{:.{estimate_decimals}f}}"
    unit_str = f" {unit}" if unit else ""
    return (
        f"{label} {fmt.format(estimate)}{unit_str}, "
        f"95% CI {fmt.format(ci_low)} to {fmt.format(ci_high)}, "
        f"p{format_apa_pvalue(p_value)}"
    )


def format_apa_pvalue(p: float | None, *, decimals: int = 3) -> str:
    """APA / AMA Manual of Style p-value formatter (Phase 1.5+).

    Returns the leading operator + value for direct insertion: '<0.001', '=0.042'.
    Reference: AMA Manual of Style 11th ed., §19.4.2; ICMJE recommendations.
    """
    if p is None:
        return "=NA"
    if not (0.0 <= p <= 1.0):
        raise ValueError(f"p-value must be in [0,1]; got {p!r}")
    threshold = 10 ** (-decimals)
    if p < threshold:
        return f"<{threshold:.{decimals}f}"
    return f"={p:.{decimals}f}"


def environment_hash_for_repo(
    repo_dir: str | Path | None = None,
    *,
    lockfiles: tuple[str, ...] = ("uv.lock", "renv.lock"),
) -> str:
    """Phase 1.5+: SHA-256 over the concatenated bytes of project lockfiles.

    Single deterministic hash that captures both Python (uv) and R (renv) deps.
    Returns a 64-char hex string. Files that don't exist are silently skipped
    (e.g. early Phase 1.0 trees). If none exist, returns the SHA of an empty
    payload — the result is still 64 chars and stable.
    """
    base = Path(repo_dir) if repo_dir else Path(__file__).resolve().parents[2]
    h = hashlib.sha256()
    for name in lockfiles:
        p = base / name
        if p.exists():
            h.update(name.encode("utf-8"))
            h.update(b"\0")
            h.update(p.read_bytes())
            h.update(b"\n")
    return h.hexdigest()


__all__ = [
    "ModelName",
    "REL_ERROR_THRESHOLD",
    "DifferentialCheck",
    "Provenance",
    "sha256_file",
    "current_git_commit",
    "format_apa_continuous",
    "format_apa_pvalue",
    "format_apa_effect_ci",
    "environment_hash_for_repo",
]
