"""Shared Pydantic v2 result models for Phase 1.2 hypothesis tests.

All `run_*` test functions in `analysis/functions/` produce one of these
result models + a Provenance JSON, following the pattern established in
Phase 1.0 ANCOVA and Phase 1.1 Table 1.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class TwoGroupContinuousResult(BaseModel):
    """t-test / Mann-Whitney U / Wilcoxon signed-rank etc."""

    model_config = ConfigDict(extra="forbid")

    test_name: str
    statistic: float
    p_value: float = Field(..., ge=0.0, le=1.0)
    n_total: int = Field(..., gt=0)
    n_per_group: dict[str, int] = Field(default_factory=dict)
    estimate: float | None = Field(default=None, description="Mean diff, median diff, etc.")
    estimate_unit: str = ""
    ci_95: tuple[float, float] | None = None
    df: float | None = None
    paired: bool = False
    variant: str | None = None  # student / welch / paired
    display: str = ""


class CategoricalResult(BaseModel):
    """Chi-square / Fisher's exact / McNemar."""

    model_config = ConfigDict(extra="forbid")

    test_name: str
    statistic: float | None = None  # Fisher exact has no test stat in conventional sense
    p_value: float = Field(..., ge=0.0, le=1.0)
    df: float | None = None
    n_total: int = Field(..., gt=0)
    contingency: list[list[int]] = Field(default_factory=list)  # row major
    row_labels: list[str] = Field(default_factory=list)
    col_labels: list[str] = Field(default_factory=list)
    odds_ratio: float | None = None
    or_ci_95: tuple[float, float] | None = None
    yates_correction: bool | None = None  # for chi-square
    method: str | None = None  # e.g. "two-sided", "mid-p"
    display: str = ""


class MultiGroupResult(BaseModel):
    """ANOVA / Kruskal-Wallis."""

    model_config = ConfigDict(extra="forbid")

    test_name: str
    statistic: float
    p_value: float = Field(..., ge=0.0, le=1.0)
    df_between: float | None = None
    df_within: float | None = None
    n_total: int = Field(..., gt=0)
    n_per_group: dict[str, int] = Field(default_factory=dict)
    ss_type: int | None = None  # 1 / 2 / 3 (ANOVA only)
    eta_squared: float | None = None  # effect size
    display: str = ""


class PostHocComparison(BaseModel):
    model_config = ConfigDict(extra="forbid")

    group_1: str
    group_2: str
    estimate: float | None = None  # mean diff (Tukey) or rank-sum diff (Dunn)
    p_value_raw: float | None = None
    p_value_adjusted: float = Field(..., ge=0.0, le=1.0)
    ci_95: tuple[float, float] | None = None


class PostHocResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    test_name: str
    correction: str  # tukey / bonferroni / holm / bh_fdr
    n_comparisons: int = Field(..., gt=0)
    comparisons: list[PostHocComparison]
    display: str = ""


class CorrelationResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    method: Literal["pearson", "spearman", "kendall"]
    coefficient: float = Field(..., ge=-1.0, le=1.0)
    p_value: float = Field(..., ge=0.0, le=1.0)
    n: int = Field(..., gt=1)
    ci_95: tuple[float, float] | None = None
    ci_method: str | None = None  # fisher_z / bootstrap / exact / asymptotic
    display: str = ""


class RegressionCoefficient(BaseModel):
    """Single coefficient row in a regression result (Phase 1.3)."""

    model_config = ConfigDict(extra="forbid")

    name: str
    estimate: float
    std_error: float
    ci_low: float
    ci_high: float
    p_value: float = Field(..., ge=0.0, le=1.0)
    or_or_irr: float | None = Field(
        default=None,
        description="OR for logistic, IRR for Poisson/NB. None for non-exponentiated coefs.",
    )


class RegressionResult(BaseModel):
    """Logistic / Poisson / Negative Binomial / Firth-logistic (Phase 1.3)."""

    model_config = ConfigDict(extra="forbid")

    test_name: str
    model_kind: Literal[
        "ancova", "ols",
        "logistic", "poisson", "negative_binomial", "firth_logistic", "cox"
    ]
    coefficients: list[RegressionCoefficient]
    n_analyzed: int = Field(..., gt=0)
    n_events: int | None = Field(
        default=None,
        description="Number of positive outcomes (binary endpoint only).",
    )
    epv: float | None = Field(
        default=None,
        description="Events per variable. RF-6 input. None for non-binary outcomes.",
    )
    aic: float | None = None
    overdispersion_phi: float | None = Field(
        default=None,
        description="Pearson chi-square / df.residual. Poisson only — RF for severe.",
    )
    converged: bool = True
    diagnostics: dict[str, float] = Field(default_factory=dict)
    display: str = ""


class SurvivalKMResult(BaseModel):
    """Kaplan-Meier estimator (Phase 1.4)."""

    model_config = ConfigDict(extra="forbid")

    test_name: str = "kaplan_meier"
    median_survival: dict[str, float | None] = Field(
        default_factory=dict,
        description="group label → median survival time (None if not reached).",
    )
    survival_at_timepoints: dict[str, dict[str, float]] = Field(
        default_factory=dict,
        description='group label → {str(time): S(time)}. Keys stringified for JSON.',
    )
    n_per_group: dict[str, int] = Field(default_factory=dict)
    n_events_per_group: dict[str, int] = Field(default_factory=dict)
    figure_path: str | None = None
    time_unit: str = "time"
    display: str = ""


class LogRankResult(BaseModel):
    """Two-or-more group log-rank test (Phase 1.4)."""

    model_config = ConfigDict(extra="forbid")

    test_name: str = "log_rank"
    statistic: float
    p_value: float = Field(..., ge=0.0, le=1.0)
    df: int = Field(..., ge=1)
    n_total: int = Field(..., gt=0)
    n_events_total: int = Field(..., ge=0)
    n_per_group: dict[str, int] = Field(default_factory=dict)
    display: str = ""


class SchoenfeldResult(BaseModel):
    """Actual PH score test: KM-left/Efron, with a validated R cox.zph check."""

    model_config = ConfigDict(extra="forbid")

    test_name: str = "schoenfeld_ph"
    per_predictor_p: dict[str, float] = Field(
        default_factory=dict,
        description="encoded coefficient name → actual PH score-test p-value (R terms=FALSE).",
    )
    global_chi2: float
    global_df: int = Field(..., ge=1)
    global_p: float = Field(..., ge=0.0, le=1.0)
    ph_alpha: float = 0.05
    ph_violation: bool = False
    figure_path: str | None = None
    display: str = ""


__all__ = [
    "TwoGroupContinuousResult",
    "CategoricalResult",
    "MultiGroupResult",
    "PostHocComparison",
    "PostHocResult",
    "CorrelationResult",
    "RegressionCoefficient",
    "RegressionResult",
    "SurvivalKMResult",
    "LogRankResult",
    "SchoenfeldResult",
]
