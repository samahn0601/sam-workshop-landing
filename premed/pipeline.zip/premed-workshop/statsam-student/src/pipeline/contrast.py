"""Phase 5.1+ — reference level handling shared by the regression engines.

Both lifelines and patsy pick the baseline category by sort order. That is a
library detail, not a clinical decision, and it silently flips the reported
direction when arms are named "Antipyretic"/"Control" or
"Multidisciplinary"/"Usual care". Every engine that reports a contrast against
a reference level routes through here so the SAP-declared reference is what
actually gets used.
"""

from __future__ import annotations

import pandas as pd
import re


def validate_model_contrast(data: pd.DataFrame, formula: str, treatment_var: str) -> None:
    rhs = formula.split("~", 1)[-1]
    terms = re.findall(r"\b[A-Za-z_]\w*\b", rhs)
    if treatment_var not in data.columns or treatment_var not in terms:
        raise ValueError(f"Comparison {treatment_var!r} must exist in both the data and the model formula; an unrelated covariate cannot substitute for it.")


def apply_reference_level(
    data: pd.DataFrame, var: str, reference_level: str | None
) -> pd.DataFrame:
    """Reorder a categorical column so `reference_level` becomes the baseline.

    Both pandas' `get_dummies(drop_first=True)` and patsy drop the first
    category, so putting the declared reference first is what makes the
    estimate read as "comparison vs reference".

    Returns the frame unchanged when no reference is declared, which keeps
    SAPs locked before Phase 5.1 working exactly as before.
    """
    if reference_level is None:
        return data
    if var not in data.columns:
        raise ValueError(f"Declared comparison column {var!r} is missing; check the SAP column mapping.")
    levels = list(pd.unique(data[var].dropna()))
    if reference_level not in levels:
        matches = [level for level in levels if str(level) == str(reference_level)]
        if not matches and pd.api.types.is_numeric_dtype(data[var]):
            try:
                matches = [level for level in levels if level == float(reference_level)]
            except ValueError:
                pass
        if len(matches) == 1:
            reference_level = matches[0]
    if reference_level not in levels:
        raise ValueError(
            f"reference_level {reference_level!r} not present in column {var!r}. "
            f"Observed levels: {sorted(map(str, levels))}"
        )
    ordered = [
        reference_level,
        *[lv for lv in sorted(levels, key=str) if lv != reference_level],
    ]
    out = data.copy()
    out[var] = pd.Categorical(out[var], categories=ordered, ordered=False)
    return out


def resolve_contrast_coefficient(
    param_names: list[str], treatment_var: str
) -> str | None:
    """Return the fitted coefficient that carries the treatment contrast.

    A numeric arm column yields a coefficient named exactly `treatment_var`.
    A categorical one yields an encoded name — `group[T.Multidisciplinary]`
    from patsy, `group_Multidisciplinary` from `get_dummies` — so an exact
    match alone fails on precisely the columns most likely to be mislabelled.

    Returns None when nothing matches, leaving the caller to raise with its
    own message rather than guessing at a coefficient.
    """
    if treatment_var in param_names:
        return treatment_var
    encoded = [
        name
        for name in param_names
        if name.startswith(f"{treatment_var}[") or name.startswith(f"{treatment_var}_")
    ]
    encoded = [name for name in encoded if ':' not in name]
    if len(encoded) > 1:
        raise ValueError(f"Comparison {treatment_var!r} has multiple coefficients. Specify a supported two-level contrast in the SAP before analysis.")
    return encoded[0] if encoded else None


def select_contrast(coefficients, treatment_var: str):
    """Select exactly one fitted contrast; never substitute another covariate."""
    name = resolve_contrast_coefficient([c.name for c in coefficients], treatment_var)
    if name is None:
        raise ValueError(f"Comparison {treatment_var!r} is absent from the fitted model; check the SAP formula and group column.")
    return next(c for c in coefficients if c.name == name)


def ordered_groups(data: pd.DataFrame, group_var: str, reference_level: str | None):
    prepared = apply_reference_level(data, group_var, reference_level)
    if reference_level is not None:
        return list(prepared[group_var].cat.categories)
    return sorted(prepared[group_var].dropna().unique().tolist())


def contrast_label(coefficient_name: str, treatment_var: str) -> str:
    """Strip the encoding noise off a coefficient name for display.

    `group[T.Multidisciplinary]` and `group_Multidisciplinary` both become
    `Multidisciplinary`, which is what a reader needs to see next to the
    estimate.
    """
    name = coefficient_name
    if name.startswith(f"{treatment_var}[T.") and name.endswith("]"):
        return name[len(treatment_var) + 3 : -1]
    if name.startswith(f"{treatment_var}["):
        return name[len(treatment_var) + 1 : -1]
    if name.startswith(f"{treatment_var}_"):
        return name[len(treatment_var) + 1 :]
    return name
