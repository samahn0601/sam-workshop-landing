"""One strict CSV reader for upload, reopen, preflight, and analysis.

The raw file is never rewritten. CP949 must be explicitly selected; decoding
errors never trigger a fallback that could silently change variable names.
"""

from __future__ import annotations

import codecs
import csv
import hashlib
import io
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

import pandas as pd

CsvEncoding = Literal["utf-8", "utf-8-sig", "cp949"]
CSV_ENCODINGS: tuple[CsvEncoding, ...] = ("utf-8", "utf-8-sig", "cp949")


@dataclass(frozen=True)
class CsvInput:
    dataframe: pd.DataFrame
    encoding: CsvEncoding
    data_sha256: str


def sap_csv_encoding(sap) -> CsvEncoding | None:
    spec = getattr(sap, "data_spec", None)
    return getattr(spec, "csv_encoding", None)


def read_csv_input(source: str | Path | bytes, *, encoding: CsvEncoding | None = None) -> CsvInput:
    """Read UTF-8 (with/without BOM) or explicitly requested CP949.

    Pandas' established type/missing-value parsing is retained. Invalid bytes,
    duplicate/empty headers, and inconsistent row widths fail before parsing;
    pandas must not repair a header or infer an index from extra fields.
    """
    if encoding is not None and encoding not in CSV_ENCODINGS:
        raise ValueError("CSV 인코딩은 utf-8, utf-8-sig, cp949 중에서 선택하세요.")
    raw = source if isinstance(source, bytes) else Path(source).read_bytes()
    selected = encoding or "utf-8"
    if raw.startswith(codecs.BOM_UTF8):
        if selected == "cp949":
            raise ValueError("UTF-8 BOM이 있는 CSV입니다. UTF-8 인코딩을 선택하세요.")
        selected = "utf-8-sig"
    try:
        decoded = raw.decode(selected, errors="strict")
    except UnicodeDecodeError as exc:
        # Do not put original bytes or research values in the error message.
        raise ValueError(
            f"CSV를 {selected}로 읽을 수 없습니다. 파일 인코딩을 확인하고 "
            "UTF-8 또는 CP949를 명시적으로 선택하세요."
        ) from exc
    if "\x00" in decoded:
        raise ValueError("CSV에 NUL 문자가 있습니다. UTF-8 또는 CP949 CSV로 저장하세요.")
    try:
        rows = csv.reader(io.StringIO(decoded, newline=""), strict=True)
        header = next((row for row in rows if row), None)
        if not header:
            raise ValueError("CSV에는 헤더와 최소 한 행의 데이터가 필요합니다.")
        if any(not name.strip() for name in header):
            raise ValueError("CSV에 이름이 없는 열이 있습니다. 원본의 열 이름을 확인하세요.")
        if len(set(header)) != len(header):
            raise ValueError("CSV에 중복 열 이름이 있습니다. 원본의 열 이름을 확인하세요.")
        for row in rows:
            if row and len(row) != len(header):
                raise ValueError(f"CSV {rows.line_num}번째 줄의 열 수가 헤더와 다릅니다.")
    except csv.Error as exc:
        raise ValueError("CSV의 따옴표 또는 행 구분 형식이 올바르지 않습니다.") from exc
    data = pd.read_csv(io.StringIO(decoded))
    if data.empty or not len(data.columns):
        raise ValueError("CSV에는 헤더와 최소 한 행의 데이터가 필요합니다.")
    digest = "sha256:" + hashlib.sha256(raw).hexdigest()
    data.attrs["csv_encoding"] = selected
    data.attrs["data_sha256"] = digest
    return CsvInput(data, selected, digest)
