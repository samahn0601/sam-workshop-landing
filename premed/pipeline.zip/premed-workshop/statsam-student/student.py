"""Local student workflow. Raw data never printed or transmitted by this program."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import platform
import re
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
APPROVAL = '이 질문과 분석계획을 읽고 승인합니다'

class Hold(Exception):
    pass

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def save(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')

def code_hash():
    paths = sorted([ROOT/'student.py', ROOT/'requirements.txt'] + list((ROOT/'src').rglob('*.py')) + list((ROOT/'analysis').rglob('*.py')))
    h = hashlib.sha256()
    for p in paths:
        h.update(p.relative_to(ROOT).as_posix().encode())
        h.update(p.read_bytes())
    return h.hexdigest()

def audit(study, event, **details):
    p = study/'audit.jsonl'
    previous = p.read_bytes() if p.exists() else b''
    record = {'utc': datetime.now(timezone.utc).isoformat(), 'event': event,
              'prior_log_sha256': hashlib.sha256(previous).hexdigest(), **details}
    with p.open('a', encoding='utf-8') as f:
        f.write(json.dumps(record, ensure_ascii=False, allow_nan=False)+'\n')

def inspect(data_path, dictionary_path):
    from src.pipeline.csv_input import read_csv_input
    import numpy as np
    dictionary = read_json(dictionary_path)
    if dictionary.get('data_kind') not in ('synthetic', 'authorized_anonymized'):
        raise Hold('DATA_KIND: synthetic 또는 authorized_anonymized 선언이 필요합니다.')
    if dictionary.get('data_kind') == 'authorized_anonymized':
        required = ['authorized_local_analysis', 'no_direct_identifiers', 'one_row_per_independent_person']
        if not all(dictionary.get('attestations', {}).get(k) is True for k in required):
            raise Hold('AUTHORIZATION: 담당자 확인과 비식별·독립성 선언이 필요합니다. 선언은 검증 인증이 아닙니다.')
    if dictionary.get('design') != 'independent_two_group':
        raise Hold('DESIGN: 짝지음·반복·군집·생존·다군 설계는 이 실습본에서 지원하지 않습니다.')
    columns = dictionary.get('columns', {})
    forbidden = re.compile(r'(?:name|email|phone|address|birth|dob|mrn|patient|resident|이름|성명|전화|주소|생년|주민|등록번호)',re.I)
    if any(forbidden.search(str(name)) for name in columns):
        raise Hold('IDENTIFIER: 직접식별자로 보이는 열 이름은 허용하지 않습니다. 비식별 코드를 사용하세요.')
    roles = {role: [k for k,v in columns.items() if v.get('role') == role] for role in ['id','group','outcome']}
    if set(roles) != {'id','group','outcome'} or any(len(v) != 1 for v in roles.values()) or len(columns) != 3:
        raise Hold('SCHEMA: id/group/outcome 세 열을 각각 하나씩 정의하세요.')
    names = {role: vs[0] for role,vs in roles.items()}
    loaded = read_csv_input(data_path, encoding=dictionary.get('encoding', 'utf-8'))
    df = loaded.dataframe
    if set(df.columns) != set(columns):
        raise Hold('SCHEMA: CSV 열이 승인할 사전과 다릅니다. 추가 열을 자동 사용하지 않습니다.')
    if df.isna().any().any():
        raise Hold('MISSING: 결측값이 있습니다. 이 실습본은 삭제나 대치를 자동 수행하지 않습니다.')
    # Same check for synthetic and real declarations: a flag never bypasses identifier screening.
    ids = df[names['id']].astype(str)
    if not ids.map(lambda v:bool(re.fullmatch(r'(?:S[0-9]{2,8}|anon_[A-Za-z0-9_-]{2,24})',v))).all():
        raise Hold('IDENTIFIER: ID는 S01 형식 또는 anon_ 접두 비식별 코드만 허용합니다. 이름·이메일·전화번호는 금지합니다.')
    if df[names['id']].duplicated().any():
        raise Hold('DUPLICATE: ID 중복이 있습니다. 반복 측정 가능성을 확인하세요.')
    gs = columns[names['group']]
    levels = gs.get('levels', [])
    if len(levels) != 2 or len(set(levels)) != 2 or gs.get('reference') not in levels:
        raise Hold('GROUP: 서로 다른 두 군과 기준군을 명시하세요.')
    if set(df[names['group']].astype(str)) != set(levels):
        raise Hold('GROUP: 군 값이 데이터 사전의 두 군과 다릅니다.')
    # All scientific engines receive numeric outcome; conversion does not rewrite the CSV.
    try:
        df[names['outcome']] = df[names['outcome']].astype(float)
    except (ValueError, TypeError):
        raise Hold('TYPE: 결과변수는 연속형 숫자여야 합니다.') from None
    vals = df[names['outcome']]
    if not np.isfinite(vals).all():
        raise Hold('FINITE: 무한대 또는 비정상 숫자가 있습니다.')
    ospec = columns[names['outcome']]
    if ospec.get('type') != 'continuous' or not ospec.get('unit'):
        raise Hold('ENDPOINT: 연속형 결과변수와 단위를 명시하세요.')
    if 'min' in ospec and (vals < ospec['min']).any() or 'max' in ospec and (vals > ospec['max']).any():
        raise Hold('RANGE: 사전에 정의한 범위를 벗어난 값이 있습니다.')
    sizes = [int((df[names['group']].astype(str) == lv).sum()) for lv in levels]
    if min(sizes) < 5:
        raise Hold('SMALL_GROUP: 교육용 경계로 군별 최소 5명이 필요합니다. 일반 표본수 권고가 아닙니다.')
    metadata = {'data_kind': dictionary['data_kind'], 'rows': len(df), 'column_count': 3,
                'missing_count': 0, 'group_sizes_in_dictionary_order': sizes,
                'checks': 'schema/duplicate/finite/range/declared_design',
                'not_checked': ['real_world_independence', 'anonymization_guarantee', 'selection_bias', 'clinical_validity', 'power']}
    return df, dictionary, names, metadata

def prepare(args):
    study = Path(args.study).resolve()
    study.mkdir(parents=True, exist_ok=True)
    if (study/'plan.json').exists():
        raise Hold('EXISTS: 기존 계획이 있습니다. 새 연구 폴더를 사용하거나 기존 승인 이력을 검토하세요.')
    df, d, names, metadata = inspect(args.data, args.dictionary)
    if len(args.question.strip()) < 10:
        raise Hold('QUESTION: 대상·비교·결과를 담은 질문을 먼저 작성하세요.')
    plan = {'schema_version': 1, 'question': args.question.strip(),
            'data_path': str(Path(args.data).resolve()), 'dictionary_path': str(Path(args.dictionary).resolve()),
            'method': 'welch', 'alpha': 0.05, 'design': d['design'], 'columns': names,
            'reference': d['columns'][names['group']]['reference'],
            'missing_policy': 'hold', 'covariates': [], 'primary_endpoints': 1,
            'assumptions_reviewed_by_student': False,
            'assumptions_to_review': ['한 행은 한 사람이고 두 군은 독립적인가?',
                '결과는 연속형이고 극단값·분포가 평균 비교를 해석할 수 있게 하는가?',
                '짝지음·군집·보정이 필요한 연구가 아닌가?', '표본 선정과 인과 해석의 한계를 설명할 수 있는가?']}
    save(study/'plan.json', plan)
    save(study/'metadata.json', metadata)
    audit(study, 'PLAN_DRAFTED', data_sha256=digest(args.data), dictionary_sha256=digest(args.dictionary))
    print('PLAN_DRAFTED: 학생에게 질문·계획과 가정 확인을 보여주세요. 원자료 행은 출력하지 않았습니다.')

def validate_plan(plan):
    expected = {'method':'welch','alpha':0.05,'design':'independent_two_group',
                'missing_policy':'hold','covariates':[],'primary_endpoints':1}
    if any(plan.get(k) != v for k,v in expected.items()):
        raise Hold('UNSUPPORTED_PLAN: 지원하지 않는 계획을 자동 대체하지 않습니다.')
    if plan.get('assumptions_reviewed_by_student') is not True:
        raise Hold('ASSUMPTIONS: 학생이 가정과 설계를 검토한 뒤 승인하세요.')
    df,d,names,metadata = inspect(plan['data_path'], plan['dictionary_path'])
    if names != plan.get('columns') or d['columns'][names['group']]['reference'] != plan.get('reference'):
        raise Hold('PLAN_MAPPING: 사전과 계획의 변수·기준군이 다릅니다.')
    return df,d,names,metadata

def binding(study, plan):
    return {'plan_sha256': digest(study/'plan.json'), 'data_sha256': digest(plan['data_path']),
            'dictionary_sha256': digest(plan['dictionary_path']), 'code_sha256': code_hash()}

def approve(args):
    study = Path(args.study).resolve()
    plan = read_json(study/'plan.json')
    validate_plan(plan)
    if args.statement != APPROVAL or args.source not in ('author_direct', 'instructor_demo'):
        raise Hold('APPROVAL: 실제 학생의 직접 승인 문장을 받아 기록하세요.')
    if args.source == 'instructor_demo' and read_json(plan['dictionary_path'])['data_kind'] != 'synthetic':
        raise Hold('APPROVAL: 강사 데모 승인은 실제 자료에 사용할 수 없습니다.')
    if (study/'approval.json').exists():
        raise Hold('APPROVAL_EXISTS: 승인 기록은 덮어쓰지 않습니다. 새 연구 폴더를 사용하세요.')
    approval = {**binding(study, plan), 'source': args.source, 'status': 'AUTHOR_ATTESTED',
                'statement': args.statement, 'utc':datetime.now(timezone.utc).isoformat(),
                'identity_verification':'not_performed'}
    save(study/'approval.json', approval)
    audit(study, 'PLAN_APPROVED', **approval)
    print('PLAN_APPROVED: 해시 결속 완료. 신원·IRB·익명화 인증을 의미하지 않습니다.')

def formula_check(df, names, reference, result):
    from scipy.stats import t
    groups = sorted(df[names['group']].astype(str).unique())
    other = next(g for g in groups if g != reference)
    a = df.loc[df[names['group']].astype(str)==reference,names['outcome']].tolist()
    b = df.loc[df[names['group']].astype(str)==other,names['outcome']].tolist()
    va, vb = statistics.variance(a)/len(a), statistics.variance(b)/len(b)
    se = math.sqrt(va+vb)
    if se <= 0:
        raise Hold('VARIANCE: 군내 분산이 없어 계산할 수 없습니다.')
    dof = (va+vb)**2/(va**2/(len(a)-1)+vb**2/(len(b)-1))
    diff = statistics.mean(b)-statistics.mean(a)
    critical = float(t.ppf(.975,dof))
    manual = {'estimate':diff,'statistic':diff/se,'df':dof,
              'p_value':float(2*t.sf(abs(diff/se),dof)),
              'ci_low':diff-critical*se, 'ci_high':diff+critical*se}
    engine = {'estimate':result.estimate,'statistic':result.statistic,'df':result.df,
              'p_value':result.p_value,'ci_low':result.ci_95[0],'ci_high':result.ci_95[1]}
    if not all(math.isfinite(v) for v in engine.values()):
        raise Hold('FINITE_RESULT: 유한한 결과를 얻지 못했습니다.')
    errors = {k:abs(v-engine[k]) for k,v in manual.items()}
    if any(e>1e-9 for e in errors.values()):
        raise Hold('NUMERIC_CHECK: 별도 공식 계산과 엔진 결과가 일치하지 않습니다.')
    return {'status':'PYTHON_FORMULA_CHECKED', 'checked_fields':list(errors),
            'absolute_tolerance':1e-9,'absolute_errors':errors,
            'limitation':'같은 SciPy t 분포 함수를 사용함. R 또는 독립 라이브러리 교차검증 아님.'}, other

def run(args):
    from analysis.functions.run_t_test import run_t_test
    import numpy, pandas, scipy, pydantic
    study = Path(args.study).resolve()
    plan = read_json(study/'plan.json')
    if not (study/'approval.json').exists():
        raise Hold('APPROVAL_MISSING: 승인 전 계산하지 않습니다.')
    approval = read_json(study/'approval.json')
    expected = binding(study, plan)
    if any(approval.get(k)!=v for k,v in expected.items()):
        raise Hold('APPROVAL_STALE: 데이터·사전·계획·코드가 바뀌었습니다. 이전 승인으로 실행할 수 없습니다.')
    if (study/'result.json').exists():
        raise Hold('RESULT_EXISTS: 기존 계산·결과를 덮어쓰지 않습니다.')
    df,d,names,metadata = validate_plan(plan)
    try:
        result, prov = run_t_test(df,names['outcome'],group_var=names['group'],
            reference_level=plan['reference'],variant='welch',alpha=.05,data_path=plan['data_path'])
    except ValueError:
        raise Hold('ENGINE_INPUT: 엔진 입력 조건을 충족하지 못했습니다. 원자료 값은 출력하지 않습니다.') from None
    check, other = formula_check(df,names,plan['reference'],result)
    unit = d['columns'][names['outcome']]['unit']
    result = result.model_copy(update={'estimate_unit':unit})
    prov = prov.model_copy(update={'estimate_unit':unit,'comparison':f"{other} - {plan['reference']}",
                                  'code_commit':f"student-code-sha256:{expected['code_sha256']}"})
    save(study/'result.json',result.model_dump(mode='json'))
    prov.to_json(study/'provenance.json')
    save(study/'verification.json',check)
    environment = {'python':sys.version.split()[0], 'os':platform.system(),
        **{m.__name__:m.__version__ for m in [numpy,pandas,scipy,pydantic]}}
    save(study/'environment.json',environment)
    prefix = '합성 실습 데이터에서' if d['data_kind']=='synthetic' else '승인된 비식별 관찰자료에서'
    text = (f"{prefix} 총 {prov.n_analyzed}명의 {names['outcome']}를 두 독립 군으로 비교했다. "
        f"Welch t 검정의 평균 차이({other} − {plan['reference']})는 {result.estimate:.2f} {unit}으로 계산되었고, "
        f"95% 신뢰구간은 {result.ci_95[0]:.2f}~{result.ci_95[1]:.2f} {unit}, "
        f"p값은 {result.p_value:.4g}로 계산되었다. 이 결과만으로 인과효과나 임상적 의미를 판단할 수 없다.")
    (study/'RESULT_PARAGRAPH.md').write_text('# 수치 출처를 확인할 결과 문단\n\n'+text+
        '\n\n출처: result.json / provenance.json. 검산 범위: verification.json.\n'
        '학생 과제: 평균 차이의 방향, 신뢰구간, p값과 연구 설계의 한계를 자신의 말로 설명하세요.\n'
        '질문·변수·계획에 맞는 해석인지 학생이 검토해야 하며 자동 생성 문장은 제출 승인이 아닙니다.\n',encoding='utf-8')
    output_hashes = {p.name:digest(p) for p in study.iterdir() if p.name in
        ['result.json','provenance.json','verification.json','environment.json','RESULT_PARAGRAPH.md']}
    save(study/'manifest.json',{'status':'EDUCATIONAL_RESULT_REVIEW_REQUIRED','can_submit':False,
        **expected,'output_sha256':output_hashes,'verification_scope':check['status'],'environment':environment})
    audit(study,'COMPUTED',**expected,output_sha256=output_hashes)
    print('COMPUTED: result/provenance/verification/manifest/결과 문단이 생성되었습니다. 학생 해석 검토가 남아 있습니다.')

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command',required=True)
    p = sub.add_parser('prepare'); p.add_argument('--study',required=True); p.add_argument('--data',required=True)
    p.add_argument('--dictionary',required=True); p.add_argument('--question',required=True); p.set_defaults(handler=prepare)
    p = sub.add_parser('approve'); p.add_argument('--study',required=True); p.add_argument('--statement',required=True)
    p.add_argument('--source',choices=['author_direct','instructor_demo'],default='author_direct'); p.set_defaults(handler=approve)
    p = sub.add_parser('run'); p.add_argument('--study',required=True); p.set_defaults(handler=run)
    p = sub.add_parser('verify-result'); p.add_argument('--study',required=True); p.set_defaults(handler=verify_result)
    args = parser.parse_args()
    try:
        args.handler(args)
    except (Hold, ValueError, KeyError, FileNotFoundError) as exc:
        # Third-party error detail can contain cell values/paths: only our controlled HOLD messages are shown.
        reason = str(exc) if isinstance(exc,Hold) else 'INPUT_INVALID: 파일·JSON·CSV 형식을 확인하세요. 원자료는 출력하지 않습니다.'
        study = Path(args.study).resolve()
        if study.exists():
            audit(study,'HOLD',reason=reason)
            save(study/'hold.json',{'status':'HOLD','reason':reason,'can_submit':False})
        print('HOLD: '+reason)
        return 2
    return 0

def verify_result(args):
    study=Path(args.study).resolve()
    manifest=read_json(study/'manifest.json')
    expected=binding(study,read_json(study/'plan.json'))
    if any(manifest.get(k)!=v for k,v in expected.items()):
        raise Hold('RESULT_STALE: 현재 데이터·사전·계획·코드가 결과 기록과 다릅니다.')
    if manifest.get('can_submit') is not False:
        raise Hold('RESULT_STATUS: 제출 승인은 이 실습본의 출력이 아닙니다.')
    for name,hash_ in manifest['output_sha256'].items():
        if name not in ['result.json','provenance.json','verification.json','environment.json','RESULT_PARAGRAPH.md']:
            raise Hold('MANIFEST_SCHEMA: 알 수 없는 출력 경로가 있습니다.')
        if digest(study/name)!=hash_:
            raise Hold('OUTPUT_CHANGED: 계산 후 출력 파일이 바뀌었습니다. 수치 확인을 통과했다고 표시하지 않습니다.')
    prior=b''
    for line in (study/'audit.jsonl').read_bytes().splitlines(keepends=True):
        record=json.loads(line)
        if record.get('prior_log_sha256')!=hashlib.sha256(prior).hexdigest():
            raise Hold('AUDIT_CHANGED: 감사 로그 해시 연결이 다릅니다.')
        prior+=line
    print('INTEGRITY_CHECKED: 입력·계획·코드·출력·감사 로그 해시가 일치합니다. 과학적 타당성이나 인간 승인의 진위를 인증하지 않습니다.')

if __name__ == '__main__':
    raise SystemExit(main())
