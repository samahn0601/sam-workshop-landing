# Source provenance

Local snapshot: 2026-10-13.
Source repository: `StatSam` (local code snapshot; private folder path omitted).
Source HEAD: `7838537010a68ed69d08bce8aa2d2fbed0fcf941`. This is a working-tree snapshot; the hash below is the exact copied file authority.
License: MIT; full original notice retained in LICENSE.

The five actual source modules below are byte-identical. Student workflow, schema checks, formula verification, data and guides are new adaptations.
No patient data, existing studies, settings, credentials, .git, environments, caches or provider configuration were copied.

| Source file | SHA-256 |
|---|---|
| `analysis/functions/run_t_test.py` | `26273bd73674fb9f35049c13f58c53387e03f31dc02b922700269a3ad6b9f1cf` |
| `src/pipeline/provenance.py` | `8c0a76c9aac7a603e9c9d2730b452c2da0e338dc734abe3430aca10d473ab50d` |
| `src/pipeline/test_results.py` | `49ffd710376607f059ee5cadd230bb930ed53f7c24d5a37fc969eebcabb4bff2` |
| `src/pipeline/contrast.py` | `2afa6705d72c5b88efedd511a0a35897110ce50ac50fcddc9748bec279501ac5` |
| `src/pipeline/csv_input.py` | `e9cb40fe3dca6d8c58698d3c6d83dffef9771c5ac03c8c7e8934b59d9c234f92` |
| `LICENSE` | `00c49b8f51c168e3cfc80774250e6cd6986dcf617cd921cd1dc2030e9d4510b8` |

## Deliberate scope
Two independent groups, one continuous endpoint, Welch t-test, fixed alpha 0.05, explicit direction, no missing values.
Preserved: actual numeric engine, strict CSV reader, reference contrast, typed result, numeric provenance.
Adapted: smaller prerequisites and student approval/hash workflow; does not preserve full StatSam S1–S10/G1 state compatibility.
Excluded: dashboard, R bridge, Quarto/Word, imputation, regression, survival, journal submission and clinical recommendations.
Verification is Python formula comparison, not independent R validation or evidence of clinical validity.
No remote service is called by the included workflow. Installing Python/packages requires downloads; sending prompts to a desktop AI still sends prompt contents externally.
