# Instructor synthetic evidence

Read-only example calculated on Windows/Python 3.12.13. These files show numeric/provenance/hash evidence, not a student approval. Private host-specific plan paths and reusable approvals are excluded. Recompute your own study after setup. Formula check uses shared SciPy t distribution and is not R cross-validation.
