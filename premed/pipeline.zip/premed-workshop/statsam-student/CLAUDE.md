# StatSam Student — shared learning and computation rules

Read AGENTS.md. Both Codex and Claude Code desktop use the same folder, student checkpoints and local deterministic program.

AI proposes a question clarification and analysis plan. Student selects the question, reviews assumptions, explicitly approves the plan and explains the result. AI handles technical setup and execution. Do not complete these student judgments automatically.

Supported: one independent person per row, exactly two groups, one continuous outcome, Welch t-test, alpha .05, no missing values or adjustment. Plans outside that scope HOLD. Data/plan/dictionary/code changes invalidate approval. Approvals are assertions about human review, not authentication or ethical certification.

Use BOOTSTRAP.md to prepare the local Python 3.12 subset, run doctor and verify. Do not install full StatSam/R/Quarto or change app/model configuration for this exercise. Setup needs package-download connectivity. Computation itself calls no remote AI API.

An actual data file is read only by local code. Agent reads metadata/approved aggregate outputs and safe dictionaries only. Show no raw values. The student's question and plan prompt are sent to their selected desktop AI service; do not promise the AI conversation is offline.

Engine execution, formula comparison, student interpretation and real research validity are different things. Keep HOLD evidence, preserved original modules and MIT notice. This fork does not reproduce or claim full StatSam validation or state compatibility.
