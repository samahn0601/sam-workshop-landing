"""Explicit instructor synthetic example, never a substitute for student approval."""
import argparse, json, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
def main():
    p=argparse.ArgumentParser(); p.add_argument('--study',default=str(Path.home()/'.statsam-student'/'demo-study'))
    a=p.parse_args(); study=Path(a.study).resolve()
    def call(*args):
        subprocess.run([sys.executable,'-X','utf8',str(ROOT/'student.py'),*map(str,args)],check=True,cwd=ROOT)
    call('prepare','--study',study,'--data',ROOT/'data/synthetic_quiz.csv',
         '--dictionary',ROOT/'data/dictionary.json','--question','합성 학생 자료에서 guided 군과 control 군의 퀴즈 점수 평균은 다른가?')
    plan=json.loads((study/'plan.json').read_text(encoding='utf-8'))
    plan['assumptions_reviewed_by_student']=True
    plan['review_context']='instructor_demo: synthetic design supplied; not actual student approval'
    (study/'plan.json').write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    call('approve','--study',study,'--source','instructor_demo','--statement','이 질문과 분석계획을 읽고 승인합니다')
    call('run','--study',study)
    print('INSTRUCTOR_SYNTHETIC_DEMO: completed. Student must create and approve a separate study.')
if __name__=='__main__': main()
