# StatSam Student

의예과 초보자를 위한 실제 통계 계산 실습본입니다. 학생이 질문과 분석계획을 승인하면 StatSam의 원본 Welch t 검정 엔진으로 계산하고, 별도 공식과 출력 해시를 확인합니다.

**시작:** [START_HERE.md](START_HERE.md). 데스크톱 Codex/Claude Code에 폴더를 선택하고 첫 요청을 붙여넣습니다. 설치와 실행은 데스크톱 AI가 처리합니다.

- 지원: 두 독립 군, 한 연속 결과, Welch 검정, 합성 CSV 및 허용된 비식별 로컬 CSV.
- 결정: 학생 질문 → 계획·가정 검토 → 직접 승인 → 실제 계산 → 자신의 말로 결과 설명.
- 원본: 실제 코드 5개 모듈을 그대로 포함. MIT 고지와 SHA-256은 [SOURCE_PROVENANCE.md](SOURCE_PROVENANCE.md).
- 범위: 작은 교육용 통계 fork. 원본 StatSam 전체 S1–S10, R 검산, 저널 제출 기능을 포함하지 않습니다.
- 예제 수치: 합성 24명, guided−control +6.50점, 95% CI −1.74~14.74, p=.116. 실제 연구 결과가 아닙니다.

[BOOTSTRAP.md](BOOTSTRAP.md) · [ONE_SLIDE_SUMMARY.md](ONE_SLIDE_SUMMARY.md) · [VERIFICATION_REPORT.json](VERIFICATION_REPORT.json)
