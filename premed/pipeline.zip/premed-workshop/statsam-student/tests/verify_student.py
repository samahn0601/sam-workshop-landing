"""Concrete educational workflow checks; uses synthetic fixtures only."""
import argparse, csv, hashlib, io, json, math, shutil, sys, tempfile
from pathlib import Path
from types import SimpleNamespace as NS
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import student as s

def main():
    results=[]
    def check(name,fn):
        fn(); results.append({'name':name,'status':'PASS'})
    def holds(fn,code):
        try: fn()
        except s.Hold as e:
            assert str(e).startswith(code), (code,str(e)); return
        raise AssertionError('Expected HOLD '+code)
    with tempfile.TemporaryDirectory(prefix='statsam-student-verify-') as td:
        temp=Path(td)
        def fixture(name):
            folder=temp/name; folder.mkdir()
            shutil.copyfile(ROOT/'data/synthetic_quiz.csv',folder/'data.csv')
            shutil.copyfile(ROOT/'data/dictionary.json',folder/'dictionary.json')
            return folder
        def prepare(folder):
            s.prepare(NS(study=folder/'study',data=folder/'data.csv',dictionary=folder/'dictionary.json',
                         question='합성 두 독립 군의 퀴즈 점수 평균은 다른가?'))
        def approval(folder):
            study=folder/'study'; plan=s.read_json(study/'plan.json'); plan['assumptions_reviewed_by_student']=True
            s.save(study/'plan.json',plan)
            s.approve(NS(study=study,statement=s.APPROVAL,source='instructor_demo'))
        f=fixture('complete'); prepare(f); approval(f); s.run(NS(study=f/'study'))
        result=s.read_json(f/'study/result.json')
        check('actual_original_engine_expected_mean_difference',lambda:assert_close(result['estimate'],6.5))
        check('formula_check_six_numeric_fields',lambda:assert_true(len(s.read_json(f/'study/verification.json')['checked_fields'])==6))
        manifest=s.read_json(f/'study/manifest.json')
        check('output_hashes_match',lambda:assert_true(all(s.digest(f/'study'/name)==hash_ for name,hash_ in manifest['output_sha256'].items())))
        check('submission_not_approved',lambda:assert_true(manifest['can_submit'] is False))
        check('result_integrity_hashes_and_audit_chain',lambda:s.verify_result(NS(study=f/'study')))
        p=f/'study/RESULT_PARAGRAPH.md'; p.write_bytes(p.read_bytes()+b'edited')
        check('changed_output_hold',lambda:holds(lambda:s.verify_result(NS(study=f/'study')),'OUTPUT_CHANGED'))
        f=fixture('stale-code'); prepare(f); approval(f)
        original=s.code_hash
        try:
            s.code_hash=lambda:'0'*64
            check('stale_code_hold',lambda:holds(lambda:s.run(NS(study=f/'study')),'APPROVAL_STALE'))
        finally:s.code_hash=original
        n=fixture('no-approval'); prepare(n)
        check('no_approval_hold',lambda:holds(lambda:s.run(NS(study=n/'study')),'APPROVAL_MISSING'))
        check('assumptions_unreviewed_hold',lambda:holds(lambda:s.approve(NS(study=n/'study',statement=s.APPROVAL,source='instructor_demo')),'ASSUMPTIONS'))
        for kind in ['data','dictionary','plan']:
            f=fixture('stale-'+kind); prepare(f); approval(f)
            target = f/('data.csv' if kind=='data' else 'dictionary.json') if kind!='plan' else f/'study/plan.json'
            target.write_bytes(target.read_bytes()+b'\n')
            check('stale_'+kind+'_hold',lambda f=f:holds(lambda:s.run(NS(study=f/'study')),'APPROVAL_STALE'))
        def invalid(name,mutate,code):
            f=fixture(name); mutate(f)
            check(name,lambda:holds(lambda:s.inspect(f/'data.csv',f/'dictionary.json'),code))
        def csv_change(f,old,new):
            p=f/'data.csv'; p.write_text(p.read_text().replace(old,new),encoding='utf-8')
        def dict_change(f,change):
            p=f/'dictionary.json'; d=s.read_json(p); change(d); s.save(p,d)
        invalid('duplicate_id_hold',lambda f:csv_change(f,'S02,','S01,'),'DUPLICATE')
        invalid('missing_outcome_hold',lambda f:csv_change(f,',51',','),'MISSING')
        invalid('non_numeric_hold',lambda f:csv_change(f,',51',',text'),'TYPE')
        invalid('non_finite_hold',lambda f:csv_change(f,',51',',inf'),'FINITE')
        invalid('range_hold',lambda f:csv_change(f,',51',',101'),'RANGE')
        invalid('unsupported_design_hold',lambda f:dict_change(f,lambda d:d.update(design='paired')),'DESIGN')
        invalid('real_data_without_attestation_hold',lambda f:dict_change(f,lambda d:d.update(data_kind='authorized_anonymized')),'AUTHORIZATION')
        invalid('third_group_hold',lambda f:csv_change(f,'S01,control','S01,third'),'GROUP')
        invalid('obvious_name_in_identifier_hold',lambda f:csv_change(f,'S01,control','Kim,control'),'IDENTIFIER')
        invalid('synthetic_flag_does_not_bypass_email_hold',lambda f:csv_change(f,'S01,control','sam@example.com,control'),'IDENTIFIER')
        # Strict CSV reader must reject extra fields and duplicate headings before pandas can repair them.
        from src.pipeline.csv_input import read_csv_input
        for name,raw in [('duplicate_header',b'x,x\n1,2\n'),('wrong_width',b'x,y\n1,2,3\n')]:
            def bad_csv(raw=raw):
                try: read_csv_input(raw)
                except ValueError: return
                raise AssertionError('strict CSV should reject input')
            check(name+'_hold',bad_csv)
        f=fixture('authorized-synthetic-fixture')
        dict_change(f,lambda d:d.update(data_kind='authorized_anonymized',attestations={
            'authorized_local_analysis':True,'no_direct_identifiers':True,'one_row_per_independent_person':True}))
        prepare(f)
        check('instructor_demo_cannot_approve_real_declared_data',lambda:check_demo_real(f))
        s.approve(NS(study=f/'study',statement=s.APPROVAL,source='author_direct'))
        s.run(NS(study=f/'study'))
        check('authorized_anonymized_route_with_simulated_approval',lambda:s.verify_result(NS(study=f/'study')))
        check('source_module_hashes_unchanged',lambda:verify_sources())
    out={'status':'PASS','checks':results,'check_count':len(results),'data':'synthetic only',
         'limitations':['No new-device or macOS execution measured','No R differential test','Not clinical or educational efficacy validation']}
    parser=argparse.ArgumentParser(); parser.add_argument('--report'); args=parser.parse_args()
    if args.report: s.save(args.report,out)
    print(json.dumps(out,ensure_ascii=False,indent=2))

def assert_true(condition):
    assert condition
def assert_close(a,b):
    assert math.isclose(a,b,abs_tol=1e-10),(a,b)
def check_demo_real(f):
    p=f/'study/plan.json'; plan=s.read_json(p); plan['assumptions_reviewed_by_student']=True; s.save(p,plan)
    try:s.approve(NS(study=f/'study',statement=s.APPROVAL,source='instructor_demo'))
    except s.Hold as e:
        assert str(e).startswith('APPROVAL'); return
    raise AssertionError('demo approval accepted actual-declared data')
def verify_sources():
    for item in s.read_json(ROOT/'source_manifest.json')['files']:
        assert s.digest(ROOT/item['destination'])==item['sha256'],item['destination']
if __name__=='__main__': main()
