# Bootstrap verification — 2026-10-13

Measured on the instructor's Windows host after the final launcher change:

| Probe | Actual outcome |
|---|---|
| Invoke public bootstrap from a separate bare Python 3.13 venv | PASS |
| Existing uv on PATH | PASS (observed uv 0.11.32) |
| Hide all optional uv commands, install uv in home-owned tool venv | PASS (uv 0.13.0 installed and invoked) |
| Repeat setup without clearing existing statistical environment | PASS |
| Override inherited workspace UV Python/cache directories | PASS; effective paths under user home `.statsam-student` |
| doctor | Python 3.12.13; NumPy 2.3.5, pandas 2.3.3, SciPy 1.16.3, Pydantic 2.12.5 |
| verify | 27 concrete checks PASS, synthetic fixtures only |

The downloader's base Python 3.13 is an installation host. Actual numerical execution uses the fork's separate Python 3.12 environment. scientific dependencies, Python installation and caches are kept outside the selected package/sync folder.

This is same-host integration evidence. A brand-new device, macOS/Linux execution, all proxies/permissions, student completion and educational effect were not measured. The full workshop downloader's deployment and browser workflow are verified separately by its coordinator.
