"""Two-sample / paired t-test (Phase 1.2 implementation).

Variants:
- student : equal variance (`scipy.stats.ttest_ind(equal_var=True)`)
- welch   : unequal variance (default; medical research standard)
- paired  : paired-samples t-test (`scipy.stats.ttest_rel`)

Returns (TwoGroupContinuousResult, Provenance).
"""

from __future__ import annotations

import logging
from typing import Literal

import numpy as np
import pandas as pd
import scipy
import scipy.stats as ss
from pydantic import BaseModel, ConfigDict

from src.pipeline.provenance import (
    Provenance,
    current_git_commit,
    format_apa_effect_ci,
    format_apa_pvalue,
    sha256_file,
)
from src.pipeline.contrast import ordered_groups
from src.pipeline.test_results import TwoGroupContinuousResult

logger = logging.getLogger(__name__)


def _format_t_effect(label, estimate, ci_low, ci_high, p_value):
    # Storage always retains full precision. Avoid printing a nonzero small
    # endpoint/CI as zero when its units are small (e.g. concentrations).
    values = (estimate, ci_low, ci_high)
    if any(0 < abs(value) < 0.0005 for value in values):
        return (f"{label} {estimate:.4g}, 95% CI {ci_low:.4g} to {ci_high:.4g}, "
                f"p{format_apa_pvalue(p_value)}")
    return format_apa_effect_ci(label, estimate, ci_low, ci_high, p_value)


class TTestInput(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, extra="forbid")

    data: pd.DataFrame
    outcome_var: str
    group_var: str | None = None
    pre_var: str | None = None  # required when variant=paired
    variant: Literal["student", "welch", "paired"] = "welch"
    alpha: float = 0.05


def run_t_test(
    data: pd.DataFrame,
    outcome_var: str,
    *,
    group_var: str | None = None,
    reference_level: str | None = None,
    pre_var: str | None = None,
    variant: Literal["student", "welch", "paired"] = "welch",
    alpha: float = 0.05,
    data_path: str | None = None,
    result_id: str = "t_test",
    analysis_id: str = "A002",
) -> tuple[TwoGroupContinuousResult, Provenance]:
    """Run t-test family on a DataFrame column.

    Independent: provide `group_var` (must split data into exactly 2 groups).
    Paired: provide `pre_var` (pre-measurement column).
    """
    TTestInput(
        data=data, outcome_var=outcome_var, group_var=group_var,
        pre_var=pre_var, variant=variant, alpha=alpha,
    )

    n_total = int(len(data))

    if variant == "paired":
        if pre_var is None:
            raise ValueError("paired t-test requires pre_var (pre-measurement).")
        sub = data[[pre_var, outcome_var]].dropna()
        if not np.isfinite(sub.to_numpy(dtype=float)).all():
            raise ValueError("paired t-test requires finite observations.")
        n = int(len(sub))
        if n < 2:
            raise ValueError(f"paired t-test needs n>=2 complete pairs; got {n}.")
        diff = (sub[outcome_var] - sub[pre_var]).values
        stat, p = ss.ttest_rel(sub[outcome_var], sub[pre_var])
        mean_diff = float(np.mean(diff))
        sd_diff = float(np.std(diff, ddof=1))
        if sd_diff == 0:
            raise ValueError("paired t-test requires nonzero variance of differences.")
        df = n - 1
        se = sd_diff / np.sqrt(n) if n > 0 else float("nan")
        t_crit = ss.t.ppf(1 - alpha / 2, df)
        ci_low, ci_high = mean_diff - t_crit * se, mean_diff + t_crit * se

        result = TwoGroupContinuousResult(
            test_name="paired_t",
            statistic=float(stat),
            p_value=float(p),
            n_total=n_total,
            n_per_group={"paired": n},
            estimate=mean_diff,
            ci_95=(float(ci_low), float(ci_high)),
            df=float(df),
            paired=True,
            variant="paired",
            display=_format_t_effect(
                "paired mean difference",
                mean_diff, float(ci_low), float(ci_high), float(p),
            ) + f", t={float(stat):.3f}, df={df}, n={n}",
        )
        comparison = f"paired:{pre_var}_vs_{outcome_var}"
        n_analyzed = n
    else:
        if group_var is None:
            raise ValueError("Student/Welch t-test requires group_var.")
        sub = data[[group_var, outcome_var]].dropna()
        groups = ordered_groups(sub, group_var, reference_level)
        if len(groups) != 2:
            raise ValueError(
                f"t-test needs exactly 2 groups; got {len(groups)} in {group_var!r}."
            )
        g1, g2 = groups
        v1 = sub.loc[sub[group_var] == g1, outcome_var].values.astype(float)
        v2 = sub.loc[sub[group_var] == g2, outcome_var].values.astype(float)
        n1, n2 = len(v1), len(v2)
        if not np.isfinite(v1).all() or not np.isfinite(v2).all():
            raise ValueError("t-test requires finite observations.")
        if n1 < 2 or n2 < 2:
            raise ValueError(f"each group needs n>=2; got n1={n1}, n2={n2}.")
        sd1, sd2 = float(np.std(v1, ddof=1)), float(np.std(v2, ddof=1))
        if sd1 == 0 and sd2 == 0:
            raise ValueError("t-test requires nonzero within-group variance.")
        equal_var = variant == "student"
        stat, p = ss.ttest_ind(v2, v1, equal_var=equal_var)  # direction: g2 - g1
        diff = float(np.mean(v2) - np.mean(v1))

        if equal_var:
            sp = np.sqrt(((n1 - 1) * sd1**2 + (n2 - 1) * sd2**2) / (n1 + n2 - 2))
            se = sp * np.sqrt(1 / n1 + 1 / n2)
            df_val = float(n1 + n2 - 2)
        else:
            se = np.sqrt(sd1**2 / n1 + sd2**2 / n2)
            df_val = float(
                (sd1**2 / n1 + sd2**2 / n2) ** 2
                / ((sd1**2 / n1) ** 2 / (n1 - 1) + (sd2**2 / n2) ** 2 / (n2 - 1))
            )
        t_crit = ss.t.ppf(1 - alpha / 2, df_val)
        ci_low = diff - t_crit * se
        ci_high = diff + t_crit * se

        result = TwoGroupContinuousResult(
            test_name=f"t_test_{variant}",
            statistic=float(stat),
            p_value=float(p),
            n_total=n_total,
            n_per_group={str(g1): n1, str(g2): n2},
            estimate=diff,
            ci_95=(float(ci_low), float(ci_high)),
            df=df_val,
            paired=False,
            variant=variant,
            display=_format_t_effect(
                f"{variant} mean difference ({g2}-{g1})",
                diff, float(ci_low), float(ci_high), float(p),
            ) + f", t={float(stat):.3f}, df={df_val:.2f}, n={n1+n2}",
        )
        comparison = f"by:{group_var}"
        n_analyzed = n1 + n2

    input_hash = sha256_file(data_path) if data_path else _sha256_dataframe(data)
    prov = Provenance(
        result_id=result_id,
        analysis_id=analysis_id,
        endpoint=outcome_var,
        comparison=comparison,
        model="t_test",
        estimate=result.estimate or 0.0,
        estimate_unit="",
        n_analyzed=n_analyzed,
        ci_95=result.ci_95,
        p_value=result.p_value,
        missing_rule="complete_case",
        display=result.display,
        input_data_sha256=input_hash,
        code_commit=current_git_commit(),
        engine=f"Python:scipy=={scipy.__version__}",
    )
    logger.info("t-test result: %s", result.display)
    return result, prov


def _sha256_dataframe(df: pd.DataFrame) -> str:
    import hashlib

    h = hashlib.sha256()
    h.update(pd.util.hash_pandas_object(df, index=True).values.tobytes())
    return h.hexdigest()


__all__ = ["TTestInput", "run_t_test"]
