"""StatSam student educational subset."""
