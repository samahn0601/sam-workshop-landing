# Public package scope

Include source, guides, synthetic data, MIT license, source manifest, test script, verification report and `examples/` only. `examples/` is instructor synthetic evidence for reading; it is not a student study or reusable approval.

Exclude `instructor-evidence*/`, `__pycache__/`, `*.pyc`, local environment, real/student data, real study outputs and credentials. Instructor private run folders contain host-specific absolute plan paths; do not publish those folders.

Public ZIP and its SHA-256/bootstrap index are assembled by the workshop coordinator after content review. This folder itself has not been published by this worker.
