"""Desktop agent launcher; environments stay outside project/cloud-synced folders."""
import argparse, hashlib, importlib.util, json, os, platform, shutil, subprocess, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
KEY = hashlib.sha256(str(ROOT).encode()).hexdigest()[:12]
ENV = Path.home()/'.statsam-student'/'runtimes'/KEY
PY = ENV/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
LOCAL = Path.home()/'.statsam-student'
TOOL_ENV = LOCAL/'tools'/'uv-0.13.0'
TOOL_PY = TOOL_ENV/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
UV_ENV = {**os.environ, 'UV_PYTHON_INSTALL_DIR':str(LOCAL/'python'),
          'UV_CACHE_DIR':str(LOCAL/'cache'), 'UV_PYTHON_INSTALL_BIN':'0'}

def call(args):
    subprocess.run(list(map(str,args)), check=True, cwd=ROOT, env=UV_ENV)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('command',choices=['setup','doctor','demo','verify','student'])
    args, rest = p.parse_known_args()
    if args.command == 'setup':
        if shutil.which('uv'):
            uv = [shutil.which('uv')]
        else:
            # Works even when invoked from the downloader's bare venv; never pip --user there.
            if not TOOL_PY.exists():
                call([sys.executable,'-m','venv',TOOL_ENV])
            call([TOOL_PY,'-m','pip','install','uv==0.13.0'])
            uv = [str(TOOL_PY),'-m','uv']
        call(uv+['--version'])
        call(uv+['python','install','3.12','--no-bin'])
        if PY.exists():
            call([PY,'-c',"import sys; assert sys.version_info[:2] == (3,12), 'Unexpected existing statistical runtime; preserve it and review.'"])
        else:
            call(uv+['venv','--python','3.12',str(ENV)])
        call(uv+['pip','install','--python',str(PY),'-r',str(ROOT/'requirements.txt')])
        print('SETUP: Python 3.12 + pinned subset installed. Run doctor and verify next.')
    elif not PY.exists():
        print('SETUP_REQUIRED: desktop agent should run bootstrap.py setup first.'); return 2
    elif args.command == 'doctor':
        call([PY,'-X','utf8','-c',"import sys,numpy,pandas,scipy,pydantic; print({'python':sys.version.split()[0], **{m.__name__:m.__version__ for m in [numpy,pandas,scipy,pydantic]}})"])
    elif args.command in ['demo','verify']:
        script = 'demo.py' if args.command=='demo' else 'tests/verify_student.py'
        call([PY,'-X','utf8',ROOT/script,*rest])
    else:
        call([PY,'-X','utf8',ROOT/'student.py',*rest])
    return 0

if __name__=='__main__':
    try:
        raise SystemExit(main())
    except subprocess.CalledProcessError as exc:
        print(f'COMMAND_FAILED: exit={exc.returncode}; setup/verification is incomplete.'); raise SystemExit(exc.returncode)
