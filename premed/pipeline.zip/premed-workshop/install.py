"""Verified local ZIP installer; no provider calls or global package installation."""
import argparse, hashlib, json, os, re, stat, subprocess, sys, tempfile, zipfile
from pathlib import Path, PurePosixPath

def sha(data): return hashlib.sha256(data).hexdigest()
def validate(z):
    entries = z.infolist()
    if len(entries)>500 or sum(i.file_size for i in entries)>20_000_000: raise ValueError('Archive limits exceeded')
    seen=set()
    for i in entries:
        n=i.orig_filename; p=PurePosixPath(n); mode=i.external_attr>>16
        if not n.startswith('premed-workshop/') or '\\' in n or ':' in n or p.is_absolute() or '..' in p.parts or n.casefold() in seen:
            raise ValueError('Unsafe or duplicate archive path: '+n)
        if stat.S_ISLNK(mode) or (stat.S_IFMT(mode) not in {0,stat.S_IFREG,stat.S_IFDIR}): raise ValueError('Links/special files forbidden')
        if any(re.fullmatch(r'(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?',s,re.I) or s.endswith(('.', ' ')) for s in p.parts): raise ValueError('Unsafe Windows name')
        seen.add(n.casefold())
    manifest=json.loads(z.read('premed-workshop/PACKAGE_MANIFEST.json'))
    members={i.filename.removeprefix('premed-workshop/'):i for i in entries if not i.is_dir() and not i.filename.endswith('/PACKAGE_MANIFEST.json')}
    if set(members)!=set(manifest['files']): raise ValueError('Manifest file set mismatch')
    for name,i in members.items():
        if sha(z.read(i))!=manifest['files'][name]: raise ValueError('Package member changed: '+name)
    return manifest

def installed_ok(target,m):
    def ok(n,h):
        f=target/n
        return f.is_file() and f.resolve()==f.absolute() and not f.is_symlink() and sha(f.read_bytes())==h
    return all(ok(n,h) for n,h in m['files'].items())

def install(archive,workspace,expected):
    root=Path(workspace).resolve(strict=True)
    if not root.is_dir(): raise ValueError('Workspace root must already exist and be authorized in the desktop app')
    archive=Path(archive).resolve(strict=True)
    if sha(archive.read_bytes())!=expected: raise ValueError('ZIP SHA mismatch')
    target=root/'premed-workshop'
    with zipfile.ZipFile(archive) as z:
        manifest=validate(z)
        if target.exists() or target.is_symlink():
            if target.is_symlink() or target.resolve()!=target.absolute() or not installed_ok(target,manifest): raise ValueError('Existing child differs: preserved; inspect/status it, choose a NEW child workspace for reinstall')
            mode='RESUMED_EXISTING'
        else:
            with tempfile.TemporaryDirectory(prefix='.premed-install-',dir=root) as tmp:
                staged=Path(tmp)/'premed-workshop'; staged.mkdir()
                for i in z.infolist():
                    if i.is_dir(): continue
                    dest=Path(tmp)/i.filename
                    dest.parent.mkdir(parents=True,exist_ok=True)
                    with dest.open('xb') as f: f.write(z.read(i))
                if not installed_ok(staged,manifest): raise ValueError('Post-extraction verification failed')
                # Exclusive mkdir prevents POSIX rename from replacing an existing empty directory.
                target.mkdir(exist_ok=False)
                for child in staged.iterdir(): os.rename(child,target/child.name)
            mode='INSTALLED_NEW'
    for path in [target/'INSTALL_STATUS.json',target/'student-collab/workspace']:
        if path.is_symlink() or path.resolve()!=path.absolute(): raise ValueError('Managed readiness/workspace path is an alias; preserved')
    result=subprocess.run([sys.executable,'-X','utf8',str(target/'student-collab/pipeline.py'),'doctor'],capture_output=True,text=True,encoding='utf-8')
    if result.returncode: raise ValueError('Collab doctor failed: '+result.stderr+result.stdout)
    doctor=json.loads(result.stdout)
    if not all(doctor.get(k) is True for k in ['python_supported','write_read_korean','core_hashes_match','path_ok','folder_ok']): raise ValueError('Collab readiness failed')
    status={'status':'READY','mode':mode,'package_sha256':expected,'python_executable':sys.executable,'collab_ready':True,'statsam_ready':False,'submission_status':'NOT_SUBMITTED','folder':str(target)}
    (target/'INSTALL_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2),encoding='utf-8')
    return status

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--zip',required=True);a.add_argument('--workspace',required=True);a.add_argument('--sha256',required=True);x=a.parse_args()
    try:
        if sys.version_info<(3,11): raise ValueError('Host Python >=3.11 required')
        print(json.dumps(install(x.zip,x.workspace,x.sha256),ensure_ascii=False,indent=2))
    except (ValueError,OSError,zipfile.BadZipFile,KeyError) as e:
        print(json.dumps({'status':'HOLD','error':str(e)},ensure_ascii=False));sys.exit(2)
