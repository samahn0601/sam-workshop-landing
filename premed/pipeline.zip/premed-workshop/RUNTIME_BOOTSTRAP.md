# AI가 하는 설치 (학생에게 명령 실행을 요구하지 않음)

공개 파일은 prompt.md와 pipeline.zip 두 개. archive member는 `premed-workshop/install.py`이고 SHA는 instructor의 배포 manifest/prompt에 별도 고정한다. ZIP 전체 SHA 확인 후 이 exact member만 고유 임시 폴더로 스트리밍한다(Windows .NET ZipArchive; macOS unzip -p). installer 자체 SHA도 확인한다. 모든 ZIP member 검사는 install.py가 전체 추출 전에 수행한다.

Python >=3.11이 실제 실행되는지 `-c`로 확인한다. Windows Store alias/설치 팝업만 나타나는 명령은 사용 가능 판정이 아니다. Collab은 stdlib이므로 venv/ensurepip 없는 embedded Python도 실행 가능하다. 완전한 Python/venv는 선택적 StatSam이 별도 준비한다.

Python이 없으면 runtime.json의 플랫폼·아키텍처에 맞는 pinned uv0.13.0 공식 release asset을 내려받고 SHA 확인한다. uv를 실행하기 전에 archive 경로·symlink/special-file·size를 검사한다. agent는 이전 desktop-bootstrap의 검증 함수들을 재사용할 수 있다. runtime/cache는 home/.premed-workshop 아래; UV_PYTHON_INSTALL_BIN=0, UV_PYTHON_INSTALL_REGISTRY=0, UV_PYTHON_NO_REGISTRY=1. `uv python install 3.13 --no-bin --no-registry` (macOS는 --no-registry 생략 가능), `uv python find 3.13 --managed-python` 출력 경로를 사용한다. 영구 PATH/registry를 변경하지 않는다.

`HOST_PYTHON -X utf8 TEMP/install.py --zip LOCAL/pipeline.zip --workspace AUTHORIZED_CURRENT_ROOT --sha256 EXPECTED_ZIP_SHA`

installer는 전체 파일 검증 후 새 child를 exclusive 생성하고 전체 member SHA와 Collab doctor를 확인한다. 같은 배포본의 기존 child는 hash 검증 후 RESUMED_EXISTING으로 재검증하고 학생 workspace는 보존한다. 다른/손상된 기존 child는 HOLD이고 덮어쓰지 않는다. root 선택 승인과 AI의 새 child 폴더 생성은 다른 행동이다. 앱 승인 없는 상위/Downloads 전체 접근을 우회하지 않는다.

최종 INSTALL_STATUS.json의 READY는 Collab만. 실제 분석을 선택하면 statsam-student/bootstrap.py setup/doctor/verify까지 실행해야 StatSam 준비 완료다. uv가 PATH에 있으면 process-only PATH로 제공한다. 없어도 StatSam의 home-scoped uv bootstrap이 작동한다. 공유 host3.13과 science3.12는 의도적으로 분리된다.
