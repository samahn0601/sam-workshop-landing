# 파일 묶기 → 브라우저 투고 → 접수 확인

## 수업 연습

AI가 H1~H5 완료와 마지막 검토를 확인하고 finish.py package/verify를 실행한다. 브라우저 localhost 양식에 제목을 쓰고 submission-training/upload.zip을 선택한 뒤 최종 검토 체크와 연습 제출을 한다. 서버는 업로드한 실제 바이트의 SHA가 검토한 ZIP과 일치해야 접수증을 저장한다. 응답 화면의 TRAINING_SUBMITTED, receipt_id, 업로드 SHA와 로컬 TRAINING_RECEIPT.json을 비교한다. 연습 접수는 실제 저널 접수로 표시하지 않는다. 끝나면 AI가 자신이 시작한 서버만 종료한다.

## 실제 저널에서 별도 진행할 때

1. 공식 저널의 현재 author instructions와 article type 요구를 읽는다. 원문 URL·확인 날짜·버전·미확인 항목을 기록한다. 이 배포본의 기본 DOCX는 요구 형식을 자동 충족하지 않는다.
2. 실제 원고, title page/블라인드 원고, 표·그림, 보고 지침, AI 공개, 저자 체크리스트, cover letter를 저널 규정과 대조한다. 실제 저자 순서·공저자 동의·COI·IRB/동의·펀딩·독점 투고는 저자 사실 확인으로만 기입한다. 지불·서명·MFA가 필요하면 해당 인간이 한다.
3. 저자가 직접 허용한 portal 작업 범위를 기록한다. 현재 앱의 브라우저/컴퓨터 도구가 지원하는 파일 입력과 양식을 사용한다. 이름 지정된 Chrome/Edge/Aside를 보존한다. 로그인만으로 투고 완료라고 하지 않는다. 도구 미지원이면 작성 가능한 초안·파일 묶음을 제공하고 실제로 못 한 동작을 명시한다.
4. 마지막 실제 Submit 지시 범위에서 제출한다. 성공 화면, 접수번호, 저널, 제출 시각 및 실제 receipt/export를 확인하고 로컬에 저장한다. `actual-submission-record.json`에는 status, journal, submission_id, submitted_at, 실제 evidence 파일 상대경로/SHA, 저자 지시 원문, 관찰 경로와 미확인 사항을 기록한다. 기록은 AI의 접수 인증이 아니다.
5. 응답이 애매하면 status=SUBMISSION_UNKNOWN. 확인되지 않은 접수번호·시각·receipt를 쓰지 않고 portal 접수 목록부터 확인한다. 중복 재제출하지 않는다.

실제 receipt가 확인되면 PORTAL_RECEIPT_OBSERVED라고 기록할 수 있다. AUTHOR_ATTESTED와 직접 관찰을 분리한다. TRAINING_ receipt, ZIP 생성, 이메일 초안, 제출 버튼 클릭만으로 실제 SUBMITTED라고 쓰지 않는다.
