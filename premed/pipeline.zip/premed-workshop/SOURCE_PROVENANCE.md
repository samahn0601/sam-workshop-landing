# Distribution provenance

- Student Collab baseline ZIP: SHA256 3992148a83da01a089f6f2e18e31065ddc942a5111bd4c71a83cfd539da4ae23 (66,597 bytes). Source-derived teaching fork. Exact parent modules and hashes are student-collab/FORK_PROVENANCE.json. Parent owner authorized this educational distribution; no parent license grant is invented. No unrelated studies/state/tools are included.
- Optional StatSam baseline ZIP: SHA256 aeaff5ac93aa5b6e75dfca9ffd1de74ae1078afd822714f379b3a0bf41edec04 (44,372 bytes). Included 37-file curated subset; original computation/source files unchanged, START_HERE.md and BOOTSTRAP.md adjusted for the single bundle. full MIT license and original source hashes in statsam-student/LICENSE and SOURCE_PROVENANCE.md.
- New original extension: install.py, finish.py, root contracts, runtime guidance and parent capability audit. Student Collab core FIFO and ledger modules remain unchanged. Student pipeline H3 teachback uses whole-manuscript wording; no state schema/gate bypass. Agent/guide/prompts updated for automatic setup and full-manuscript scope; historical DECISIONS entries retained with extension overriding old paragraph scope.
- PACKAGE_MANIFEST.json records every current packaged member SHA. No absolute private host paths, provider credentials, original projects, cached environments or instructor fixture approvals are shipped. runtime.json carries public pinned runtime sources only.

Synthetic statistical results and test receipts are teaching results, not actual human-subject research or journal submission.
