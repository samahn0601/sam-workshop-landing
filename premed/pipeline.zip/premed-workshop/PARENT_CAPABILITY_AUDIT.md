# 부모 Collab과 학생 배포본의 범위 (2026-10-13)

읽은 활성 release/source commit: `2403b8d92fa823991dafdeba77e39117a1a3d126`. 원본·state는 수정하지 않았다. 이 파일은 정적 코드와 계약 감사이며 실제 저널 로그인/전송 테스트가 아니다.

| 과정 | 부모의 실제 부품/계약 | 이 학생 ZIP |
|---|---|---|
| 질문·검색·스토리·초안 ①~④ | Collab PIPELINE.md13~16, 오케스트레이터와 shared discovery | H1 질문, H2 공개 원문 근거, H3 전체 원고 초안과 미완료 항목; desktop AI가 실제 수행 |
| 검증·피드백·비평 ⑤~⑪ | typed fact/7-layer/critic evidence/H2~H4 및 재검증 | H4 실제 새 대화 비평과 학생 판단; 전수 7-layer/독립3엔진/통계 전체 기능 없음 |
| Figure·윤문 ⑪-b~⑫-b | image/figure 도구와 post-humanize checks | 학생 글 수정과 diff; 전문 Figure/내용 보존 자동 검증 없음 |
| 패키징 ⑬~⑬.5 | docx_builder build_submission_package, gate3_pre_evidence, packager.build/assemble_submit_ready, post_edit_gate | finish.py로 실제 기본 DOCX+Markdown+cover letter+공개문+체크리스트+파일 SHA/ZIP. 저널 특화형식·블라인드·reporting guideline 자동 검증 없음 |
| H5 인계 ⑭ | handoff.generate_final+last_5min_checklist, compliance/warn/unknown을 인간 검토 | H5 자기판단 + 마지막 실제 파일 검토, CLASSROOM_PACKAGE_REVIEWED/VERIFIED |
| Portal upload/Submit | AGENTS.md64: 실제 저자 지시 범위에서 앱 도구 사용. scripts에 범용 portal/computer driver 없음. H5 delegation36은 packaging review만 | localhost 실제 ZIP 업로드 + TRAINING_SUBMITTED 접수증. 실제 저널은 별도 직접 저자 지시+현재 앱 browser/computer 도구 필요 |
| 접수·리비전 | main orchestrator.record_submission2595: never uploads, 실제 receipt 결속; R&R CLI 별도 | 실제 접수 증거 기록 안내만. 실제 receipt 자동 인증·R&R parent state 이식 없음 |

parent orchestrator1153~1161의 allowed_actions upload/submit는 저자 override 허용 범위를 기록하는 코드이지 브라우저 조작 엔진이 아니다. CONSULTING.md16의 포털 대행 금지는 **부분서비스** 계약이며 Collab 저작 arm의 직접 저자 지시 계약과 구별한다. matrix의 packaging 기능은 advisory이므로 생성물 파일과 검증 evidence를 함께 확인해야 한다. 프로그램 exit0만으로 valid/SUBMIT_READY라고 하지 않는다.

부모 문서는 16-step과 ①~⑭ 표, 구현의 final_review 번호를 혼용한다. 이를 “학생 배포본이 부모 14/16단계를 모두 자동 실행한다”고 설명하지 않는다. 학생 state.schema student-collab/1은 별도 계약이며 부모 state로 자동 이전하지 않는다.

## 감사 시점 파일 SHA-256 (release 상대 경로)

- sam-ai-collab/AGENTS.md: c48867c2dcb4814204bd26c5ab9c0678a0364ed4f66271ae7326accf39a55142
- sam-ai-collab/CLAUDE.md: e8f3bdeea449be7c6e596433621394ec92e5a174545a5d96204f8f995918b518
- sam-ai-collab/PIPELINE.md: ef92bcccde771e4031750f93a32f927efb5172637dc0a14450c75008550704d0
- sam-ai-collab/CONSULTING.md: a43ed359216c5496ebcd287515bedd382c0e753e8e16f725d6ddd0aadcb3f787
- sam-ai-collab/scripts/orchestrator.py: 771638050ab6ed59e786430c784d2d52cfaf0745d3047e4b7a9e85118d3514f0
- sam-ai-collab/scripts/packaging_project.py: 85250122addba6879d297538fc4a2b1251e5ced6fc12788d13448549688f95a4
- shared/scripts/packager.py: 0152ac350065c2b5fb07cd9ddf558ed7dbd4232e4ad3d79403d9fd17174013af
- shared/capability_matrix.yaml: 24fac0915e749ae867a45bf22c47edcbde0df391f4a87442d14285864e271c5b

main sam-ai-collab/scripts/orchestrator.py snapshot SHA: 6acae39bc8158e7d20ce7a6e3181af8e011d37c3830780d188f089c7b5a8c648. Main has more receipt-binding code than the pinned release; do not claim main additions are active pinned runtime behavior.
