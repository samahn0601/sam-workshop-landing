# Desktop agent setup — Windows / macOS / Linux

이 문서는 **데스크톱 AI가 실행할 지침**입니다. 학생에게 설치 명령이나 압축 해제를 기본 과제로 넘기지 않습니다.

## 공개 허브에서 내려받는 경우

`/premed/desktop-bootstrap.json`의 `tracks.statsam` 항목에서 URL·SHA-256·크기를 확인합니다. `target_directory`는 `statsam-student`입니다. 학생이 제공하거나 허브가 표시한 공식 URL만 사용합니다. 파일을 새 프로젝트 폴더에 다운로드하고 SHA-256을 비교한 다음, ZIP 멤버에 절대경로·`..`·심볼릭 링크가 없는지 검사하여 안전하게 해제합니다. 기존 폴더를 덮어쓰지 않습니다. 허브의 해시 정보가 없거나 불일치하면 설치를 완료했다고 말하지 않습니다. 다운로드 파일은 별도로 보존합니다.

본 문서 작성 시 개별 ZIP/허브 URL의 게시·다운로드 검증은 별도 작업입니다. 설치된 이 폴더가 있으면 다운로드를 반복하지 않습니다.

## 도구 준비와 런처

1. 현재 운영체제와 작업 폴더를 확인합니다. 기존 Python 3.11 이상 또는 `python3`, `python`, Windows `py -3`를 확인합니다. 없으면 해당 OS의 승인된 설치 경로로 Python을 설치합니다. 사용자 개입이 실제로 필요한 OS 관리자 권한·로그인 문제만 짧게 알립니다.
2. Python으로 `bootstrap.py setup`을 실행합니다. 공통 다운로드 도구의 Python 3.13도 설치용 호스트로 사용할 수 있습니다. 런처는 PATH에 준비된 uv를 쓰며, 없다면 `$HOME/.statsam-student/tools/uv-0.13.0`의 별도 도구 환경에 설치합니다. 실제 통계 실행은 Python 3.12와 **requirements.txt의 고정된 과학 패키지 및 하위 의존성**을 `$HOME/.statsam-student/runtimes/<folder-hash>`에 준비해 사용합니다. Python 설치와 다운로드 캐시도 `$HOME/.statsam-student/python`, `$HOME/.statsam-student/cache`에 둡니다. 공통 도구가 넘긴 동기화 폴더 캐시 설정을 이어 쓰지 않습니다. 앱·전역 모델 설정은 바꾸지 않습니다.
3. `bootstrap.py doctor`, `bootstrap.py verify`를 실행하고 실제 버전과 테스트 결과를 확인합니다. 의존성 설치 성공만으로 실습 완료라고 하지 않습니다.
4. 강사 데모가 필요한 경우 `bootstrap.py demo --study <새 로컬 경로>`를 실행합니다. 기존 study는 덮어쓰지 않습니다.

RTK가 있는 경우의 예시(에이전트용):

```text
rtk proxy python3 -X utf8 bootstrap.py setup
rtk proxy python3 -X utf8 bootstrap.py doctor
rtk proxy python3 -X utf8 bootstrap.py verify
rtk proxy python3 -X utf8 bootstrap.py demo --study <new-local-demo-directory>
```

Python 실행파일 이름은 현재 OS에서 확인한 것으로 바꿉니다. RTK가 없는 배포 환경에서는 `rtk proxy`를 생략할 수 있으며 학생에게 RTK 설치를 요구하지 않습니다. 실제 오류를 읽고 패키지 다운로드·권한·프록시 문제를 구분합니다. Windows 실행이 확인되었다고 macOS/Linux 완료를 주장하지 않습니다.

## 학생 실습 실행

아래 명령은 학생이 입력할 예제가 아닙니다. AI가 학생의 실제 응답을 받은 후 실행합니다.

```text
bootstrap.py student prepare --study <new-local-study> --data <local-csv> --dictionary <safe-dictionary-json> --question <student-question>
bootstrap.py student approve --study <local-study> --source author_direct --statement <actual-direct-student-approval>
bootstrap.py student run --study <local-study>
bootstrap.py student verify-result --study <local-study>
```

prepare 후 plan.json을 학생에게 보여줍니다. 학생이 가정을 검토했다고 직접 확인한 뒤 `assumptions_reviewed_by_student`를 true로 기록하고, 학생이 직접 승인 문장을 말한 뒤 approve를 실행합니다. 승인 문장은 `이 질문과 분석계획을 읽고 승인합니다`입니다. 질문이나 승인 문장을 프로그램 예제에서 가져와 학생이 답한 것처럼 기록하지 않습니다.

실제 자료는 데이터 사전에서 `data_kind: authorized_anonymized`와 다음 세 선언이 true여야 합니다: `authorized_local_analysis`, `no_direct_identifiers`, `one_row_per_independent_person`. 선언자는 학생/자료 담당자이며 AI가 대신 판단하지 않습니다. 담당자가 허용한 로컬 데이터 경로를 사용하고 원자료는 에이전트 도구로 읽지 않습니다. synthetic→real 선언 변경은 실제 자료 허가를 만들지 않습니다.

데이터·계획·사전·코드 변경 시 원래 study를 보존하고 새 study에서 다시 승인합니다. run이 HOLD 또는 실패하면 통계 결과를 만들어 넣거나 예제 숫자로 대신하지 않습니다.
