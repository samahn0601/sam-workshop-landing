H4에서 내가 결정한 지적만 반영해 revision.md를 만들어줘. 새 주장·수치·인용이 생겼으면 어떤 근거 때문인지 표시해줘. 의미가 바뀐 부분은 내게 보여줘. 실제 수정 교환을 purpose=revision으로 기록하고 draft.md와 diff를 보여줘.

disclosure 명령으로 사용 공개 초안을 만들고 실제 로그와 내가 수행한 검토를 대조해 disclosure.md를 정리해줘. 기록하지 못한 사용이 있었는지도 확인해줘. 그다음 H5 review를 열어줘. 내가 판단을 저장했다고 말하면 decide --from-downloads로 반영하고, DONE이 되면 export해줘. 미완료이면 WORKSHOP_PARTIAL 그대로 내보내줘. 논문 제출은 하지 마.
