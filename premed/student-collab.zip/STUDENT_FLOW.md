# 내 논문 주제로 시작하는 Student Collab — 진행 흐름

학생은 브라우저로 **START_HERE.html**을 열어 따라 하면 됩니다. 이 문서는 같은 흐름을 글로 적은 것이며, 주 작업 에이전트도 함께 읽습니다.

## 폴더 하나에서 시작합니다

1. `student-collab.zip`을 모두 풀면 `student-collab` 폴더 하나가 생깁니다. 그 안에 `START_HERE.html`과 `pipeline.py`가 함께 보이면 맞는 폴더입니다. 다운로드 폴더처럼 짧은 위치에 풉니다. 반디집·7-Zip은 ‘여기에 풀기’ 대신 ‘student-collab\에 풀기’를 고릅니다. 깊은 폴더에 풀면 Windows 경로 길이 제한(260자) 때문에 init이 실패할 수 있습니다.
2. 이 폴더를 데스크톱 앱의 로컬 프로젝트로 연결합니다.
   - ChatGPT 구독: ChatGPT 데스크톱 앱의 Codex에서 프로젝트를 만들거나 폴더를 엽니다(Add folder). 권한은 Ask for approval로 시작합니다.
   - Claude 구독: Claude 데스크톱 앱의 Code 탭 → Local → Select folder. 권한은 Manual 또는 Accept edits로 시작합니다.
3. START_HERE.html의 **첫 요청 복사**로 `prompts/00-setup.md` 내용을 주 작업 대화에 붙입니다. Python 3.11 이상이 없으면 [공식 Python](https://www.python.org/downloads/)을 설치하고 앱을 다시 엽니다. Windows는 Python install manager를 설치한 뒤 터미널에서 python을 한 번 입력해 첫 런타임을 받고, macOS는 공식 설치 패키지를 씁니다. 학생이 코드를 작성할 필요는 없습니다.
4. 내 주제 한 문장, 오늘 고칠 범위, 파일 사용 권한, 앱에 보이는 모델 이름을 말합니다. 드래프트가 있으면 **허용된 사본만** 이 폴더의 `incoming/`에 넣고 파일명을 알려줍니다. 주제만 있어도 시작할 수 있습니다.

## 매 단계 같은 네 동작

1. **말하기:** START_HERE.html에서 단계별 문장을 복사해 주 작업 대화에 붙입니다. 예: `prompts/01-topic-or-draft.md를 읽고 H1을 진행해줘.`
2. **검토 화면:** 에이전트가 파일을 만들고 `review`를 실행하면 검토 화면이 기본 브라우저에 열립니다. 안 열리면 에이전트가 보여준 절대경로를 탐색기/Finder에서 엽니다.
3. **내 판단:** 결정·이유·이번 단계 개념 질문에 대한 내 설명·모르는 점을 **직접** 쓰고 **판단 저장**을 누릅니다. 파일은 다운로드 폴더에 생기며 옮기지 않아도 됩니다.
4. **돌아가기:** 주 작업 대화에 `판단 저장했어. 저장한 판단 파일을 decide로 반영하고 현재 단계를 보여줘.`를 붙입니다. 다음 단계와 다음에 붙일 문장이 표시됩니다.

저장이 안 되면 검토 화면의 **판단문 복사**를 눌러 같은 대화에 붙입니다. 버튼을 누르는 것만으로는 다음 단계가 열리지 않습니다. 길을 잃으면 `지금 어느 단계이고 다음에 무엇을 하면 되는지 알려줘.`라고 말합니다.

## AI에게 맡길 때

- **인지적 오프로딩**(cognitive offloading): 기억·계산·정리를 도구에 맡기는 것입니다. 흔하고 유용하지만, 배워야 할 과정까지 맡기면 이득이 사라집니다. 오늘은 단계 상태와 AI 사용 기록을 실행기가 맡고, 질문과 이유는 내가 먼저 말합니다.
- **지식 외주화**(knowledge outsourcing): 알아야 할 내용을 AI·검색에 두는 것입니다. 찾을 수 있다고 아는 것은 아닙니다. 검토 화면의 자기 설명과 마지막 60초 설명은 AI를 보지 않고 합니다.
- **인식적 외주화**(epistemic outsourcing): ‘인식적’은 무엇을 알고 믿을지에 관한 것이라는 뜻입니다. 무엇이 맞고 근거가 충분한지의 판단까지 AI에 넘기는 것을 말합니다. AI의 요약은 근거의 끝이 아니므로 원문을 확인하고, 지지·채택·기각의 결정과 이유는 검토 화면에서 내가 씁니다.

## 정상적으로 만들어지는 파일

`workspace/my-paper/` 아래 `scope.md` → `evidence.csv` → `draft.md` → `critic.md` → `revision.md` / `disclosure.md`.

`review/review.html`은 내가 판단하는 화면, `exchange/critic.html`은 H4 비평을 받아 오는 화면, `meta/reproducibility_ledger.jsonl`은 기록, `handoff/`는 가져갈 결과입니다. `state.json`을 직접 고치지 않습니다. 로컬 원본이나 개인정보가 섞이지 않았는지 확인한 뒤 파일을 공유합니다.

## 주제만 있다면

연구 질문 1개, 가능한 방법과 부족한 자료, 기본 근거 1개, 개요와 서론 한 문단이 목표입니다. 수행하지 않은 연구의 방법·결과를 과거형으로 만들지 않습니다. ‘아직 모름’이 남아도 정상입니다.

## 드래프트가 있다면

전체 논문 중 한 문단(한국어 5–8문장 또는 영어 150–250단어; 시간 여유가 있을 때 300–600단어)을 고릅니다. PDF/DOCX는 원본을 보존하고 선택 부분을 텍스트로 읽은 뒤 표·인용·OCR 누락을 대조합니다. 주장과 근거, 비평을 검토하고 수정본과 diff를 가져갑니다.

## H4 비평 받아 오기

H3를 마치면 `prompts/04-critic.md를 읽고 H4 비평 요청을 만들어줘.`라고 말합니다. **비평 화면**(exchange/critic.html)이 열립니다.

1. **요청 복사**를 누릅니다. 보낼 내용은 화면 아래에서 먼저 읽을 수 있습니다.
2. 화면이 안내하는 새 대화를 엽니다. 구독 1개면 같은 서비스에서 폴더가 연결되지 않은 새 대화, 2개면 다른 서비스의 새 대화입니다.
3. 요청을 붙여 보내고, 응답이 끝나면 응답 전체를 복사합니다.
4. 비평 화면에 서비스와 화면의 모델 이름을 고르고 응답 전체를 붙인 뒤 **비평 응답 저장**을 누릅니다.
5. 주 작업 대화에 `비평 응답 저장했어. critic-import로 가져오고 내 판단을 물어봐줘.`를 붙입니다. 중요한 지적 1–2개를 채택·기각·보류하고 이유를 말합니다.

비평 대화에는 주 폴더를 연결하지 않습니다. 응답을 받지 못했으면 H4는 미완료입니다. 비평 화면을 쓸 수 없으면 `prompts/07-return-critic.md` 양식에 실제 응답을 붙여 주 작업 대화에 보냅니다.

## 주 에이전트용 명령 지도

학생은 아래 명령을 외우지 않습니다. 에이전트가 doctor 단계에서 찾은 Python 실행 파일로 실행합니다.

```text
python3 -X utf8 pipeline.py doctor
python3 -X utf8 pipeline.py guide
python3 -X utf8 pipeline.py init my-paper --topic "내 질문" --writer ChatGPT --route single --rights own_authorized
python3 -X utf8 pipeline.py init draft-paper --topic "내 질문" --input "incoming/draft.docx" --writer Claude --route multi --rights own_authorized
python3 -X utf8 pipeline.py status my-paper
python3 -X utf8 pipeline.py review my-paper
python3 -X utf8 pipeline.py decide my-paper --from-downloads
python3 -X utf8 pipeline.py decide my-paper --file "판단 JSON 절대경로"
python3 -X utf8 pipeline.py open my-paper
python3 -X utf8 pipeline.py log-ai my-paper --tool ChatGPT --model "화면에 보인 모델명 또는 UNKNOWN" --purpose draft --prompt "workspace/my-paper/exchange/h3-prompt.txt" --response "workspace/my-paper/exchange/h3-response.txt" --scope "서론 한 문단"
python3 -X utf8 pipeline.py critic-pack my-paper
python3 -X utf8 pipeline.py critic-import my-paper --from-downloads
python3 -X utf8 pipeline.py refcheck my-paper --online
python3 -X utf8 pipeline.py disclosure my-paper
python3 -X utf8 pipeline.py export my-paper
```

Windows에서는 `python3` 대신 `py` 또는 `python`이 동작할 수 있습니다. `review`와 `critic-pack`은 화면을 기본 브라우저로 열려고 시도하며, 열지 못해도 절대경로를 출력합니다. 시험용으로 열지 않으려면 `--no-open`을 붙입니다.

본문 변경으로 이전 판단이 오래됐으면 `reopen my-paper --from H2 --reason "근거 변경"`처럼 가장 먼저 영향받은 단계를 엽니다. 두 구독 중 하나가 막히면 `route my-paper --mode single --reason "두 번째 서비스 이용 불가"`로 사실대로 바꿉니다. 그다음 판단 화면을 다시 생성합니다.

## 한 서비스 / 두 서비스

한 서비스면 같은 제공자의 새 대화에 비평 요청을 붙여 검토합니다. 이전 작성 대화를 넘기지 않아도 모델 학습의 공통 한계가 남습니다. 두 서비스면 다른 제공자를 비평에 씁니다. 다수결로 결론 내리지 않습니다. 본문·수치·원문 근거로 결정합니다. 주 프로젝트를 쓰는 에이전트는 항상 하나입니다.

## 설치 문제

앱 로그인은 되는데 파일이 안 바뀌면 일반 Chat 화면이 아닌 로컬 작업 경로인지 확인합니다. Code/Codex 메뉴·구독·OS 지원은 강사와 확인합니다. doctor의 path_ok가 false면 폴더 경로가 너무 깊은 것이므로 ZIP을 다운로드 폴더처럼 짧은 위치에 새로 풉니다. Git 요구가 표시될 때만 공식 Git 설치를 돕습니다. Python을 못 찾으면 앱을 완전히 종료한 뒤 다시 열어 새 대화에서 재확인합니다. 설치가 길어지면 짝의 성공한 환경에서 본인 판단을 수행하고, 내 컴퓨터는 `설치 미완료`로 남깁니다. 웹 대화만 한 것을 로컬 실행 성공으로 기록하지 않습니다.

## 165분 저장과 다음 시간

`prompts/06-resume-export.md를 읽고 지금 상태를 export해줘.`라고 말합니다. 완료면 WORKSHOP_REVIEWED, 도중이면 WORKSHOP_PARTIAL입니다. `handoff/`는 전달용입니다. 다음에 이어 하려면 **workspace/내-프로젝트 전체**를 보관하고 같은 폴더를 앱에서 열어 status부터 확인합니다. 설치가 안 된 기기를 설치 성공으로 표시하지 않습니다.
