# 미준비 참가자용 대안 주제

이 자료는 수업 진행용 예시이며 실제 연구 결과가 아닙니다.

관심 질문: 연구 초보자가 AI를 이용해 논문을 쓸 때, 저자 책임과 사용 공개를 어떻게 기록하면 좋을까?

오늘 범위: ICMJE의 저자 기준과 AI 사용 권고를 읽고, 책임과 공개를 설명하는 짧은 서론을 작성·비평·수정한다. 새로운 실험이나 설문을 수행했다고 쓰지 않는다.

출처 후보:
- https://www.icmje.org/recommendations/browse/roles-and-responsibilities/defining-the-role-of-authors-and-contributors.html
- https://www.icmje.org/recommendations/browse/artificial-intelligence/ai-use-by-authors.html

본인 주제나 권한이 확인된 드래프트가 있으면 그것을 우선 사용합니다.
