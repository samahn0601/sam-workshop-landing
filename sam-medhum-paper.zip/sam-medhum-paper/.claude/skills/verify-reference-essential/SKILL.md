---
name: verify-reference-essential
description: >
  Use this skill when a humanities/social-medicine manuscript (medical education
  or history of medicine) needs reference verification at the desk-rejection
  prevention level: source existence, metadata mismatch, ghost/orphan or
  footnote↔bibliography inconsistency, citation chimera, retracted papers, and
  paraphrase/quote fabrication (whether cited sources actually support nearby
  claims or themes). Verification is tiered by source type — modern scholarly
  literature (Chat Research / web), qualitative methodology canon (books), and
  primary/archival sources (human-verify, fail-closed). Trigger when user says
  "reference 검증", "인용 검증", "참고문헌 확인", "각주 확인", "사료 확인",
  "ghost citation", "retracted paper", "verify references", "citation hallucination",
  or operates in Step 5 Verify of the sam-medhum pipeline. Do not use for general
  literature search (use ②Research / Chat Research) or for full 7-Layer audit
  (use verify-7layer). Input: paper_home/04_draft/{manuscript.md} +
  paper_home/04_draft/{references.txt | bibliography.md | footnotes}. Output:
  paper_home/05_verify/{refcheck_refs.csv, refcheck_issues.md,
  r6_claim_support.jsonl, verification_certificate.md}. Pipeline position:
  sam-medhum Step 5 / Self-Gate B. Context: Claude single-engine (no external
  API); PubMed auto-path (ref_verify_pubmed.py) valid only for the P2 quantitative
  profile. Primary-source claims must NEVER be auto-PASSed. Everything traces to
  ②Research — no memory-cited references. Mandatory pass before Step 6 Critic.
  Trigger keywords: reference, 인용, 참고문헌, 각주, footnote, bibliography, DOI,
  사료, primary source, ghost, orphan, retracted, 철회, paraphrase, quote,
  citation chimera.
---

# verify-reference-essential (Step 5)

> **Reviewer는 원고에서 reference·각주·사료를 가장 먼저 본다.** 인문사회의학은 특히 출처 정확성과 사료 취급을 정밀 심사한다.
> **핵심 fail-closed 교리:** 모든 인용은 ②Research로 추적된다 — **메모리에서 인용 생성 금지.** "Claude가 DOI/사료가 맞다고 했다"는 검증이 아니다. 반드시 실제 출처(Crossref/카탈로그/아카이브/원문)에서 확인.

## 검증 차원 R1–R6 (파이프라인 공통 vocabulary — 재조율)

| Layer | 목적 | 인문사회의학 재조율 |
|---|---|---|
| **R1** 존재 | 출처가 실제 존재? | DOI resolve / 도서 카탈로그 / 아카이브 소장 확인 |
| **R2** 메타 정합 | title/authors/year/**edition**/journal 일치? | 논문=서지, 단행본=**판·쇄** 주의 |
| **R3** 구조 정합 | 본문 인용 ↔ 목록 상호 대응? | **번호형=bracket ghost/orphan · 각주형=각주↔bibliography 일관성** |
| **R4** Chimera | 서지는 실재하나 다른 저작 메타 혼입? | metadata diff |
| **R5** Retracted | 철회 논문 인용? | 저널 논문 한정(Crossref update-to/웹) — **단행본·1차 사료는 N/A** |
| **R6** Claim support | 인용 출처가 주장/주제를 실제 지원? | 현대문헌=원문/초록, 질적=인용↔주제, 사료=**1차 사료↔주장(인간확인)** |

## 소스 티어 → 검증 경로 (앵커의 3분기 모델) ★ 이 스킬의 중심

각 reference를 먼저 티어로 분류(triage)한 뒤, 티어별 경로로 검증한다. **분야 프로파일(P1/P2/P3)이 기본 경로를 정한다.**

| Tier | 무엇 | 검증 경로 | 자동화 수준 |
|---|---|---|---|
| **T1 현대 학술문헌** (P1·P2·P3 공통) | 저널 논문·최근 단행본·학위논문 | **Claude Chat Research / 웹**(KCI·RISS·DBpia·Google Scholar·Crossref) 반자동 확인 — **프롬프트 프로토콜, API 스크립트 아님(Claude 단독·키 불요)** | 반자동 |
| **T2 질적 방법론 정전** (주로 P1) | Clandinin & Connelly, Creswell, Braun & Clarke, Lincoln & Guba 등 — **단행본**(PubMed 부재 많음) | **Crossref(book DOI)/출판사 페이지/Google Books + 인간 확인** — 판·쇄·연도 오귀속 흔함 | 반자동 + 인간 |
| **T3 1차 사료·아카이브** (P3 의사학) | 사료·문서·신문·기록물·서한 | **자동 검증 불가 → 인간확인 fail-closed 체크리스트.** 조용한 PASS 금지 → `INCOMPLETE_EXTERNAL_CHECK` | **불가 (인간전용)** |
| **P2 PubMed 경로** (양적 의학교육) | PubMed 색인 논문 | `ref_verify_pubmed.py` R1–R6 자동(en-dash·fail-closed 인증서 지원) | 자동(스크립트) |

> **원칙:** PubMed 색인 논문(주로 P2, 일부 P1)은 스크립트로. 비색인 논문·국내문헌·단행본은 T1/T2 반자동. 1차 사료는 **절대 자동 통과 금지** — 사람이 원자료를 본다.

## 모드

| 모드 | 시간 | 범위 |
|---|---|---|
| `workshop-mini` | 30분 | 티어 분류 + 위험 상위 표본 검증 (T3는 전건 체크리스트) |
| `standard` | 60분 | 전건 R1–R4 + R6 위험 기반 |
| `deep-audit` | 120분+ | 전건 R6 + 원문/사료 원본 대조 |

기본 `workshop-mini`.

> **운영 맥락(2인·각자 Max)**: 이 fork 워크숍은 참가자 2인(의학교육·의사학), 각자 개인 Claude Max. 대규모 동시 호출 부하는 없음. **P2 PubMed 라이브 호출**만 NCBI 무키 3 req/s 제한을 받으나 2인 동시라도 대체로 여유. 429 지속 시 아래 **Degraded Mode**. (T1/T2/T3는 API 미사용 — rate limit 무관.)

## 입력

- `paper_home/04_draft/manuscript.md` — **workshop-mini는 `.md` 우선.** `.docx`만 있으면 먼저 `.md`로 변환(Claude가 수행, 원본 `.docx`는 읽기 전용 보존) 후 실행 — 변환 실패 시 R3·R6는 `INCOMPLETE`
- 참고문헌: `references.txt`/`.bib`(번호형) **또는** `bibliography.md` + 각주(각주형 — 의사학·일부 질적)

## 절차 (workshop-mini, 30분)

### Phase 0 (3분) — 소스 티어 분류 + 분야 경로 선택

1. `paper_profile.json`의 `discipline`(P1/P2/P3) 확인 → 기본 경로 결정.
2. 각 reference를 **T1/T2/T3**로 태깅 (한 원고에 혼재 가능: 예 P1 질적 논문 = T1 최근 논문 + T2 방법론 정전).
3. 인용 스타일 판별: **번호형 `[n]`** vs **각주형**(footnote) → R3 경로 분기.

### Phase 1 (2분) — Preflight

```bash
ls paper_home/04_draft/
# manuscript.md + (references.txt | bibliography.md) 확인 (paper_home이 안 보이면 위치부터 탐색)
```
- **P2 경로만** 추가: `python --version`(3.9+) + `${CLAUDE_SKILL_DIR}/../_shared/scripts/` 스크립트 존재 확인 + 연락 이메일(NCBI E-utilities `tool/email` 식별용 — 아래 Phase 2b에서 **이 값으로 치환**, 더미 예시 그대로 실행 금지).

### Phase 2 (10분) — R3 구조 정합 + R1/R2/R4/R5 존재·메타

#### Phase 2a — R3 구조 정합 (인용 스타일별 분기)

**번호형 `[n]` (P2 및 번호형 P1):** deterministic 백엔드 호출 —
```bash
python ${CLAUDE_SKILL_DIR}/../_shared/scripts/compliance_backend.py citation-integrity \
  --manuscript paper_home/04_draft/manuscript.md \
  --refs       paper_home/04_draft/references.txt
```
JSON 산출(예):
```json
{
  "name": "citation_reference_integrity", "status": "fail",
  "message": "본문 인용 [9] 있으나 ref list에 항목 없음 (ghost); ref list에 항목 [7] 있으나 본문 미인용 (orphan)",
  "evidence": {"cited_count": 8, "ref_count": 7, "ghost_citations": [9], "orphan_references": [7]},
  "workshop_grade": "Human review required"
}
```

**각주형(footnote — 의사학·일부 질적): 스크립트 미지원 → Claude 구조 검사.** `compliance_backend`는 `[n]` bracket 전용이라 각주엔 쓰지 않는다. 대신 아래를 Claude가 수행:
- **각주 ↔ bibliography 대응**: 모든 각주의 출처가 bibliography(참고문헌 목록)에 있는가(ghost 유사) / bibliography의 모든 항목이 최소 1개 각주에서 인용되는가(orphan 유사)
- **첫 인용(full form) vs 이후(short form / ibid. / op. cit.) 일관성**: `ibid.`가 직전 각주와 실제 동일 출처인가, short form이 앞선 full form과 매칭되는가
- **동일 저작 표기 흔들림**: 제목·연도·쪽수 불일치 탐지
- 결과를 `refcheck_issues.md` 상단에 prepend (LLM coach 동시 참조 input).

> 경로 규칙: 공유 스크립트는 이 스킬 폴더의 **형제 폴더 `_shared`** 에 있다 (`${CLAUDE_SKILL_DIR}` = 이 SKILL.md가 있는 폴더). 셸(특히 PowerShell)이 이 변수를 자동 확장하지 않을 수 있으므로 **Claude가 실제 절대경로로 치환해 실행**한다. 홈(`~`)·repo root·`sam-workshop` 우산 폴더 가정 금지.

#### Phase 2b — R1/R2/R4/R5 존재·메타·chimera·철회 (티어별)

**P2 PubMed 경로 (자동 스크립트 — 색인 논문):**
```bash
python ${CLAUDE_SKILL_DIR}/../_shared/scripts/ref_verify_pubmed.py \
  --manuscript paper_home/04_draft/manuscript.md \
  --references paper_home/04_draft/references.txt \
  --email <Phase 1에서 받은 이메일> \
  --r6-sample 8 \
  --out paper_home/05_verify/
```
산출: `refcheck_refs.csv`(R1–R5) · `refcheck_issues.md`(high/medium, R3 결과 상단 prepend) · `r6_claim_support.jsonl`(R6 대기) · `verification_certificate.md`(요약). NCBI 무키 3 req/s — 429 시 재시도 1회, 지속되면 **Degraded Mode**.

**T1 현대 학술문헌 (Chat Research 반자동 — 비색인 논문·국내문헌·최근 단행본):** API 스크립트가 아니라 **프롬프트 프로토콜**. 각 출처에 대해 Claude가 아래를 Chat Research/웹으로 확인하고 사람이 승인 —
```
[T1 현대문헌 확인 프로토콜 — Claude Chat Research]
대상: {서지 문자열}
1. 존재(R1): Crossref/Google Scholar/KCI/RISS/DBpia에서 동일 제목·저자·연도가 실재하는가? (DOI 있으면 doi.org resolve)
2. 메타 정합(R2): title·저자·연도·게재지가 원고 서지와 일치하는가? 불일치 필드 표기.
3. Chimera(R4): DOI/링크는 열리나 실제 저작이 서지와 다른가?
- 각 출처에 confidence(low/medium/high)와 확인에 쓴 출처 URL/DB를 명시.
- 확인 못 하면 "미확인 — ②Research 재조회 필요"로 남긴다 (기억으로 채우지 않는다).
```

**T2 질적 방법론 정전 (단행본):**
```
[T2 방법론 정전 확인 프로토콜]
대상: {단행본 서지 — 예: Braun & Clarke (2006) / Creswell (2013, 3rd ed) / Lincoln & Guba (1985)}
1. 존재·판(R1/R2): Crossref book DOI / 출판사 페이지 / Google Books에서 저자·제목·**판(edition)·연도** 확인. 판이 바뀌면 쪽수·연도 달라짐 — 오귀속 흔함.
2. 인간 확인 필수: 저자명 철자(Clandinin & Connelly), 쪽수 인용의 판 일치.
- Braun & Clarke 주제분석, Creswell 질적설계, Lincoln & Guba 신뢰성 4기준 등 정전은 판·연도 혼동이 잦으니 반드시 원서지 대조.
```

**T3 1차 사료·아카이브 (P3 — 자동 불가, fail-closed 인간확인 체크리스트):** 자동 검증을 **하지 않는다**(불가능). 대신 각 사료에 아래 체크리스트를 생성하고, 미완이면 certificate `INCOMPLETE_EXTERNAL_CHECK` — **절대 auto-PASS 금지**.
```markdown
## T3 1차 사료 인간확인 체크리스트 (사료별)
- [ ] 사료 실재·소장처 확인 (아카이브·도서관·컬렉션 명 + 청구기호/식별자)
- [ ] 원자료 직접 열람 또는 신뢰 가능한 영인·전사본 대조 (2차 재인용 아님)
- [ ] 인용 문구·날짜·인명이 원자료와 일치 (전사 오류 점검)
- [ ] 번역 사료면 원문-번역 대응 확인
- [ ] 이용 허가·저작권·아카이브 인용 형식 준수
- [ ] 상태: 확인완료 / **미확인(INCOMPLETE_EXTERNAL_CHECK)**
```

#### ⚠️ Degraded Mode — 스크립트/네트워크 실패 시 (fail-closed)

Python 미설치·스크립트 미발견·PubMed/Crossref timeout·429가 **재시도 1회 후에도** 지속되면, 디버깅에 3분 이상 쓰지 말고 즉시 전환:
1. **R3 로컬 가능분만 수행** (번호형 compliance_backend는 네트워크 불필요 / 각주형은 Claude 구조검사).
2. 위험 상위 **5개 출처만** doi.org·Crossref·Google Scholar·도서 카탈로그를 **직접 조회**해 R1·R2 수동 확인 (출처 화면 기준).
3. **certificate Status = `INCOMPLETE_EXTERNAL_CHECK`** 로 기록 — **PASS 금지.** (네트워크 장애는 원고 오류가 아니므로 FAIL도 아님 — 구분 기록.) Required next step에 "네트워크 회복 후 동일 명령 재실행" 명시.
4. **하지 않는 것**: 기억으로 DOI·메타·철회·**사료** 판정(검증 아님) / 의존성 자동 설치(pip install) / full text·아카이브 크롤링 / 원본 `.docx` 직접 수정.

→ 외부 검증이 미완이면 Self-Gate B를 통과할 수 없다. **"검증한 척"이 가장 위험하다.**

### Phase 3 (10분) — R6 Claim/Quote Support 검증 (Claude Phase)

`r6_claim_support.jsonl`(P2 스크립트 산출) 또는 Phase 2b에서 수집한 출처 내용을 Claude에 입력. 각 항목에 대해:
- 주장/주제 문장 vs 인용 출처(초록·원문·인용구·사료)를 비교
- verdict 5분류: **Supported / Partially supported / Not supported / Contradicted / Cannot judge from source**
  (refcheck.schema enum: supported / partially_supported / not_supported / contradicted / cannot_judge)
- evidence_span (출처에서 지원/모순 근거 문구) 인용
- recommended_action (keep | revise claim | replace citation | check full text/source)

```
CRITICAL:
- 출처 원문/초록만으로 확인 불가 → "Cannot judge from source"로 표시 (pass 처리 X)
- 강한 역사적 단정("최초의"/"유일한")·인구 통계·귀속 주장 → 2차 재인용·초록만으로 통과 절대 금지 (1차 출처/원문 확인)
- 질적 인용은 인터뷰 원자료(또는 원 출처)와 대조 — 맥락 왜곡·과잉일반화 점검
- "아마 맞다"고 판단해도 evidence_span이 없으면 pass X
```

산출 갱신: `r6_claim_support.jsonl`의 `verdict` 채움 + `r6_summary.md` 생성

### Phase 4 (5분) — Self-Gate B 결정

본인이:
- [ ] 모든 R1–R5 high severity 항목 결정 (수정/교체/제거)
- [ ] R6 "Not supported / Contradicted" 항목 → 본문 수정 또는 인용 교체
- [ ] R6 "Cannot judge" 항목 → 원문/사료 확인 follow-up 표시
- [ ] **T3 1차 사료 체크리스트 미완 항목 = INCOMPLETE — 본인이 원자료로 직접 확인**
- [ ] 강한 역사적 단정·귀속·통계 주장은 본인이 1차 출처로 통과 결정

→ verification_certificate.md 갱신: PASS / FAIL / **INCOMPLETE_EXTERNAL_CHECK** (외부·사료 검증 미완 — PASS 불가)

### Phase 5 (2분) — HITL emit

P2 스크립트는 자동으로 `events.jsonl` 갱신. T1/T2/T3 경로는 Claude가 emit(아래 표준).

## R6 위험 기반 샘플링 (인문사회의학 우선순위)

0순위 키워드/패턴으로 자동 우선순위(각 +1 risk_score, 점수 높은 순 N개):
1. **강한 단정** ("최초의", "유일한", "definitive", "gold standard")
2. **귀속/인과 주장** ("X가 Y를 야기", "A가 처음 도입")
3. **연도·인구·수치 주장** (역사적 통계, 척도 수치)
4. **1차 사료에 근거한 핵심 주장** (P3 — 항상 표본에 포함)
5. **질적 인용의 과잉일반화** (참여자 1인 발화를 집단 주장으로)
6. **AI가 새로 추가한 reference / 방법론 정전 오귀속**
7. **서지 metadata mismatch 의심**

## R6 Claude 의미 검증 프롬프트 (표준)

```
You are checking whether a cited source supports a paraphrased claim, theme, or
quotation in a humanities / social-medicine manuscript (medical education or
history of medicine).

Use only the supplied source text (abstract, excerpt, quotation, or primary-source
transcript). Do not use outside knowledge.

Classify the relationship as one of:
1. Supported
2. Partially supported
3. Not supported
4. Contradicted
5. Cannot judge from source

Check: population/context match, claim direction, magnitude/date/number,
attribution ("first/only"), whether the manuscript overstates the source,
and (for qualitative) whether a single participant quote is over-generalized.

Return JSON:
{ "claim_id":"...", "verdict":"...", "confidence":"low|medium|high",
  "evidence_span":"...", "problem":"...",
  "recommended_action":"keep|revise claim|replace citation|add citation|check full text" }

CRITICAL: If the source does not contain the information needed, set verdict to
"Cannot judge from source". Do not guess. Strong historical claims, attributions,
and population statistics must NEVER be marked Supported on secondary/abstract-only
evidence; they require the primary source or full text.
```

## Output 표준

### `verification_certificate.md`
```markdown
# Verification Certificate

- Status: PASS | FAIL | INCOMPLETE_EXTERNAL_CHECK
- Discipline: P1 | P2 | P3
- Total references: N  (T1: n1 / T2: n2 / T3: n3)
- R1–R5 high severity: N
- R3 구조 정합: (번호형 ghost/orphan) 또는 (각주↔bibliography) 결과
- T3 1차 사료: 확인완료 x / **미확인 y (>0 이면 INCOMPLETE_EXTERNAL_CHECK)**
- R6 sampled: N
- R6 verdict distribution: Supported X / Partially X / Not supported X / Contradicted X / Cannot judge X

## Required next step
1. R1-R5 high 항목 본인 결정
2. R6 Not supported/Contradicted 본문 수정
3. R6 Cannot judge → 원문/사료 확인 follow-up
4. T3 미확인 사료 원자료 직접 확인
5. Self-Gate B 통과 결정
```

## HITL Event Emit

P2 스크립트는 자동. T1/T2/T3는 Claude가 emit:
```json
{"ts":"...","paper_id":"...","step":5,"gate":"B_draft","event_type":"gate_pass","skill":"verify-reference-essential","engine":"claude","category":"reference_integrity","severity":2,"description":"P1: T1 12 refs Chat-Research confirmed, T2 3 canon books human-confirmed, R6 sampled 8"}
```
INCOMPLETE(사료 미확인 등)면 gate_pass가 아니라:
```json
{"event_type":"gate_fail","category":"reference_integrity","severity":4,"description":"P3: 5 primary sources INCOMPLETE_EXTERNAL_CHECK — human archival verify required","fixed":false}
```

## 결정적 vs LLM 분리 (가장 중요한 원칙)

| 검증 항목 | 도구 |
|---|---|
| DOI 실재 (T1) | Crossref/doi.org (결정적) — Claude 확인은 실제 조회 기준 |
| PubMed 색인 논문 (P2) | ref_verify_pubmed.py (결정적 스크립트) |
| 번호형 Ghost/Orphan (R3) | **compliance_backend.citation_reference_integrity (결정적, `[n]` 전용)** |
| 각주↔bibliography (R3) | Claude 구조 검사 (스크립트 미지원) |
| 단행본 존재·판 (T2) | Crossref book/출판사/Google Books + 인간 (결정적 조회) |
| **1차 사료 (T3)** | **인간 원자료 대조 (자동 불가 — INCOMPLETE 표면화)** |
| **Claim/Quote 의미 일치 (R6)** | **Claude semantic (LLM)** |

→ "Claude가 맞다고 했다"는 검증이 아니다. **실제 출처(Crossref/카탈로그/원문/아카이브)에서 확인하거나 사람이 원자료를 본다.** 메모리 인용은 전부 ②Research로 되돌려 확인.

## Self-Gate B 체크리스트

- [ ] **외부 검증 완결** — certificate가 `INCOMPLETE_EXTERNAL_CHECK`면 통과 불가 (재실행/사료 확인 후 재판정)
- [ ] 모든 R1–R5 high severity 처리
- [ ] R3 구조 정합(번호형 ghost/orphan 또는 각주↔bibliography) 0건 또는 수정 완료
- [ ] R6 Not supported / Contradicted 0건 (또는 본문 수정 완료)
- [ ] **T3 1차 사료 전건 인간 확인** (P3)
- [ ] 강한 역사적 단정·귀속·통계 주장 본인 1차 출처 확인
- [ ] verification_certificate.md PASS

## Floor (절대 위임 불가)

- **1차 사료(T3)에 근거한 주장의 통과 — 항상 본인** (자동/2차 재인용 통과 금지)
- **강한 역사적 단정·귀속("최초의"/"유일한")·인구 통계 주장** — 본인이 1차 출처/원문으로 확인
- **Retracted citation 발견 시** — 본인 결정 (제거 vs 교체 vs 유지+사유 명시)
- **방법론 정전(T2)의 판·쪽 인용** — 본인 확인 (오귀속 흔함)

## 자주 발생하는 함정

1. **DOI는 resolve되나 다른 저작** (chimera) — R4
2. **각주엔 있으나 bibliography 누락 / bibliography엔 있으나 각주 미인용** — R3 각주형
3. **`ibid.`/short form이 엉뚱한 출처를 가리킴** — R3 각주 일관성
4. **방법론 정전 판·연도 오귀속** (Creswell 3rd vs 4th, Braun & Clarke 연도) — T2
5. **1차 사료를 2차 재인용으로 대체하고 확인한 척** — T3 최악의 실패
6. **질적 인용 과잉일반화** (참여자 1인 발화 → 집단 주장) — R6
7. **국내문헌(KCI/RISS/DBpia)을 PubMed에서 못 찾았다고 없는 것으로 처리** — T1 경로로 확인

## 다음 단계

→ Self-Gate B 통과 → Step 6 Multi-Persona Critic (Claude 인-모델)
