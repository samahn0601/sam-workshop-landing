---
name: reporting-guideline-router
description: >
  Use this skill to identify which reporting guideline applies to a
  humanities/social-medicine study and verify the manuscript meets its required
  items. Routing keys off discipline + study design. For qualitative
  med-education (P1, default): COREQ (32-item, interviews/focus groups — primary
  for narrative-inquiry interview studies) or SRQR (21-item, general qualitative).
  For quantitative med-education (P2): STROBE / CONSORT / PRISMA / STARD / SQUIRE
  etc. For history of medicine (P3): NO formal reporting checklist exists — route
  honestly to the target journal's author guidelines + historiographic
  conventions (do not fabricate a checklist). Trigger when user says "reporting
  checklist", "COREQ SRQR", "STROBE", "보고지침", "study type 분류", "reporting
  guideline", or is auto-invoked by journal-fit-check / story-design /
  desk-reject-precheck. Do not use for journal style guides beyond routing (저자
  지침 원문은 공식 페이지에서 직접 확인). Input:
  paper_home/01_design/article_type.md + paper_home/.sam/hitl/paper_profile.json
  (discipline) + paper_home/04_draft/manuscript.md. Output:
  paper_home/08_package/reporting_checklist.md (+ checklist PDF when downloadable;
  P3 = journal author-guideline compliance note). Pipeline position: invoked by
  journal-fit-check (Step 1) for routing, by desk-reject-precheck (Step 7) for
  verification. Context: qualitative journals require COREQ/SRQR; quantitative
  require EQUATOR checklists as desk requirement; history journals have none.
  Trigger keywords: reporting guideline, COREQ, SRQR, STROBE, CONSORT, PRISMA,
  보고지침, checklist, 질적 보고지침, 저자지침.
---

# reporting-guideline-router (Tier 2 — auto)

> discipline + study design별 reporting guideline 자동 라우팅 + checklist 매핑. **엔진 = Claude 단독.**

## 분야 분기 (라우팅 1단계 = discipline)

`paper_home/.sam/hitl/paper_profile.json`의 **`discipline`**를 먼저 읽고, 그 안에서 study design으로 세부 라우팅한다:

- **P1 의학교육-질적 (기본)** → **COREQ** 또는 **SRQR** (아래 표)
- **P2 의학교육-양적** → STROBE/CONSORT/PRISMA 등 EQUATOR 체크리스트
- **P3 의사학** → **정식 reporting checklist 없음** — 저널 저자지침 + 역사서술 규범으로 라우팅(정직하게)

> `discipline` 미기록이면 P1로 가정하고 명시(fail-closed). **P3에 억지로 체크리스트를 만들어내지 않는다** — 없다고 정직하게 말하는 것이 fail-closed 교리.

## Routing Table

> **버전은 2026-06 기준 고정(pinned)** — 실행 시 EQUATOR·각 guideline 공식 사이트에서 **최신판·확장 존재를 확인**하고, 더 새 버전이 있으면 우선·표는 superseded로 표시.

### P1 질적 (기본 · first-class)

| Study design | Guideline | 항목수 | Canonical URL |
|---|---|---|---|
| **인터뷰/포커스그룹** (내러티브탐구·현상학·근거이론이 면담 기반) | **COREQ** (2007) — *내러티브 탐구 면담연구의 1순위* | 32-item | equator-network.org/reporting-guidelines/coreq/ |
| **일반 질적연구** (문서분석·관찰·혼합 질적) | **SRQR** (2014) | 21-item | equator-network.org/reporting-guidelines/srqr/ |

- **COREQ 3영역**: ① 연구팀 & 성찰성(면접자·자격·관계) ② 연구설계(표집·세팅·자료수집·포화) ③ 분석 & 결과(코딩·주제 도출·인용 제시). → section-boundary P1의 Q1(성찰성)·Q2(주제-인용)와 직접 대응.
- **둘 다 해당 시**: 면담·포커스그룹 기반이면 **COREQ 우선**, 그 외 질적이면 SRQR. 혼합연구는 질적 부분에 COREQ/SRQR + 양적 부분에 P2 지침 병행.

### P2 양적 (임상·정량 — 기존 표 유지)

| Study type | Guideline | Canonical URL |
|---|---|---|
| Observational (cohort/case-control/**cross-sectional 설문**) | **STROBE** (2007; RECORD·STROBE-MR 확장 후보) | strobe-statement.org |
| Randomized controlled trial | **CONSORT 2025** (2010 대체, 30-item) | consort-spirit.org |
| Systematic review / meta-analysis | **PRISMA 2020** (scoping이면 PRISMA-ScR) | prisma-statement.org |
| Quality improvement (교육 개선) | **SQUIRE 2.0** | squire-statement.org |
| Diagnostic accuracy | **STARD 2015 (v1.1)** | equator-network.org/reporting-guidelines/stard/ |
| Trial protocol | **SPIRIT 2025** (2013 대체) | consort-spirit.org |
| Prediction model | **TRIPOD+AI** (2015 대체; LLM 연구는 TRIPOD-LLM 후보) | tripod-statement.org |
| AI in health/education | **TRIPOD+AI / CONSORT-AI / SPIRIT-AI / DECIDE-AI** | equator-network.org |

> 의학교육-양적에서 가장 흔함: **설문=STROBE**, **교육개선=SQUIRE 2.0**. (MERSQI·NOS 등은 reporting이 아니라 quality-appraisal 도구 — 라우팅 대상 아님.)

### P3 의사학 (정식 체크리스트 없음 — 정직 라우팅)

EQUATOR형 reporting guideline이 **존재하지 않는다.** 억지 매핑 대신:

1. **Target 저널 저자지침** — 의사학·연세의사학·Social History of Medicine·Bulletin of the History of Medicine·Medical History 각 공식 author guidelines(분량·각주 양식·초록 요건). 원문은 공식 페이지에서 직접 확인.
2. **역사서술 규범(대체 checklist)** — 아래 §"P3 관례 체크리스트"로 형식 점검(EQUATOR 체크리스트가 **아님**을 산출물에 명시).

## 모드

| 모드 | 시간 |
|---|---|
| `workshop-mini` | 3분 (라우팅만) |
| `standard` | 15분 (라우팅 + 본문 vs checklist 매칭) |
| `deep-audit` | 30분 (item-by-item 통과 여부) |

## 입력

- `paper_home/.sam/hitl/paper_profile.json` (discipline)
- `paper_home/01_design/article_type.md`
- `paper_home/04_draft/manuscript.md`

## 절차 (3분 routing)
```
당신은 reporting guideline 라우터입니다.
1. discipline 읽기 (P1/P2/P3)
2. P1 → 면담·포커스그룹 여부로 COREQ vs SRQR 결정
   P2 → study design 식별 후 STROBE/CONSORT/PRISMA/SQUIRE 등 매칭
   P3 → "정식 체크리스트 없음" 선언 + 저널 저자지침·역사서술 규범으로 라우팅
3. checklist URL(P1/P2) 또는 저널 저자지침 경로(P3) 제공
4. 부착 의무 여부 confirmation (P1/P2 checklist PDF / P3 저자지침 준수 노트)
```

## 절차 (15분 standard, 본문 매칭)

- **P1 (COREQ 예)**: 32항목 중 핵심을 본문에서 검색 —
  면접자 신원·자격(item 1–5), 표집·포화(item 10–15), 코딩·주제·인용 제시(item 25–32). 누락 item + 위치 제안.
- **P2 (STROBE 예)**: item 6(eligibility)·11(표본크기)·12c(결측)·17(confounder 보정) 등 검색.
- **P3**: 아래 관례 체크리스트로 형식 점검(내용 품질은 scorecard-9d/section-boundary).

### P3 관례 체크리스트 (EQUATOR 아님 — 역사서술 형식 점검)
- [ ] 논지(thesis)가 Introduction에 명시
- [ ] 1차 사료와 2차 문헌이 구분되어 인용
- [ ] 각주/미주 양식 일관(저널 지침 = 대개 Chicago notes 계열; 저널별 확인)
- [ ] 1차 사료 로케이터(소장처·컬렉션·문서명·연도) 표기
- [ ] 초록·키워드가 저널 요건 충족
- [ ] 역사서술적 기여가 Conclusion에 명시

## Output 표준

`paper_home/08_package/reporting_checklist.md`:

```markdown
# Reporting Guideline Routing  (discipline: P1)

- Study design: 내러티브 탐구 (심층면담 기반)
- Primary guideline: COREQ (32-item)
- Checklist URL: https://www.equator-network.org/reporting-guidelines/coreq/

## COREQ Items 본문 매칭
| # | Domain | Item | Status | 위치 |
|---|---|---|---|---|
| 1 | 팀·성찰성 | Interviewer identified | Pass | Methods §3 |
| 8 | 성찰성 | Researcher relationship | **Fail** | 위치성 진술 보강 필요 |
| 27 | 분석·결과 | Quotations presented | Pass | Findings 전반 |

## 누락 item: 2건 → 본문 보강 후 COREQ checklist PDF 부착

## checklist 부착
- [ ] COREQ checklist PDF → paper_home/08_package/reporting_checklist.pdf
- [ ] 각 item에 본문 페이지 표기
```

> P3는 위 대신 `## 저널 저자지침 준수 노트`(저널명·분량·각주 양식·관례 체크리스트 결과)를 쓰고, "정식 EQUATOR checklist 부착 대상 아님"을 명기.
> 체크리스트/노트 문서를 .docx로 뽑을 때 `${CLAUDE_SKILL_DIR}/../_shared/scripts/md_to_docx.py` 사용 가능(⑦ 패키징).

## HITL Event Emit

```json
{"ts":"...","step":1,"gate":"A_design","event_type":"gate_pass","skill":"reporting-guideline-router","engine":"claude","category":"checklist_routing","severity":1,"description":"P1 COREQ routed; 2 items need attention"}
```

## 자주 발생하는 함정

1. **분야 무시하고 STROBE로 직행** — P1 질적연구인데 STROBE 라우팅 = 오라우팅. discipline 먼저.
2. **COREQ vs SRQR 혼동** — 면담·포커스그룹 = COREQ, 그 외 질적 = SRQR.
3. **P3에 억지 체크리스트 발명** — 없는 것을 지어내면 fail-closed 위반. "없음" 선언 + 저널 지침 라우팅이 정답.
4. **checklist PDF 부착 누락(P1/P2)** — 라우팅만 하고 부착 안 함 → desk reject.
5. **각 item 본문 페이지 미표기** — checklist "page #" 칸 비우면 desk reject.

## 다음 단계

→ 본문 보강 → checklist PDF/저자지침 노트 부착 → desk-reject-precheck (Step 7 quick scan) → Step 10 Wrap
