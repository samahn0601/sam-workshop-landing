---
name: scorecard-9d
description: >
  Use this skill to score a humanities/social-medicine manuscript on 9 dimensions
  for Self-Gate decisions and version comparison. The rigor dimensions are
  discipline-conditional: for qualitative med-education (P1, default) dimensions
  1-3 = Lincoln & Guba trustworthiness (credibility/transferability/dependability/
  confirmability + reflexivity) and thick description; for quantitative
  med-education (P2) = clinical/educational relevance + methodological/statistical
  rigor + evidence sufficiency; for history of medicine (P3) = historiographic
  contribution + source criticism + use of primary sources. Dimensions 4-9
  (argument/logical coherence, novelty, style, journal fit, humanness, structure
  Pass/Fail) are shared. Trigger when user says "scorecard", "9차원 점수", "원고
  평가", "manuscript score", "draft 점수", "version comparison", "점수 비교", or
  operates in Step 6. Pairs with critic-multi-persona (Claude in-model personas).
  Do not use for desk-rejection precheck (desk-reject-precheck) or packaging
  (Step 7 flow). Input: paper_home/04_draft/manuscript.md +
  paper_home/.sam/hitl/paper_profile.json (discipline) + journal_shortlist.md
  (dim 7) (+ prior version if comparing). Output:
  paper_home/06_critic/scorecard_9d.md. Pipeline position: sam-medhum Step 6 /
  Self-Gate C, optional re-score at D_finish. Context: trustworthiness rigor,
  historiographic rigor, reward-hacking detection via dimension diff. Trigger
  keywords: scorecard, 점수표, 9차원, 평가, score, dimension, 신뢰성, 사료비판,
  version diff, 점수 비교.
---

# scorecard-9d (Step 6, optional 투고 직전 re-score)

> 9차원 정량 평가. v1 → v2 → v3 진행 시 차원별 변화 추적(Score-Driven Revert 감지). critic-multi-persona(**Claude 인-모델 멀티페르소나** — 질적방법론가/의학교육자/역사가)와 자주 묶어 운영. **엔진 = Claude 단독.**

## 분야 분기 (차원 1–3만 교체)

`paper_home/.sam/hitl/paper_profile.json`의 **`discipline`**에 따라 **차원 1–3(엄정성 클러스터)**이 바뀐다. **차원 4–9는 전 분야 공통**. 척도·게이트 형태(1–8 합산 max 40 + 차원 9 Pass/Fail)는 불변.

| # | P1 의학교육-질적 (기본) | P2 의학교육-양적 | P3 의사학 |
|---|---|---|---|
| **1** | 관련성/기여 (교육·실천적 의의) | 임상·교육적 관련성 | **역사서술적 기여** (기존 서술 갱신) |
| **2** | **신뢰성(Trustworthiness)** — credibility·transferability·dependability·confirmability + 성찰성 | 방법론·통계적 엄밀성 | **사료 비판** (출처·내력·진위·편향, 1차/2차 구분) |
| **3** | **두터운 기술(Thick description)** + 주제-인용 정박 | 근거 충분성 (데이터·인용) | **1차 사료 활용** (폭·깊이·적절 인용) |
| 4 | 논증/논리 일관성 (공통) | ← | ← |
| 5 | 독창성/기여 (공통) | ← | ← |
| 6 | 문체/가독성 (공통 — 인문 학술 레지스터) | ← | ← |
| 7 | 저널 적합성 (공통) | ← | ← |
| 8 | Humanness (AI 시그니처 부재, 공통) | ← | ← |
| 9 | 구조 정합성 (Pass/Fail, section-boundary 연동) | ← | ← |

종합: 차원 1–8 합산(max 40) + 차원 9 통과 여부.

> `discipline` 미기록이면 P1로 채점하고 명시(fail-closed).

## 점수 기준 (1–8 공통)

| 점수 | 의미 |
|---|---|
| 5 Excellent | 수정 불필요 |
| 4 Good | Minor revision 수준 |
| 3 Acceptable | 의미 있는 개선 필요 (reviewer 지적 가능성 ↑) |
| 2 Weak | 재작업 필요한 심각한 문제 |
| 1 Critical | 근본적 재작업 |

### 차원 2 rubric (분야별로 무엇을 보는가)

- **P1 신뢰성**: credibility(장기관여·삼각검증·member checking), transferability(두터운 기술·맥락 제시), dependability(감사 추적·분석 절차 투명), confirmability(원자료↔해석 연결), **성찰성**(연구자 위치성이 분석에 어떻게 작용했는지). 5 = 4기준 + 성찰성 모두 절차·서술로 뒷받침.
- **P2 엄밀성**: 설계 적절성·표본·측정도구 타당도/신뢰도·통계 적합성. 수치 일관성은 P2-only `${CLAUDE_SKILL_DIR}/../_shared/scripts/stats_consistency_check.py`가 별도.
- **P3 사료비판**: 사료의 출처·내력(provenance)·진위·저자 편향 검토, 1차/2차 구분, 사료 간 교차확인. 5 = 핵심 주장이 비판적으로 검토된 1차 사료에 정박.

## 모드

| 모드 | 시간 | 특징 |
|---|---|---|
| `workshop-mini` | 10분 | 1–8 점수 + 9 Pass/Fail, 간단 사유 |
| `standard` | 25분 | + 차원별 evidence span 인용 |
| `deep-audit` | 50분 | + version diff (v1 vs v2 vs v3) |

## Gate 연동

- **Self-Gate A2 (Step 3 후)**: 차원 7(저널 적합성) ≥ 3
- **Self-Gate C (Step 6 후)**: 종합 ≥ 32/40 + 차원 ≤ 2점 = 0건 + 차원 9 = Pass
- **Self-Gate D_finish (Step 7 후, 투고 직전 re-score)**: 종합 ≥ 36/40 + 차원 9 = Pass + 차원 8 ≥ 4

> 차원 7은 `journal_shortlist.md`의 **Scope fit·Fit verdict·Reject risk 필수 참조** — "Reject risk를 상쇄할 논리가 draft에 있는가"(① Scope-Fit Gate의 downstream, 분야 무관).

## 입력

- `paper_home/04_draft/manuscript.md`
- `paper_home/.sam/hitl/paper_profile.json` (discipline)
- (선택) `paper_home/04_draft/manuscript_versions/manuscript_vN.md` (비교용)

## 절차 (workshop-mini, 10분)

### Step 1: discipline 확인 → 9차원 채점
```
당신은 가장 가혹한 Area Chair입니다. discipline={P1|P2|P3}에 맞는 차원 1–3
정의를 적용해 첨부 manuscript.md를 9차원 채점하세요.
각 차원:
- 점수 (1-5 또는 차원 9는 Pass/Fail)
- 1줄 사유 (구체적 — "전반적으로 좋음" 같은 모호 금지)
- evidence_location (판단 근거가 된 본문 위치)
차원 2가 P1이면 credibility/transferability/dependability/confirmability/성찰성
각각에 한 줄씩. 차원 9는 section-boundary 결과를 그대로 받는다.
```

### Step 2: 종합 + Gate 매칭

| 종합 | 수준 | 다음 단계 |
|---|---|---|
| 36–40 + 9=Pass | 투고 준비 | Self-Gate D 통과 가능 |
| 32–35 + 9=Pass | Gate C 통과 | 마무리 정제 후 Step 7 |
| 25–31 | Major revision | Step 6 critic 재실행 |
| < 25 | 재작성 | Step 3 story-design 회귀 |

### Step 3: Humanness 자동 트리거

차원 8 ≤ 3점 → `humanize-en`/`humanize-ko` 자동 발화 권고(인문 학술 레지스터 주석 반영).

### Step 4: Version diff (있을 때)
```
| 차원 | v1 | v2 | Δ |
| 2 신뢰성 | 3 | 4 | +1 |
| 4 논증 일관성 | 4 | 3 | -1 ⚠️ |
⚠️ 차원 하락 → Score-Driven Revert 검토 권고.
```

## Output 표준

### `scorecard_9d.md`
```markdown
# Scorecard 9D — Round N  (discipline: P1)

## 점수
| 차원 | 점수 | 사유 | Evidence |
|---|---|---|---|
| 1. 관련성/기여 | 4/5 | 수련교육 실천에 전이 가능 | Discussion §2 |
| 2. 신뢰성 | 3/5 | member checking O, 성찰성 진술 얕음 | Methods §3 |
| 3. 두터운 기술 | 3/5 | Theme 2 발췌 빈약 | Findings §2 |
| ... |
| 9. 구조 정합성 | Pass | Q1–Q5 이슈 0건 | section_boundary.md |

## 종합
- 1–8 합: 32/40 · 차원 9: Pass

## Gate 판정
- Gate C: PASS (≥32 + 차원 ≤2 = 0건 + 9=Pass)

## Humanness 트리거
- 차원 8 = 4 → humanize 재실행 불필요

## Version Diff (있을 때)
- v1 합 28 → v2 합 32 (+4), Score-Driven Revert 미발동
```

## HITL Event Emit

```json
{"ts":"...","step":6,"gate":"C_verify_critic","event_type":"gate_pass","skill":"scorecard-9d","engine":"claude","category":"manuscript_score","severity":2,"description":"P1 score 32/40, dim9=Pass, trustworthiness=3","time_to_fix_min":10}
```

## 결정적 vs LLM 분리

- **LLM**: 9차원 점수 자체(정성 판단, discipline rubric 적용).
- **결정적**: 종합 산술, Gate 임계 비교, Score-Driven Revert 감지(수치 ↓ 룰), 차원 9는 section-boundary 산출을 그대로 승계.

## Self-Gate 체크리스트

### Self-Gate C (Step 6)
- [ ] discipline에 맞는 차원 1–3 rubric 적용
- [ ] 종합 ≥ 32
- [ ] 1–8 차원 중 ≤ 2점 = 0건
- [ ] 차원 9 = Pass
- [ ] Score-Driven Revert 미발동 (또는 본인 ratify)

### Self-Gate D_finish (Step 7 후 · 투고 직전 re-score)
- [ ] 종합 ≥ 36
- [ ] 차원 9 = Pass
- [ ] 차원 8 ≥ 4 (Humanness 안정)

## 자주 발생하는 함정

1. **AI가 본인 score를 후하게 줌 (self-approval)** — 자체평가 편향. "가장 가혹한 reviewer" 페르소나 + critic-multi-persona 교차. Claude 단독이므로 점수는 **저자가 ratify**(⑥ 정차).
2. **분야 rubric 오적용** — P1 원고에 "통계적 엄밀성"을 채점하면 무의미 → discipline 먼저.
3. **Evidence_location 누락** — 근거 없는 점수 = reward hacking 의심.
4. **v1→v2 차원별 비교 없이 종합만** — 한 차원 하락 못 봄(Score-Driven Revert).
5. **Humanness 단순 체크** — AI 시그니처(Moreover, Furthermore…)는 humanize-en/ko에서 별도 검증.

## 다음 단계

→ Self-Gate C/D 통과 후 다음 step
