---
name: story-design
description: >
  Use this skill when a humanities/social-medicine manuscript needs its core
  message and a discipline-appropriate structure that maps each claim to
  evidence. For qualitative med-education (P1, default) it does "finding the
  focus" — narrowing many interviews/participants into ONE publishable analytic
  thread using Clandinin & Connelly's 3-D narrative inquiry space and thematic
  structuring. For quantitative med-education (P2) it keeps hypothesis/aims +
  IMRaD. For history of medicine (P3) it builds a thesis-driven argumentation
  arc (claim → sources → historiographic positioning). Also runs a thesis→paper
  conversion mode (condense a 학위논문 into one paper). Trigger when the user says
  "outline 짜줘", "스토리 설계", "논문 구조", "초점 잡기", "주제 구조화",
  "학위논문 논문으로", "논증 구조", "narrative arc", "finding the focus", or
  operates in Step 3 of the sam-medhum pipeline. Do not use for figure planning
  (figure-prompt-eng) or reference verification (verify-reference-essential).
  Input: paper_home/01_design/{article_type.md, journal_shortlist.md} +
  paper_home/.sam/hitl/paper_profile.json (discipline) +
  paper_home/02_research/{claim_bank.jsonl, evidence_table.md} (+ deep_research.md
  backup; + 00_intake/ thesis for conversion mode). Output:
  paper_home/03_outline/{story_1pager.md, outline.md, evidence_map.md}.
  Pipeline position: sam-medhum Step 3 / Self-Gate A. Context: qualitative
  trustworthiness, historiographic argument, claim-evidence traceability.
  Trigger keywords: outline, 스토리, 구조, 초점, 주제, 논증, narrative inquiry,
  학위논문, thesis to paper, key message, one-sentence message, claim evidence.
---

# story-design (Step 3)

> ②Research(claim_bank) + 저널 spec을 받아 **논문의 핵심 주장 + 분야별 구조 + claim-evidence 매핑**을 산출. Step 4 Draft 진입 전 마지막 디자인 단계. **엔진 = Claude 단독** (외부 API 불요).

## 분야 분기 (먼저 읽는다)

`paper_home/.sam/hitl/paper_profile.json`의 **`discipline`** (①에서 start-here가 기록)에 따라 3.1–3.4 절차와 outline 골격이 달라진다:

- **P1 의학교육-질적 (기본·대표)** — 핵심 = "초점 잡기(finding the focus)". Clandinin & Connelly 3차원 내러티브 탐구공간 + 주제 구조화.
- **P2 의학교육-양적** — 가설/목적(aims) + IMRaD (임상팩 골격 유지).
- **P3 의사학** — 논증 서사(claim → 사료 → 역사서술적 위치잡기).

> `discipline` 미기록이면 P1로 가정하고 그 사실을 산출물에 명시(fail-closed: 조용히 임상 IMRaD로 넘어가지 않는다).

## 모드

| 모드 | 시간 | 산출 |
|---|---|---|
| `workshop-mini` | 25분 | 핵심 메시지 + outline + evidence map |
| `standard` | 50분 | + 대안 서사/논증 아크 2개 비교 |
| `deep-audit` | 90분 | + 섹션별 claim ledger 채움 |
| `thesis-to-paper` | 40분 | **오버레이 모드**(어느 discipline과도 결합) — 학위논문 1편 → 논문 1편 압축. 아래 §3.5 |

## 입력

- `paper_home/.sam/hitl/paper_profile.json` — **discipline** (분기 키)
- `paper_home/01_design/article_type.md` — 잠정 article type
- `paper_home/01_design/journal_shortlist.md` — target 저널 spec (**Scope fit·Fit verdict·Reject risk 칼럼 필수 반영** — Strong fit 1순위, 없으면 Reject risk 낮은 후보. Scope-Fit Gate는 분야 무관)
- **`paper_home/02_research/claim_bank.jsonl` + `evidence_table.md`** (evidence-harvest 산출 — **근거의 단일 작업대**. evidence_table을 1차 인덱스로, high-risk·locked claim만 claim_bank에서 발췌)
- `paper_home/02_research/deep_research.md` — 원문 확인용 보조 (claim_bank 있으면 재해석 금지)
- (thesis-to-paper 모드) `paper_home/00_intake/`의 학위논문 파일
- (선택) 본인 보유 데이터: 인터뷰 전사(P1)·데이터셋(P2)·1차 사료 노트(P3)

## 3.1 핵심 메시지 (5분) — discipline별

논문의 단일 주장/초점을 한 문장으로. 공통 기준 + 4번째 기준이 분야별로 다르다:

- **Specific** (전 분야) — "AI는 교육에 좋다" ✗ → 측정·논증 가능한 단일 명제 ✓
- **Defensible** (전 분야) — P1: 인용/주제로 / P2: 데이터로 / P3: 1차 사료로 방어 가능
- **Novel** (전 분야) — ②Research에서 아직 직접 입증·서술되지 않은 영역
- 4번째:
  - **P1 Resonant & Transferable** — 독자가 자기 교육 맥락에 전이(transfer)할 수 있는 통찰
  - **P2 Actionable** — 교육/진료 개선에 적용 가능
  - **P3 Historiographically significant** — 기존 역사서술을 갱신·수정·정교화

산출 → `story_1pager.md` 첫 줄.

### P1 초점 잡기(finding the focus) — 대표 절차

질적연구의 최대 난관: 인터뷰 N건·코드 수십 개·주제 여러 개를 **하나의 발표 가능한 분석적 실(one publishable thread)**로 좁히기. 나머지는 배경·후속 연구로 보낸다.

1. claim_bank의 theme/interpretation claim을 나열 → "이 논문이 논증하는 **하나의** 분석적 주장"을 고른다.
2. **Clandinin & Connelly 3차원 내러티브 탐구공간**으로 그 주장을 위치시킨다:
   - **시간성(temporality)** — 과거/현재/미래 (경험의 시간적 전개)
   - **사회성(sociality)** — 개인적↔사회적, 내적 조건(감정·희망)↔외적 조건(환경·타인)
   - **장소(place)** — 경험이 일어난 구체적 물리·제도 공간
3. 이 3축으로 "초점이 상황 속에 놓였는가(situated)"를 점검 → 축이 비면 산만한 데이터 나열이 된다.

## 3.2 Gap / 위치잡기 (5분)

- **P1** — 기존 문헌이 "이 경험을 어떻게 못 담았는가"를 1단락(해석적 gap, 가설 아님).
- **P2** — 기존 문헌의 실증 공백 → research question/hypothesis.
- **P3** — 기존 **역사서술(historiography)**이 무엇을 놓쳤나 → 본 논문의 논지가 그것을 어떻게 갱신하는가(Introduction 논증 개시 문단 골격).

## 3.3 Outline 구조 결정 (10분) — discipline 분기

> Article type(짧은 형식 Commentary/Perspective/Letter vs 전체 논문)은 **word budget**을 정하고, discipline은 **섹션 골격**을 정한다. 짧은 형식은 아래 골격을 압축한다.

### P1 의학교육-질적 (기본)
```
1. Introduction (현상·해석적 gap·연구질문 — 가설 아님)   (~15%)
2. Methods (전통[내러티브탐구/현상학/근거이론]·참여자·자료수집·
   분석 + 성찰성/위치성 + 신뢰성[trustworthiness])          (~20%)
3. Findings (주제 1..n — 각 주제 = 분석적 주장 + 예시 인용)   (~40%)
4. Discussion (해석 vs 문헌·전이성·함의·성찰적 한계)         (~25%)
```
> 질적 전통에 따라 Findings+Discussion을 **통합**할 수 있음(엄격한 Results↔Discussion 분리는 P1 필수 아님 — section-boundary 참조). 통합 시 outline에 명시.

### P2 의학교육-양적 (IMRaD 유지)
```
1. Introduction (gap → research question/hypothesis)
2. Methods (설계·표본·측정도구[심리측정]·분석)
3. Results (표/그림 — 해석 없이 수치만)
4. Discussion (key finding·비교·한계·함의)
```
> 리뷰/설문 등 세부는 article type에 따름. 통계 일관성은 P2-only 스크립트 `${CLAUDE_SKILL_DIR}/../_shared/scripts/stats_consistency_check.py`가 ⑤에서 담당.

### P3 의사학 (논증 서사)
```
1. Introduction (역사적 문제·논지[thesis]·역사서술적 gap)
2. Sources & Approach (1차 사료 코퍼스·출처/내력·접근법·각주 체계)
3. Body / Analysis (논지를 시간순 또는 주제별로 전개 —
   모든 실질 주장은 사료 각주에 정박)
4. Contribution / Conclusion (기존 역사서술을 어떻게 갱신하는가)
```
> 엄격한 IMRaD 아님. 각주 규범(1차/2차 사료 구분·문서 로케이터)은 section-boundary P3에서 검사.

산출 → `paper_home/03_outline/outline.md` (Live Artifact 후보)

## 3.4 Evidence map (5분) — claim_id 기반, 근거 형태만 분야별

각 outline 섹션/주제에 **claim_bank의 claim_id**를 매핑(섹션·주제당 핵심 claim 1–3개). `[NO_VERBATIM]`/`[INCOMPLETE]`/`PENDING_HUMAN_SOURCE_CHECK` claim은 중심축에 두지 않고 `Step 5 보강` 표시:

| 섹션/주제 | claim_id | 핵심 주장 (요약) | 근거 | risk | fit 관련성 | action |
|---|---|---|---|---|---|---|
| (P1) Theme 2 | C007 | 전공의는 실패를 재학습의 계기로 재해석 | 인용 P03·P11 (theme: reframing) | medium | 핵심 novelty | keep |
| (P2) Results §1 | C003 | 공감점수와 소진의 음의 상관 | r=−.34, S009 | medium | Strong-fit 저널 관심 | keep |
| (P3) Analysis §2 | C012 | 1930년대 X병원 격리정책 전환 | 사료: 총독부 위생연보 1931 (locator) | high ★ | 논지 핵심 | 사료 원문 인간확인 |
| (any) — | — | (근거 후보 없음) | — | — | — | `NO_CLAIM_YET` → Step 5 |

산출 → `paper_home/03_outline/evidence_map.md`

→ claim_id 없는 섹션(`NO_CLAIM_YET`)은 Step 5 verify 보강 대상. claim_bank가 없으면(evidence-harvest 미실행) deep_research에서 직접 매핑하되 그 사실을 명시.

## 3.5 thesis-to-paper 모드 (오버레이, 40분)

참가자 다수가 **학위논문→논문 전환**을 원한다. discipline 분기 위에 얹는다.

1. **하나의 논문 = 하나의 주장.** 학위논문 1편에서 논문화 가능한 실(thread)을 1개만 고른다(P1=주제군 1개 / P2=가설 1개 / P3=논지 1개). 나머지는 별도 논문 후보.
2. **장(章)→절(節) 압축 매핑**:
   - 서론+이론적 배경(2개 장) → Introduction (이 주장에 필요한 만큼만; 문헌고찰 대폭 축약)
   - 연구방법 장 → Methods/Sources (이 논문 주장 방어에 필요한 것만)
   - 결과 장(들) → Findings/Results (고른 실을 뒷받침하는 부분만)
   - 논의+결론 → Discussion/Conclusion
3. **버릴 것**: 망라적 문헌고찰, 곁가지 분석, 부록, 장황한 방법 정당화.
4. **분량**: 학위논문 100–200면 → 논문 3,000–6,000단어. 극단적 압축이 정상.
5. **중복게재 주의**: 학위논문 기탁본과의 관계를 저널 정책으로 확인(대개 학위논문은 prior publication으로 보지 않으나 저널마다 상이) → desk-reject-precheck / ⑩ Human Final Gate에서 확인.

산출은 §3.1–3.4와 동일 파일에 쓰되 `story_1pager.md`에 `## Thesis→Paper 압축 결정`(고른 실 + 버린 장 목록)을 추가.

## Output 표준

### `story_1pager.md`
```markdown
# Story 1-Pager  (discipline: P1 | P2 | P3)

## Core message / 핵심 주장
{한 문장}

## Gap / 역사서술적 위치
{1 단락 — P3는 historiographic gap}

## Why this journal
{1–2 문장 — Fit verdict 반영}

## Structure storyline
{각 섹션/주제 1줄 요약}

## (P1) 3-D 위치: 시간성 / 사회성 / 장소
{초점이 상황 속에 놓였는지}

## Risk / counterargument
{예상 reviewer 반박 1–2개 — P1=전이성·과일반화, P3=사료 해석 이견}

## (thesis-to-paper 시) Thesis→Paper 압축 결정
{고른 실 + 버린 장}
```

### `outline.md`
섹션/주제별: 핵심 주장 1–2 bullet + 근거 후보(evidence_map 링크) + word budget(target journal 기반).

### `evidence_map.md`
위 표 형식.

## HITL Event Emit

```json
{"ts":"...","paper_id":"...","step":3,"gate":"A_design","event_type":"gate_pass","skill":"story-design","engine":"claude","category":"narrative_design","severity":1,"description":"P1 qualitative: 4 themes, focus locked, 2 sections need Step5 evidence","time_to_fix_min":25}
```

## 결정적 vs LLM 분리

- **LLM 판단**: 초점/논지 선정, 주제 구조화, 3-D 위치잡기, 메시지 정제, gap/historiography 서술.
- **결정적**: word budget(journal_specs 기반 산술), reporting checklist 섹션 강제(P1=COREQ/SRQR, P2=STROBE 등 — reporting-guideline-router 연동; P3는 정식 checklist 없음).

## Solo + Claude-only

기본 Claude 단독. 다관점이 필요하면 **Claude 인-모델 멀티페르소나**(critic-multi-persona)로 — 외부 엔진 호출 없음.

## Self-Gate A2 체크리스트 (Step 3 종료)

- [ ] 핵심 메시지가 Specific + Defensible + Novel + (P1 Resonant/P2 Actionable/P3 Historiographically significant)
- [ ] Gap/역사서술 위치가 ②Research 인용으로 뒷받침됨
- [ ] Outline의 모든 섹션/주제에 핵심 주장 ≥ 1개
- [ ] Evidence map에서 근거 0–1개인 섹션 식별(Step 5 보강 표시)
- [ ] (P1) 초점이 3-D 공간에 위치했는가 / (P3) 논지가 명시되고 사료에 정박했는가
- [ ] Section word budget이 target 저널 word limit 내
- [ ] Article type + discipline 확정 (① 잠정 → ③ lock)

## Few-shot 예시

### Before (느슨한 P1 outline)
```
1. 서론  2. 방법  3. 결과  4. 논의
```

### After — P1 질적 (내러티브 탐구; 리허설 예시: 전공의의 재학습 경험)
```
1. Introduction (300w)
   - 현상: 전공의가 임상 실패 후 어떻게 다시 배우는가
   - 해석적 gap: 기존 문헌은 역량 결과에 집중, 경험의 의미 미탐구
   - 연구질문: 재학습 경험은 어떻게 이야기되는가
2. Methods (450w)
   - 전통: 내러티브 탐구 (Clandinin & Connelly)
   - 참여자: 전공의 12명 (비식별 P01–P12), 심층면담 2회
   - 분석: 3차원 공간 재구성 + 주제 도출
   - 성찰성: 연구자=임상교수, 위치성 진술 / 신뢰성: member checking·audit trail
3. Findings (900w) — 통합형(해석 포함 허용)
   - Theme 1: 실패의 시간적 재배치 (temporality) — 인용 P03, P07
   - Theme 2: 실패를 재학습으로 reframing — 인용 P11
   - Theme 3: 지도전문의라는 장소(place)의 역할 — 인용 P05
4. Discussion (600w)
   - 문헌 대비 해석 / 전이성(다른 수련환경으로) / 성찰적 한계
```

### After — P3 의사학 (논증 서사)
```
1. Introduction: 논지 = "1930년대 X병원 격리정책은 방역이 아니라 노동통제 논리에서 전환됐다"
2. Sources & Approach: 총독부 위생연보·병원 일지·신문 (출처 내력·각주 규범)
3. Analysis: 정책 문서의 언어 변화 → 사료 각주 정박, 시간순
4. Contribution: 기존 '방역 중심' 서술을 노동사 관점으로 갱신
```

## 자주 발생하는 함정

1. **초점을 못 좁힘(P1)** — 주제 8개를 다 넣으려다 논문이 산만해짐 → 하나의 실만.
2. **가설 언어를 질적에 강요(P1)** — "H1을 검증" 식 → 해석적 연구질문으로.
3. **논지 없는 사료 나열(P3)** — 연대기만 있고 argument 부재 → Introduction에서 논지 명시.
4. **Word budget 무시** — Commentary에 6000단어 → Step 4에서 반드시 깎임.
5. **thesis 전체를 통째로 옮김** — 압축 실패 → reviewer가 "논문이 아니라 학위논문 요약" 지적.

## 다음 단계

→ Step 4 Draft (Code 탭 작업본 `manuscript.md`)
