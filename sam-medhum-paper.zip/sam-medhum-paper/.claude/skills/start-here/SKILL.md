---
name: start-here
description: >
  워크숍·논문 세션의 첫 진입점(오케스트레이터). 한 번 부르면 분야(discipline:
  의학교육-질적/의학교육-양적/의사학)를 먼저 확정하고, 10-step 파이프라인 맵과
  운전 모드를 보여주고, gate_plan을 작성한 뒤 Step 1부터 각 단계 skill을
  자동으로 이어 호출하며 안내한다. 참가자가 개별 skill 이름을 몰라도 전체 흐름을
  탄다. **Claude 단독 파이프라인** — Gemini/GPT 등 외부 엔진 호출 없음, API 키
  불요; critic의 다관점(Step⑥)은 Claude 인-모델 멀티페르소나로 구현된다. 단계별
  정차(①⑤⑥⑩)와 연구윤리 floor(IRB·연구참여자 비식별·1차 사료 확인·AI 공개문)는
  유지 — "정지 없이 진행"이지 검토 생략이 아니다. Trigger when the user starts a
  paper or workshop session, asks "어디서부터 / 시작하자 / 논문 쓰자", or is
  unsure which skill to use first. Do not use for a specific stage task — call
  that stage's skill directly (journal-fit-check, verify-reference-essential,
  critic-multi-persona 등). Input: paper_home (신규 또는 진행 중) + (선택)
  .sam/hitl/paper_profile.json, .sam/pipeline_state.json. Output:
  paper_profile.json의 discipline 필드 + .sam/hitl/gate_plan.json + Step 1
  진입. Pipeline position: 진입점 / 전체 10-step 오케스트레이션. Medical
  context: 의학교육학·의사학 연구윤리(질적연구도 IRB 대상)·Publication Ethics·
  ⑧⑨ Submission/Review floor는 운전 모드와 무관하게 강제. Trigger keywords:
  시작, 시작하자, 워크숍 시작, 논문 시작, 논문 쓰자, 어디서부터, 어디부터, 처음,
  진입점, 파이프라인 시작, 운전 모드, 분야 선택, 의학교육, 의사학, 질적연구,
  start, start here, begin, get started, kick off, where to start.
---

# start-here — 논문 파이프라인 진입점 (10-step 오케스트레이터)

> 워크숍·논문 세션의 **첫 발화 진입점**. 한 번 부르면 (1) 분야(discipline) 확정 → (2) 10-step 맵 + 운전 모드 제시 → (3) `gate_plan.json` 작성 → (4) Step 1부터 각 단계를 **반자동으로 안내**한다(다음 작업 skill을 호출하거나, 불확실하면 참가자가 입력할 명령을 제시). 참가자가 개별 skill 이름을 몰라도 흐름을 탄다.
>
> ⚠️ **"끝까지 무인 자동"이 아니다.** Claude Code에서 skill은 확정적 워크플로 엔진이 아니라 모델이 자연어/Skill tool로 트리거하는 비결정적 구조다. 그래서 start-here는 **각 단계를 안내하는 내비게이터** — 참가자가 **"다음"** 하기 전엔 다음 단계로 넘어가지 않는다(정차 ①⑤⑥⑩·연구윤리 floor는 강제). "정지 없이 진행"이지 "검토 생략"이 아니다.
>
> ℹ️ **Claude 단독.** 본 fork(sam-medhum)는 Gemini API·GPT API를 호출하지 않는다(개인 Claude Max 구독만으로 완결, API 키 불요). critic-multi-persona의 "다관점 비평"은 외부 모델이 아니라 **Claude가 여러 학술 페르소나를 순차 연기하는 인-모델 멀티페르소나**다.

## 언제 부르나

- 새 `paper_home`에서 논문을 시작할 때 ("시작하자", "어디서부터 할까")
- 진행 중 세션을 다시 열어 "지금 어느 단계지?"를 물을 때 (`.sam/pipeline_state.json` 참조해 이어감)
- 특정 단계 작업은 이 skill이 아니라 **해당 단계 skill을 직접** (journal-fit-check, verify-reference-essential, critic-multi-persona 등)

## 절차

### 0) 현재 상태 파악
- `.sam/pipeline_state.json`의 `current_step` 확인 → 있으면 그 단계부터 이어가고, 없으면 Step 1 신규 시작.
- `.sam/hitl/paper_profile.json` 있으면 로드(없으면 ①에서 함께 작성). **`discipline` 필드가 없으면 아래 0-b)를 먼저 실행 — 이어가기 세션에서 이미 있으면 skip.**

### 0-b) 분야(discipline) 확정 — 신규 논문 최초 1회만

```
이 논문은 어느 분야에 가장 가깝습니까?
1) 의학교육-질적 (기본·대표) — 인터뷰/내러티브/현상학/근거이론/주제분석
2) 의학교육-양적 — 설문/심리측정/실험
3) 의사학 — 1차 사료 기반 역사 논증
```

답변을 `paper_profile.json`의 `discipline` 필드에 그대로 기록한다(`의학교육-질적` / `의학교육-양적` / `의사학` — `paper_profile.schema.json` 준수, 자유 텍스트로 바꿔 쓰지 않는다). 이후 ②연구 유형·⑤검증 전략·⑥critic 페르소나가 이 값을 참조해 조건 분기한다. 특정 논문을 예시로 하드코딩하지 않는다 — 참가자는 각자 본인 자료(인터뷰 전사록, 설문 데이터, 1차 사료 등)를 지참하는 범용 파이프라인이다.

### 1) 10-step 맵 + 운전 모드 제시
`${CLAUDE_SKILL_DIR}/../_shared/templates/pipeline_map.md`의 10-step 맵과 운전 모드 표를 보여준다. (변수 미확장 시 Claude가 절대경로로 치환)

```
작성 ①Idea → ②Research → ③Story → ④Draft → ⑤Verify → ⑥Critic → ⑦Package
제출·리뷰·마무리   ⑧Submission → ⑨Review → ⑩Wrap
```
현장은 2모드만 전면: **🛡️ 표준(정차 ①⑤⑥⑩)** / **⚡ 시간절약(①⑤⑩)**. 나머지(🚗전체정차·🏁최종집중·🎛️커스텀)는 1분 소개 후 사후 자산.

### 2) 모드 선택 → gate_plan 작성
자연어로 모드를 받아 `.sam/hitl/gate_plan.json`에 저장한다. **반드시 아래 형식(`gate_plan.schema.json` 준수)을 그대로 따른다** — 🛡️표준(H3) 예시를 복사해 모드에 맞게만 바꾸고, `mode`/`stops`/`selected_by` 같은 임의 필드는 만들지 않는다:

```json
{
  "preset": "standard", "dial": "H3",
  "medical_floor_override": true, "publication_ethics_floor": true, "submission_review_floor": true,
  "soft_floor_steps": [1, 10],
  "steps": [
    {"n": 1, "name": "Idea Lock", "mode": "review", "locked_reason": "soft floor + Self-Gate A"},
    {"n": 2, "name": "Deep Research", "mode": "auto"},
    {"n": 3, "name": "Story & Outline", "mode": "auto"},
    {"n": 4, "name": "Draft", "mode": "auto"},
    {"n": 5, "name": "Verify", "mode": "review", "locked_reason": "Self-Gate B"},
    {"n": 6, "name": "Critic", "mode": "review", "locked_reason": "Self-Gate C"},
    {"n": 7, "name": "Humanize & Package", "mode": "auto"},
    {"n": 8, "name": "Submission", "mode": "review", "locked_reason": "Submission floor (사람)"},
    {"n": 9, "name": "Review Response", "mode": "review", "locked_reason": "Review floor (사람)"},
    {"n": 10, "name": "Wrap & Next", "mode": "review", "locked_reason": "soft floor + Human Final Gate"}
  ]
}
```
> ⚡ 시간절약 = `preset:"light"`·`dial:"H2"`·정차 ①⑤⑩(⑥ Critic도 `"auto"`). 🚗 전체정차 = 전부 `"review"`. 기본값 🛡️표준(H3).

**모드 선택 직후 책임 배너 1회**:
> AI는 초안을, 저자는 책임을 집니다. 정차하지 않은 단계도 마지막 요약에서 반드시 확인합니다. (전체 배너 = `pipeline_map.md`)

### 3) Step별 반자동 내비게이션 (핵심)
각 step **종료 시 반드시 다음 3줄을 출력**(종료 훅 — 참가자가 "지금 어디 있고 다음에 뭘 할지"를 항상 알게):
```
✅ [현재 단계] 완료 — [핵심 산출물 1줄]
다음: [Step N+1 이름]  →  /[다음-skill-name]
계속하려면 "다음"   (수정·재실행은 그대로 지시)
```
- 참가자가 **"다음"** 하기 전엔 다음 단계로 넘어가지 않는다(정차든 진행이든 동일 — 비개발자 통제감·교착 방지).
- "다음" 입력 시 다음 단계 skill을 Skill tool로 호출한다. **호출이 불확실하면 멈추지 말고** *"`/[skill-name]` 을 입력하세요"* 로 정확한 명령을 제시(참가자가 막히지 않게).
- gate_plan의 정차(review) 단계(①⑤⑥⑩)에선 [승인/수정/계속]을 명시적으로 받는다.

| Step | 단계 skill / 도구 | 정차 |
|---|---|---|
| ① Idea Lock | journal-fit-check | ✋ Self-Gate A |
| ② Deep Research | **Chat Research 핸드오프**(↓ 아래 절 — 필수) + reporting-guideline-router | 진행 |
| ③ Story & Outline | evidence-harvest-claim-bank → story-design | 진행 |
| ④ Draft | (Code 파일 에디터) + section-boundary | 진행 |
| ⑤ Verify | verify-reference-essential + stats-consistency | ✋ Self-Gate B |
| ⑥ Critic | critic-multi-persona** + scorecard-9d | ✋ Self-Gate C |
| ⑦ Humanize & Package | humanize-ko/en + desk-reject-precheck (figure-prompt-eng 옵션) | 진행 * (자동 점검 → ⑩서 최종 확인) |
| ⑧ Submission | 🔒 **사람 주도** — submission worksheet 작성 + 포털 강사 데모 | floor (사람) |
| ⑨ Review Response | 🔒 **사람 주도** — 가상 reviewer fixture → response matrix (revision-response 보조) | floor (사람) |
| ⑩ Wrap & Next | hitl-dial-recommender → 🔒 Human Final Gate + 다음 dial | ✋ Human Final Gate |

\* ⑦의 AI 공개문·cover letter는 표준 정차는 아니지만 **Publication Ethics floor**로 어떤 모드든 저자가 확인한다.
\*\* ⑥의 페르소나 활성화는 discipline 조건부(질적방법론가/의학교육학자/역사가·의사학자 + Editor 공통) — 전부 Claude 인-모델, 외부 엔진 없음. 상세는 `critic-multi-persona/SKILL.md`.

### ② Deep Research — Chat Research 핸드오프 (필수 · 빠뜨리면 안 됨)

딥리서치를 *실행*하는 별도 skill은 없다. start-here가 Step 2에 진입하면 **아래 핸드오프를 반드시 출력**한다. 이걸 빠뜨리면 `02_research/deep_research.md`가 비어, 다음 단계 `evidence-harvest-claim-bank`가 **LLM 메모리 인용(= 날조 참고문헌·desk reject)**으로 빠진다.

**start-here가 Step 2에서 출력할 안내(그대로):**
> **② Deep Research — 문헌은 'Research'로 직접 수집합니다.**
> 1. Claude **Chat 탭**으로 전환(앱 상단 클릭) → **Research(연구) 기능 켜기**.
> 2. 검색 프롬프트(discipline에 맞게 조정):
> ```
> [내 연구질문]의 핵심 문헌을 찾아줘. 출처마다 저자·연도·저널(또는 단행본)·DOI(있으면)·
> 핵심 논지(가능하면 원문 1줄 인용)·한계를 정리하고, 이 분야의 주요 이론적 틀·선행연구·
> 반박 근거도 포함해줘. 확인 가능한 인용만 — 출처 없는 일반론은 제외.
> ```
> (범위가 넓으면 주제·하위질문별로 2~3회 나눠 Research)
> 3. 결과를 복사 → Code 탭 작업 폴더의 **`02_research/deep_research.md`** 에 저장.
> 4. Code 탭으로 돌아와 **"다음"** → `evidence-harvest-claim-bank`가 claim/source bank로 구조화.

- ⚠️ **Research는 Chat 전용 기능 — Code 탭엔 없음.** 이 단계만 잠깐 Chat에 다녀온다(앱에서 클릭 한 번).
- 🔵 **(선택) ChatGPT 구독자 — ChatGPT '심층 리서치(Deep Research)' 병행 가능.** 위 2번 프롬프트를 브라우저 ChatGPT의 Deep Research로도 돌려 결과를 같은 `02_research/deep_research.md`에 합칠 수 있다(Claude Research와 병행하면 문헌 커버리지↑·상호 교차확인 — 엔진이 서로 놓친 문헌을 메움). 어느 도구로 모았든 **모든 인용은 Step 5 `verify-reference-essential`로 실재 확인**(메모리·환각 인용 금지). GPT는 선택이며 Claude Research만으로도 이 단계는 완결된다.
- Research 미가용(플랜/환경)이면: Code 탭 web search 또는 본인 보유 PDF로 대체하되, **모든 인용은 Step 5 `verify-reference-essential`로 실재 확인**(메모리 인용 금지).
- 같은 단계에서 **`reporting-guideline-router`**로 discipline에 맞는 보고지침(질적=COREQ/SRQR, 양적=STROBE 등, 의사학=사료비판·각주 체계)을 라우팅한다.
- **의사학(P3) 전용 주의**: Chat Research는 현대 문헌(2차 문헌·선행 역사서술)만 찾아준다. **1차 사료(고문서·의무기록·신문·구술 등)는 Research가 대신 찾아줄 수 없다** — 본인이 소장·열람한 사료를 `00_intake/existing_pdfs/`에 넣고, 인용 검증은 Step 5에서 **인간확인 fail-closed**(자동 통과 없음)로 처리한다.

### 4) 안전선 (운전 모드와 무관하게 강제)
- 🔒 **연구윤리 / Human Subjects** — IRB(기관연구윤리위원회) 승인, 연구참여자(인터뷰이·학생·환자 등) 비식별화·동의 문구. **질적연구도 예외 없이 IRB 대상**이다 — "임상시험이 아니니 심의 불요"는 흔한 오해이며, 인터뷰·관찰·설문만으로도 연구참여자가 있으면 심의 대상. (의학교육 연구에 임상 권고·약물 관련 내용이 섞이면 그 부분만 추가 정차.)
- 🔒 **1차 사료 확인 (의사학·P3)** — `verify-reference-essential`이 자동 검증할 수 없는 사료 인용은 인간확인 **fail-closed**(조용한 PASS 금지 → `INCOMPLETE_EXTERNAL_CHECK` 등으로 표면화). anachronism(현재 개념의 과거 투사) 여부도 본인 최종 확인.
- 🔒 **Publication Ethics** — AI 활용 공개문(Claude 단독 사용 명시)·authorship·COI·data availability·저널 정책 불일치 → 강제 정차.
- 🔒 **⑧ Submission · ⑨ Review** — 포털 자격증명·로그인·Submit 버튼·실제 reviewer 원문은 사람이 수행. 실제 제출은 **⑩ Human Final Gate** 통과 후 본인이 누른다.
- 워크숍 산출물 = **submission-directed ≠ submission-ready**.

## 출력
- `.sam/hitl/paper_profile.json`의 `discipline` 필드 (분야 확정, 신규 논문 최초 1회)
- `.sam/hitl/gate_plan.json` (운전 모드)
- `.sam/pipeline_state.json` 갱신 (`current_step`)
- Step 1 진입 — `journal-fit-check` 호출

## HITL Event Emit
세션 시작 직후 `.sam/hitl/events.jsonl`에 1줄 append:
```json
{"ts":"...","step":0,"event_type":"session_start","skill":"start-here","engine":"claude","category":"orchestration","severity":1,"description":"workshop session started, mode=H3 standard"}
```

## 자주 발생하는 함정
1. **운전 모드를 안 받고 바로 작성 시작** — 반드시 1) 맵 → 2) 모드 → 3) Step 1 순서. 모드 미선택 시 🛡️표준(H3) default + 사유 표기.
2. **⑧⑨를 자동으로 넘김** — Submission/Review는 floor라 어떤 모드든 사람. 가상 fixture·worksheet로 연습하고 실제 제출 금지.
3. **개별 단계 재작업 시 start-here 재호출** — 특정 단계만 다시 할 땐 해당 skill을 직접 부른다(여긴 진입/이어가기 전용).
4. **분야(discipline) 미확정 상태로 진행** — 0-b)를 건너뛰면 ②Research·⑤Verify·⑥Critic의 조건 분기가 틀어진다. 신규 논문은 반드시 먼저 분야를 확정.

## 다음 단계
→ 운전 모드 확정 후 **Step 1 `journal-fit-check`** 자동 시작. 이후 각 단계는 gate_plan대로 정차/진행하며 **⑩ Wrap(Human Final Gate)**까지 이어간다.
