---
name: journal-fit-check
description: >
  Use this skill when a humanities/social-medicine author (medical education or
  history of medicine) is at the start of a manuscript and needs to lock article
  type, discipline profile, and a target-journal short list. Trigger when the
  user says "타깃 저널 정해줘", "어느 저널이 맞을까", "article type 추천",
  "journal fit", "저널 후보", "submission target", or operates in Step 1 Idea
  Lock of the sam-medhum pipeline. Do not use for in-depth literature search
  (use ②Research / Chat Research) or for already-locked submission packaging (use
  desk-reject-precheck and the Step 7 packaging flow). Input:
  paper_home/00_intake/topic_seed.md + paper_home/00_intake/paper_profile.json
  (discipline) plus author's available material (interviews / survey / primary
  sources). Output:
  paper_home/01_design/{idea_variants.md, article_type.md, journal_shortlist.md}.
  Pipeline position: sam-medhum Step 1 / Self-Gate A. Context: Korean medical
  education & medical history faculty; qualitative research is the default
  profile; KCI (Korean) and SCI(E)/international targets both in scope. Claude
  single-engine (no external API). Mandatory check on each candidate journal's
  AI-disclosure policy AND whether it actually publishes qualitative / historical
  work. Trigger keywords: 저널, journal, 타깃 저널, target journal, article type,
  의학교육, 의사학, KJME, KMER, Medical Teacher, Medical Education, Academic
  Medicine, Social History of Medicine, 질적연구, qualitative, KCI, SCI, discipline,
  scope fit, ESL.
---

# journal-fit-check (Step 1)

> 인문사회의학 저자(의학교육학·의사학)가 워크숍 시작 시 본인 주제를 가져왔을 때, **10분 안에 분야 프로파일 + article type 잠정 + 저널 short list 2–3개**를 결정하도록 돕는다. 단독 저자 모드, **Claude 단독**(외부 API/키 불요). 다관점 검토는 Claude 인-모델 페르소나로 수행.

## 모드 (3-tier)

| 모드 | 시간 | 용도 |
|---|---|---|
| `workshop-mini` | 10분 | 워크숍 표준 — short list 2–3개 |
| `standard` | 25분 | 사후 작업 — full landscape + 5 후보 |
| `deep-audit` | 45분+ | 본격 투고 전 — 저널 최근호 추이, RR, accept rate |

기본은 `workshop-mini`.

## 입력

- `paper_home/00_intake/topic_seed.md` — 한 문장 주제
- `paper_home/00_intake/paper_profile.json` — `discipline` 필드(P1/P2/P3, 아래 1.0)
- (선택) 본인 보유 material 설명 (인터뷰·관찰 / 설문·척도 / 1차 사료) — 구두
- (선택) 평소 투고하시는 저널 1–2개

## 절차 (workshop-mini, 10분)

### 1.0 분야·언어 라우팅 (30초 — 다른 단계보다 먼저) ★ downstream 분기 기준

`paper_home/00_intake/paper_profile.json`의 `discipline`을 먼저 확정한다. 검증·데스크리젝트 등 downstream 스킬이 이 값으로 분기한다.

| discipline | 분야 | 연구 유형 | 근거 형태 |
|---|---|---|---|
| **P1** (기본·대표) | 의학교육-질적 | 내러티브 탐구/현상학/근거이론/주제분석 | 인터뷰 인용 ↔ 주제 |
| **P2** | 의학교육-양적 | 설문·심리측정·실험 | 수치 · 문헌(PubMed 유효) |
| **P3** | 의사학 | 사료 기반 논증·역사 서술 | 1차 사료 ↔ 주장 · 각주 |

- **원고 언어(`preferred_language`) 선택**: **KCI(국내)** = 국내 게재 실적·한국어 집필 가능(일부 저널 영문도 허용) / **SCI(E)·국제** = 영문 필수·ESL 부담. 본인 영어 집필 여력·목표 독자·실적 목적으로 결정. 결정을 미루면 short list에 KO/EN 후보를 **병기**하고 Self-Gate A1에서 확정.

### 1.1 Idea variants 생성 (2분)

본인 시드 → 2–3개 idea variant 생성. 각 variant는:
- thesis 1문장
- 가능한 article type 후보 1–2개
- 본인 보유 material (인터뷰·관찰 / 설문 / 1차 사료 / 주장)에 맞는지 표시

산출 → `paper_home/01_design/idea_variants.md`

### 1.2 Article type 잠정 결정 (2분)

| 본인 보유 재료 | 분야 | 권고 article type | 2.5h 라이브 도달 가능성 |
|---|---|---|---|
| 인터뷰·관찰 질적 데이터 (IRB OK) | P1 | Original (질적: 주제분석/현상학/내러티브/근거이론) | 주제 구조 + 대표 인용 맵 (완성 draft는 사후) |
| 질적 파일럿 / 소규모 | P1 | Brief report / Research letter (질적) | outline + 핵심 주제 1차 |
| 설문·척도·실험 데이터 | P2 | Original (양적) / Brief report | IMRaD 골격 + 결과표 1차 |
| 1차 사료 + 사료비판 논증 | P3 | Original research article (역사) | 논증 개요 + 사료 대응표 |
| 사료 종합 / 역사 서술 | P3 | Review / 역사서술 논문 (⚠️ 일부 초청제) | outline + 사료맵 |
| 강한 의견 + 근거 문헌 5–10편 | 공통 | Perspective / Commentary / Editorial | submission-directed 가능 |
| 주제 종합 (선행 30+편) | 공통 | Narrative / Scoping Review (⚠️ 초청제 다수) | outline + 근거맵 (1차 draft는 사후) |

→ 본인이 선택. AI는 권고만. article type 값은 `paper_profile.json`의 `article_type` enum(original_article·brief_report·letter·viewpoint·commentary·editorial·narrative_review)에 매핑해 기록.

※ **IRB / 연구윤리는 article type으로 우회할 문제가 아니라 제출 가능성 red flag**:
- **P1·P2 (인간 대상)** — 질적연구도 **IRB 승인 + 연구참여자 비식별** 필수. 인터뷰 인용의 재식별 위험 사전 점검.
- **P3 (사료)** — 통상 IRB 비대상이나, **생존 인물·유족 관련·미공개 아카이브**는 이용 허가·저작권·아카이브 윤리 확인 선행.

※ Narrative/Scoping Review·의사학 Review는 다수 저널이 초청(invited)제 — 비초청(unsolicited) 접수 여부를 저널 공식 페이지에서 확인 후 선택.

산출 → `paper_home/01_design/article_type.md`

### 1.3 Scope-Fit Gate + Journal short list 2–3개 (5분) ★ desk reject 1차 방어선

> **조건 충족(word limit·정책) ≠ scope fit.** desk reject의 흔한 사유는 "outside scope / narrow focus / limited innovation" — 형식이 아니라 적합성이다. **분야 무관** (JAMIA #19 desk-reject 교훈). 각 후보마다 Scope-Fit 5종을 먼저 채운다.

**필수 ① — Scope-Fit Gate (후보당 5종):**
- **Aims & Scope 적합 논증** — 공식 Aims & Scope 1줄 요약 + "이 원고가 이 저널 독자에게 주는 새 가치" 1문장 (공식 페이지 미확인 시 `잠정` 표기)
- **질적/역사 방법 수용 여부** ★ 신규 — 이 저널이 **실제로 질적연구(P1)·양적(P2)·사료 기반 역사연구(P3)를 게재**하는가? 최근 1–2년 호에서 **동종 방법** 논문 1편 확인. 일부 저널은 질적·비실증·역사 방법을 방법론만으로 desk-reject한다 (방법-미스매치 = scope-미스매치)
- **유사 논문 실증** — 최근 1–2년 이 저널에 비슷한 주제·유형 논문 1–2편 (제목 수준; 빠른 확인 한도, 못 찾으면 `②Research에서 확인` 표기 — 못 찾는 것 자체가 red flag 신호)
- **Desk-reject red flag 1개** — "에디터가 이 원고를 거절한다면 그 사유는?" (Claude 인-모델 악마의 변호인 페르소나)
- **Fit verdict** — `Strong` / `Possible` / `Risky` / `Mismatch`
  - `Strong`·`Possible` = 투고 후보 유지
  - `Risky` = scope 의문 — 투고 전 Step 1(Scope-Fit) 재정의 권고. 실제 투고 목표이면 hitl-dial-recommender가 **최소 H3 + 투고 보류(C/D gate 필수)** 가드레일 발동
  - `Mismatch` = outside scope 확정 — **가장 강한 가드레일: do-not-submit.** 저널 교체 또는 Step 1 전면 재정의 전 투고 금지 (Risky와 동일 경로로 최소 H3 발동, 강도는 최상). JAMIA #19 desk-reject 재발 방지선

**필수 ② — 조건:**
- **저널명 (full + abbreviation)** + **분야(P1/P2/P3)** + **유형(KCI / SCI(E) / 국제)**
- **AI 사용 공시 정책** ★ — accept / disclosure required / strict. 공식 instructions 인용으로 확정하기 전까지 `잠정` 표기 (워크숍 중 미확인이면 `미확인`으로 남기고 투고 전 확정)
- **Word limit** (article type별)
- **Reporting / 방법 보고 요건** — 질적=COREQ/SRQR, 양적=STROBE 등, 역사=보고지침 비대상(사료비판·서술 완결성으로 대체). reporting-guideline-router 자동 라우팅 참조
- **원고 언어** (KO / EN)

**선택 (가능하면 — 추정 금지, 모르면 비움):**
- 최근호 turnaround·게재 경향 / ESL 친화성 / (KCI) 심사료·게재료
- **추천 사유** 1–2 문장

산출 → `paper_home/01_design/journal_shortlist.md`

### 1.4 Self-Gate A1 결정 (1분)

본인이 결정:
- [ ] Discipline: P1 / P2 / P3
- [ ] 원고 언어: KO / EN
- [ ] Article type 잠정: ___
- [ ] Target journal short list: 1차 ___ / 2차 ___ / 3차 ___
- [ ] 2.5h 라이브 commitment: "오늘 ___까지 도달한다"

→ `paper_home/01_design/decision_history.md`에 기록

## 저널 DB (예시 seed — 최신 아님 · 투고 전 공식 페이지 당일 확인 필수)

> 아래 표의 정책·질적 친화성은 작성 시점 **추정/개괄** — **확정은 저널 공식 Instructions for Authors 직접 인용으로만**. 저널별 상세 specs(word limit·섹션 구성·AI 정책 원문·질적/역사 방법 수용)는 Step 2 Research에서 공식 페이지 기준으로 수집.

### P1/P2 — 의학교육 (Medical Education)

| 저널 (full / abbr) | 유형 | 언어 | 질적 친화(추정) | AI 정책(추정) | 비고 |
|---|---|---|---|---|---|
| 한국의학교육 (Korean J Med Educ, **KJME**) | KCI | KO/EN | 중~상 | Disclosure required (잠정) | 대한의학교육학회 · 국내 실적 |
| 의학교육논단 (Korean Med Educ Rev, **KMER**) | KCI | KO/EN | 상 (리뷰·논단) | Disclosure (잠정) | ⚠️ 리뷰·논단 중심 (초청 많음 — 확인) |
| Medical Teacher (Med Teach) | SCI(E) | EN | 중 (실무·양적 강) | Disclosure (잠정) | AMEE · 실무 지향 |
| Medical Education (Med Educ) | SCI(E) | EN | **상 (질적 전통 강함)** | Disclosure (잠정) | 질적·이론 연구 친화 |
| Academic Medicine (Acad Med) | SCI(E) | EN | 중~상 (혼합) | Disclosure (잠정) | AAMC · 정책·질적 병행 |
| Advances in Health Sciences Education (Adv Health Sci Educ) | SCI(E) | EN | **상 (이론·질적)** | Disclosure (잠정) | 이론 지향 |
| Perspectives on Medical Education (Perspect Med Educ, **PME**) | SCI(E)·OA | EN | **상 (질적·이론 친화)** | Disclosure (잠정) | 오픈액세스 |
| BMC Medical Education (BMC Med Educ) | SCI(E)·OA | EN | 중 (광범·질적 수용) | Disclosure (잠정) | ⚠️ APC · 대량 게재 |

> P2(양적)는 위 저널 대부분에서 STROBE 등 보고지침 요구 가능 — reporting-guideline-router 참조.

### P3 — 의사학 (History of Medicine)

| 저널 (full / abbr) | 유형 | 언어 | 방법 | AI 정책(추정) | 비고 |
|---|---|---|---|---|---|
| 의사학 (Korean J Med Hist) | KCI | KO/EN | 사료 기반 역사연구 | Disclosure (잠정) | 대한의사학회 |
| 연세의사학 (Yonsei J Med Hist) | KCI | KO/EN | 역사·인문 | Disclosure (잠정) | 연세대 의학사연구소 |
| Social History of Medicine (Soc Hist Med) | 국제(SSCI) | EN | 사회사·질적 | Disclosure (잠정) | 사회사 지향 |
| Bulletin of the History of Medicine (Bull Hist Med) | 국제 | EN | 의학사 정통 | Disclosure (잠정) | Johns Hopkins |
| Medical History (Med Hist) | 국제 | EN | 의학사 | Disclosure (잠정) | Cambridge |

> 의사학·역사 저널은 본질상 서술·질적 — reporting checklist(CONSORT/STROBE 등)를 요구하지 않는다. 대신 **사료비판·아카이브 출처·논증 완결성**이 심사 축.

## Solo + Claude-only 다관점 (외부 API 불요)

기본 동작이 Claude 단독. 외부 도구·API 키 불필요.

선택적 보조 — **Claude 인-모델 멀티페르소나**로 후보 저널별 교차 질문:
- **에디터 페르소나**: "이 원고를 desk reject 한다면 사유는?" (악마의 변호인)
- **질적방법론가 / 역사가 페르소나**: "이 저널이 이 방법론을 실제로 게재하는가? 최근 호 근거는?"
- 결과는 참고용 — **확정은 공식 페이지 인용**. (외부 LLM·멀티모델 포털은 이 fork에서 사용하지 않음)

## Output 표준

### `idea_variants.md`
```markdown
# Idea Variants
## V1 — {thesis}
- Article type 후보: ...
- Material 적합성: ...
## V2 — {thesis}
...
```

### `article_type.md`
```markdown
# Article Type 잠정 결정
- Discipline: P1 / P2 / P3
- 선택: {type}  (paper_profile enum 매핑: original_article 등)
- 사유: ...
- 2.5h 라이브 도달점: ...
```

### `journal_shortlist.md`
```markdown
| 순위 | 저널 | 분야/유형/언어 | Scope fit (1문장) | 방법 수용 | Fit verdict | Reject risk | AI 정책 | Word limit | 추천 사유 |
|---|---|---|---|---|---|---|---|---|---|
| 1차 | Medical Education | P1/SCI/EN | 의학교육 질적연구 환영 — 본 주제 부합 | 질적 게재 다수 확인 | Strong | 유사 논문 미확인 시 novelty 의문 | Disclosure required (잠정) | ~5000 | 질적 전통, 국제 노출 |
| 2차 | 한국의학교육(KJME) | P1/KCI/KO | 국내 의학교육 · 한국어 가능 | 질적 게재 확인 | Possible | scope 광범 | Disclosure (잠정) | 확인 필요 | 국내 실적, ESL 부담 낮음 |
| 3차 | ... |
```

> **Fit verdict 값(4종):** `Strong` / `Possible` / `Risky` / `Mismatch`. `Risky`·`Mismatch`는 실제 투고 목표 시 hitl-dial-recommender 하드 가드레일(최소 H3 + 투고 금지)을 발동한다 — `Mismatch`가 가장 강한 do-not-submit 신호(outside scope 확정). verdict 칸이 비었거나 `잠정`이면 미확인으로 간주되어 동일 가드레일이 걸린다. **방법 수용 칸이 "미확인"이면 Fit verdict를 최소 `Risky`로 내린다** (질적/역사 방법 desk-reject 방지).

## HITL Event Emit

skill 종료 시:
```json
{"ts":"...","paper_id":"...","step":1,"gate":"A_design","event_type":"gate_pass","skill":"journal-fit-check","engine":"claude","category":"design_lock","severity":1,"description":"discipline=P1, article type=original_article, journals=[Medical Education,KJME]","time_to_fix_min":10}
```

## 결정적 vs LLM 분리

- **LLM 판단**: idea variant 생성, article type 권고, 저널 권고 사유, 방법-수용 추정, 다관점 페르소나 검토
- **결정적(사용자·공식 페이지 확인)**: AI 정책 (저널 instructions for authors 직접 인용), 질적/역사 방법 실제 게재 여부 (저널 최근호 목차), KCI/SCI 인덱스 여부, word limit

→ AI 정책·방법 수용은 **저널 공식 페이지를 직접 인용/확인**하라고 사용자에게 요청. 메모리에서 추정 금지.

## Self-Gate A1 체크리스트

- [ ] **Discipline(P1/P2/P3) 확정** — downstream 분기 기준
- [ ] **1차 저널 Aims & Scope를 공식 페이지에서 확인 + fit 1문장 작성** (공식 scope 확인 전 1차 확정 금지)
- [ ] **1차 저널이 본 방법(질적/역사/양적)을 실제 게재하는지 최근호로 확인** (미확인이면 Fit verdict ≤ Risky)
- [ ] 후보마다 desk-reject red flag 1개 + Fit verdict 기록
- [ ] Article type이 2.5h 라이브 안에 도달 가능한가 (완성 아님, 도달점 명시)
- [ ] Target 저널 1차의 AI 정책 확인 (공식 인용 기준; 미확인이면 `미확인` 표기 → 투고 전 확정)
- [ ] Word limit·원고 언어(KO/EN)가 본인 material·집필 여력에 맞는가
- [ ] 방법 보고 요건(COREQ/SRQR/STROBE / 역사=비대상) 확인
- [ ] AI disclosure 문구 표준(Claude 단독 명시) 미리 본인 인지

## 자주 발생하는 함정

1. **article type을 너무 넓게** — 2.5h 라이브 안엔 도달점(주제맵·논증개요)까지만 약속, submission-ready 아님
2. **저널 AI 정책 미확인** — 일부 저널은 draft·critic에 AI 사용 자체를 제한. 사전 확인 필수 (공시는 Claude 단독 명시)
3. **질적/역사 방법 desk-reject** ★ — 조건이 다 맞아도 저널이 그 방법론을 게재하지 않으면 방법-미스매치로 반려. 최근호에서 동종 방법 논문 확인 필수
4. **ESL 비친화 (국제 저널)** — 영문 폴리싱 부담 큼. KCI(한국어) 대안도 병기해 비교
5. **조건 충족 = fit 착각** — word limit·정책이 다 맞아도 scope가 어긋나면 desk reject ("outside scope, narrow focus"). Scope-Fit Gate를 건너뛰지 말 것 — 실제 투고 사고(JAMIA #19)에서 추가된 방어선

## 다음 단계 (Self-Gate A 통과 시)

→ Step 2 Research(Chat Research 핸드오프) + journal_specs 수집
