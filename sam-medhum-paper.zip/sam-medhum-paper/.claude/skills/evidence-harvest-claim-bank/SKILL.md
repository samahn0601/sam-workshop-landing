---
name: evidence-harvest-claim-bank
description: >
  Use this skill at Step 2 (after Chat Deep Research and/or ingesting the author's
  own data) to convert raw material into a structured claim bank + source bank
  with stable claim IDs that all downstream skills (story-design,
  verify-reference-essential, critic, humanize) reference. The claim↔evidence
  anchor is discipline-conditional: qualitative med-education (P1, default) =
  claim ↔ interview quote/coded theme (de-identified excerpt); quantitative
  med-education (P2) = claim ↔ numeric result/citation; history of medicine (P3)
  = claim ↔ primary source (with archival locator). Trigger when user says "claim
  bank", "evidence map 만들어줘", "근거 정리", "deep research 정리", "인용-주제
  매핑", "사료 정리", "structured evidence", "claim_id", or operates between Step
  2 and Step 3. Do not use for raw web search (use Chat Deep Research first) or
  verification (verify-reference-essential). Input:
  paper_home/02_research/deep_research.md + paper_home/.sam/hitl/paper_profile.json
  (discipline) + (optional) 00_intake/ transcripts/PDFs/source-notes. Output:
  paper_home/02_research/{source_bank.jsonl, claim_bank.jsonl, evidence_table.md}.
  Pipeline position: sam-medhum Step 2.5 (between Deep Research and Outline).
  Context: source-claim traceability, de-identified participant quotes, primary
  source human-confirm (fail-closed), no memory-cited references. Trigger
  keywords: claim bank, source bank, evidence harvest, 근거 정리, 인용 매핑,
  사료 정리, claim ID, deep research 정리, supporting evidence.
---

# evidence-harvest-claim-bank (Tier 1 — Step 2 hand-off skill)

> **Step 2 → Step 3 hand-off의 결정적 봉합.** ②Research raw markdown(+본인 자료)을 구조화된 claim/source bank로 변환. 모든 downstream skill이 같은 claim_id 공유 → 검증·critic·humanize에서 factual/의미 drift 추적 가능. **엔진 = Claude 단독.**

## 분야 분기 (근거의 형태가 다르다)

`paper_home/.sam/hitl/paper_profile.json`의 **`discipline`**에 따라 source/claim 모델이 바뀐다:

- **P1 의학교육-질적 (기본)** — claim ↔ **인터뷰 인용/코딩된 주제**(비식별 발췌 + code/theme + 참여자 비식별 ID).
- **P2 의학교육-양적** — claim ↔ **수치 결과/인용**(effect size + 출처).
- **P3 의사학** — claim ↔ **1차 사료**(사료 인용/요약 + **archival locator**).

> `discipline` 미기록이면 P1로 가정하고 명시(fail-closed).

## ★ 절대 원칙 — "no memory-cited references" (fail-closed)

**모든 source·인용·발췌·사료 로케이터는 ②Research 산출로 추적 가능해야 한다** — `deep_research.md`(Chat Research 핸드오프), 저자가 지참한 자료(전사·데이터셋·사료 노트), 제공된 PDF. **LLM 메모리에서 인용/수치/발췌/소장처를 지어내는 것은 절대 금지.** 원천 없는 항목은 `[NO_VERBATIM]`/`[INCOMPLETE]`/`PENDING_HUMAN_SOURCE_CHECK`로 표면화(조용한 생성 금지).

## 모드

| 모드 | 시간 | 산출 |
|---|---|---|
| `workshop-mini` | 15분 | 핵심 claim 10–20개 + source 5–15개 |
| `standard` | 30분 | + limitation tagging + risk flag |
| `deep-audit` | 60분 | + verbatim/사료원문 모든 claim + 교차확인 |

## 입력

- `paper_home/02_research/deep_research.md` — Chat DR 결과
- `paper_home/.sam/hitl/paper_profile.json` — discipline
- (선택) `paper_home/00_intake/` — 본인 자료: P1 인터뷰 전사·코딩표 / P2 데이터셋·PDF / P3 1차 사료 노트·이미지
- `paper_home/01_design/article_type.md` — 문맥 (claim 선별 우선순위)

## 1단계 (5분) — Source bank 추출

```
당신은 evidence librarian입니다. discipline에 맞춰 첨부 자료에서 모든 source를
추출하여 source_bank.jsonl 생성. 공통 필드 + discipline 확장:

공통:
{ "source_id":"S001", "type":"...", "title":"...", "year":..., "url":"...",
  "verification_status":"PENDING_VERIFY" }

P1 type: interview_transcript | focus_group | coded_excerpt | field_note
        | journal_article | book_chapter | guideline
   + "participant_id":"P03"(비식별), "deidentified":true
P2 type: journal_article | guideline | government_db | dataset | preprint
   + "doi","pmid","authors","journal"
P3 type: archival_document | manuscript | periodical | government_record
        | oral_history | secondary_literature
   + "repository":"국사편찬위원회", "collection":"...", "shelfmark/box":"...",
     "document_date":"1931", "primary":true|false

규칙:
- 중복 제거 (P2=DOI/PMID, P3=repository+shelfmark, P1=참여자+발췌 기준)
- 메타데이터 부족 시 그대로 "[INCOMPLETE]" 마크 (LLM 추정 금지)
- P1 발췌·P3 사료 로케이터는 원천(전사/사료)에 있는 그대로만
```
산출 → `paper_home/02_research/source_bank.jsonl`

## 2단계 (8분) — Claim bank 추출

```
당신은 claim extractor입니다. 논문 작성에 쓸 claim을 claim_bank.jsonl로. 공통 +
discipline 확장:

공통:
{ "claim_id":"C001", "claim_text":"...", "claim_type":"...",
  "risk_level":"high|medium|low", "source_ids":["S003"],
  "intended_section":"...", "review_status":"PENDING_HUMAN_RATIFY",
  "locked":false }

P1 (질적):
  claim_type: theme | interpretation | pattern | context
  "quote_support":"P03: '실패했을 때 오히려 다시 배우게 됐어요'"  // 비식별 verbatim
  "code_or_theme":"reframing failure"
  "participant_ids":["P03","P11"]
  risk=high 조건: 일반화/인과 주장, 또는 참여자 재식별 위험 인용
P2 (양적):
  claim_type: epidemiology | outcome | comparison | psychometric | guideline
  "verbatim_support":"Kim 2024 abstract: '...'", "effect_size":"r=-.34"
  risk=high 조건: safety/mortality/guideline-changing
P3 (사학):
  claim_type: event | causation | interpretation | historiographic
  "primary_source_support":"위생연보 1931, p.42: '...'(인용/요약)"
  "archival_locator":"S007 (국편 소장, 컬렉션 X)"
  "secondary_positioning":"기존 서술 Y를 갱신"
  risk=high 조건: 단일/이견 있는 사료에만 의존, 또는 인과·전환 주장

규칙:
- P1: quote_support 없으면 "[NO_VERBATIM]" + risk=high
- P2: verbatim_support(초록 인용) 없으면 "[NO_VERBATIM]" + risk=high
- P3: 1차 사료 근거 claim은 전부 "review_status":"PENDING_HUMAN_SOURCE_CHECK"
       (자동검증 불가 — 인간확인 fail-closed)
- claim_id C001부터 순차, 중복 claim 통합
```
산출 → `paper_home/02_research/claim_bank.jsonl`

## 3단계 (2분) — Evidence table (사람이 읽는 형식)

```markdown
# Evidence Table  (discipline: P1)

## High-risk claims (일반화·인과 / 재식별 위험 / 단일사료)
| claim_id | claim | 근거 | flag |
|---|---|---|---|
| C007 | 전공의는 실패를 재학습으로 재해석 | P03·P11 인용 | 과일반화 주의 |

## Medium / Low
| claim_id | claim | 근거 |
|---|---|---|
| C002 | 시간적 재배치 패턴 | P03 인용 |

## 인간확인 대기
- P1 [NO_VERBATIM]: C012 → 전사 원문 확인
- P3 PENDING_HUMAN_SOURCE_CHECK: C019 → 사료 원본 대조

## 통계
- Total 15 · High 3 · Medium 9 · Low 3 · 인간확인 대기 2 (→ Step 5 우선)
```
산출 → `paper_home/02_research/evidence_table.md`

## HITL Event Emit

```json
{"ts":"...","step":2,"gate":"A_design","event_type":"gate_pass","skill":"evidence-harvest-claim-bank","engine":"claude","category":"evidence_structure","severity":2,"description":"P1: 15 claims (3 high), 2 need human quote/source check for Step 5","time_to_fix_min":15}
```

## 결정적 vs LLM 분리

- **LLM**: claim/source 추출, type 분류, verbatim/사료 발견, risk_level 판단.
- **결정적**: 중복 merge, claim_id 순차 부여, JSONL schema validation, 인간확인 대기 목록 산출.

## Solo + Claude-only

기본 Claude 단독. P2 인용 실재 검증은 ⑤에서 P2-only 스크립트 `${CLAUDE_SKILL_DIR}/../_shared/scripts/ref_verify_pubmed.py`(verify-reference-essential 경유)로. P1 인용·P3 사료는 **인간확인**(스크립트 아님).

## Floor (절대 위임 불가) — discipline별

- **P1**: 참여자 **비식별·기밀 유지**(IRB) — 재식별 가능 인용은 high-risk, 저자가 발췌 원문 직접 확인·수정. (Publication Ethics floor의 질적연구 대응.)
- **P2**: safety/mortality/guideline claim의 verbatim_support는 저자가 abstract 직접 확인.
- **P3**: 1차 사료 **실재·정확·로케이터**를 저자가 원본 대조(자동검증 불가 → fail-closed 인간확인 체크리스트). ⑩ Human Final Gate에서 재확인.

## Downstream 연결 (가장 중요한 가치)

| Skill | 사용 |
|---|---|
| `story-design` | claim_bank를 outline/주제에 매핑 (evidence_map.md) — **핵심 handoff** |
| `verify-reference-essential` | high-risk·인간확인 대기 claim sampling (P2=PubMed, P1/P3=인간) |
| `critic-multi-persona` | claim_id 단위 critique (Claude 인-모델 페르소나) |
| `humanize-en/ko` | locked claim_id 의미 보존 (인문 학술 레지스터) |

→ **claim_id는 워크숍 전체의 공통 단위.** 통일된 추적이 desk reject·의미 drift 면역력의 핵심.

## Self-Gate A 체크리스트

- [ ] discipline에 맞는 근거 필드 채움 (P1 quote/theme·P2 verbatim/수치·P3 사료/locator)
- [ ] 모든 claim에 source_ids (또는 누락 마크)
- [ ] High-risk claim 식별 (P1 재식별·과일반화 / P2 safety / P3 단일사료)
- [ ] 인간확인 대기 목록 생성 (P1 [NO_VERBATIM] / P3 PENDING_HUMAN_SOURCE_CHECK)
- [ ] 중복 claim 통합

## 자주 발생하는 함정

1. **메모리에서 인용/사료 지어냄** — 최대 위험. ②Research 산출에 없으면 마크. P3 소장처를 상상으로 채우지 말 것.
2. **P1 참여자 재식별** — 인용에 소속·희귀 상황이 노출 → 비식별 처리 + high-risk.
3. **P3 사료를 조용히 PASS** — 자동확인 불가인데 확인된 척 → 반드시 PENDING_HUMAN_SOURCE_CHECK.
4. **Risk_level 과소평가** — P1 "모든 전공의가~"(과일반화), P3 단일 사료 인과 주장을 medium으로.
5. **section 매핑 누락** — claim이 어느 섹션/주제에 들어갈지 미정 → story-design에서 혼란.

## 다음 단계

→ Self-Gate A2 → Step 3 story-design (claim_bank를 outline/주제에 매핑)
