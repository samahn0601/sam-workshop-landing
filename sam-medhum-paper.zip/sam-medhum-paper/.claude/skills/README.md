# Sam MedHum Skill Pack v1.0.0 (sam-medhum)

> **인문사회의학**(의학교육학·의사학) 교수용 Claude Skill Pack. 대상: 2026-07-12(토) 9:30–12:00, 의학교육학 교수 1 + 의사학 교수 1, 각 **개인 Claude Max** 구독. 단독저자 모드, Code 탭 중심, HITL Dial 4-gate supervised 표준.
> **`sam-workshop`**(임상·IMRaD 의학논문 5h 교육팩)의 인문사회의학 fork. 빌드 근거(SSOT)는 `_MEDHUM_BUILD_ANCHOR.md` — 이 README와 상충하면 앵커가 우선.
> v1.0.0 변경 (2026-07-07~08, fork 1차): `exam-item-builder` 제거(18→17 skill, 의사국시형 문항은 인문사회 논문과 무관) + **분야(discipline) intake 신설**(Step ①에서 의학교육-질적/의학교육-양적/의사학 확정 → `paper_profile.json` 기록 → downstream 조건분기) + **critic 페르소나 전면 교체**(질적 방법론가·의학교육 학자·역사가/의사학자 + Editor) + **Claude 단독화**(Gemini API·GPT API 호출 전부 제거 — "다관점 비평"은 Claude 인-모델 멀티페르소나로 구현, API 키 불요) + 인문사회 학술 문체(임상 문체 아님)로 레지스터 전환. Base: sam-workshop v1.5.0.

## 3 분야 (discipline) — Step ①에서 확정, downstream 조건부

| 코드 | 분야 | 근거 유형 | 보고지침 |
|---|---|---|---|
| **P1** (기본·대표) | 의학교육-질적 | 인터뷰 인용 ↔ 주제 | COREQ / SRQR |
| **P2** | 의학교육-양적 | 수치·PubMed | STROBE 등 |
| **P3** | 의사학 | 1차 사료 ↔ 주장 (자동검증 불가 → 인간확인 fail-closed) | 사료비판·각주 체계 |

`start-here`가 세션 시작 시 확정해 `paper_profile.json`의 `discipline` 필드에 기록한다. ②연구 방식·⑤검증 전략·⑥critic 페르소나가 이 값을 참조해 조건 분기한다. 참가자는 각자 본인 자료(인터뷰 전사록, 설문 데이터, 1차 사료 등)를 지참 — 특정 논문 하드코딩 없음(범용 파이프라인). 타깃 저널(KCI+SCI, 3분야) DB는 `journal-fit-check` 참조.

## Claude 단독 — 외부 엔진 없음

본 fork는 **Gemini API·GPT API를 호출하지 않는다.** 개인 Claude Max 구독 하나로 전체 파이프라인이 완결되며 API 키가 전혀 필요 없다. sam-workshop(임상팩)에서 "외부 LLM critic(선택)"·"3엔진"으로 불리던 것은 sam-medhum에는 존재하지 않는다 — critic·검증의 "다관점"은 **Claude가 여러 학술 페르소나를 순차 연기하는 인-모델 멀티페르소나**로 구현된다(`critic-multi-persona` 참조). 어딘가에 Gemini/GPT/외부 LLM critic 언급이 남아 있다면 fork 과정의 잔재이니 무시하거나 정정한다.

## 설치

### 받는 방법 — ZIP-first (git 불필요)

`sam-medhum-paper.zip`을 내려받아 압축 해제한다(참가자는 git·CLI를 몰라도 된다). 압축 해제 후 아래 "평평 복사"만 하면 끝. 공개 repo는 없다 — 랜딩 페이지에서 ZIP + `medhum.html` 안내만 게시.

### 옵션 A — 평평(flat) 복사 (표준 · Desktop Code 탭 실측 검증)

⚠️ **우산 폴더 금지** — Code 탭 skill 탐지는 `.claude/skills/<skill>/SKILL.md` **1단계만** 인식. 본 폴더(sam-medhum)째 복사하면 2단계가 되어 전부 미탐지(실측). **내용물**(진입점 start-here + 작업 skill 16 + `_shared` = 18 폴더)을 `.claude/skills/` 바로 아래로:

```bash
# Mac/Linux (작업 폴더 paper_home 기준 — 전역이면 ~/.claude/skills):
mkdir -p <paper_home>/.claude/skills
cp -R sam-medhum/. <paper_home>/.claude/skills/

# Windows (PowerShell):
Copy-Item -Recurse -Force sam-medhum\* "<paper_home>\.claude\skills\"
```

권장 경로는 Code 탭 자연어 설치(압축 해제 → 평평 복사를 Claude가 대행). 설치 후 **새 세션** 필요(skill은 세션 시작 시 스캔).

### 옵션 B — 심볼릭 링크 (개발용 · skill별 개별 링크)

```bash
# 우산 링크(ln -s …/sam-medhum)는 2단계라 미탐지 — skill별로:
cd sam-medhum && for d in */ ; do ln -s "$(pwd)/$d" ~/.claude/skills/"$d"; done
```

설치 확인 (평평 — `.claude/skills/` 바로 아래):
```
.claude/skills/
├── README.md (이 파일)
├── CLAUDE.md                                 ★ 파이프라인 정체성/floor 요약
├── _MEDHUM_BUILD_ANCHOR.md                   ★ 빌드 SSOT
├── _shared/
│   ├── schemas/ (6 JSON schemas)
│   ├── scripts/ (6 Python scripts)
│   └── templates/ (6 markdown templates)
├── start-here/SKILL.md                       ★ 진입점 (분야 확정 → 흐름 시작)
├── journal-fit-check/SKILL.md
├── story-design/SKILL.md
├── verify-reference-essential/SKILL.md
├── stats-consistency/SKILL.md
├── critic-multi-persona/SKILL.md
├── scorecard-9d/SKILL.md
├── figure-prompt-eng/SKILL.md
├── humanize-en/SKILL.md
├── humanize-ko/SKILL.md
├── desk-reject-precheck/SKILL.md
├── section-boundary/SKILL.md
├── reporting-guideline-router/SKILL.md
├── verify-7layer/SKILL.md
├── revision-response/SKILL.md
├── hitl-dial-recommender/SKILL.md
└── evidence-harvest-claim-bank/SKILL.md
```

Claude Desktop 재시작 후 자연어로 skill 자동 발화 가능.

## Skill Pack 구성 (진입점 1 + 작업 16)

### 🚀 진입점 (Entry) — 한 번 부르면 전체 흐름 시작

| Skill | 역할 |
|---|---|
| **start-here** | 분야(discipline) 확정 → 10-step 맵·운전 모드 제시 → `gate_plan` 작성 → Step 1부터 각 작업 skill을 자동 호출·안내. 참가자가 작업 skill 이름을 몰라도 흐름을 탄다(정차 ①⑤⑥⑩·연구윤리 floor 유지). 첫 발화: **"시작하자"** / "어디서부터" |

> 아래 **작업 skill 16개**는 외울 필요 없이 start-here가 단계마다 자동 호출한다. (원하면 이름으로 직접 호출도 가능)

### Tier 1 — 핵심 실습 (워크숍 시연·실습)

| # | Skill | Step | 묶음 |
|---|---|---|---|
| 1 | journal-fit-check | 1 | Idea Lock |
| 2 | evidence-harvest-claim-bank | 3 | Story & Outline (claim/source 분리) |
| 3 | story-design | 3 | Story & Outline |
| 4 | verify-reference-essential | 5 | Verify (with stats-consistency; P3는 1차 사료 인간확인 fail-closed) |
| 5 | stats-consistency | 5 | Verify (P2 위주) |
| 6 | **critic-multi-persona** | 6 | Critic — 질적방법론가/의학교육학자/역사가·의사학자(분야 조건부) + Editor, **Claude 인-모델**(with scorecard-9d) |
| 7 | scorecard-9d | 6 | Critic |
| 8 | figure-prompt-eng | 7 | Humanize & Package 내 figure brief (옵션) |
| 9 | humanize-en 또는 humanize-ko | 7 | Humanize & Package (인문사회 학술 문체로 윤문, locked claims drift check) |

### Tier 2 — 자동 호출 또는 5분 데모

| # | Skill | 사용 |
|---|---|---|
| 10 | desk-reject-precheck | Step 7 quick scan |
| 11 | section-boundary | scorecard-9d 차원 9 자동 |
| 12 | reporting-guideline-router | journal-fit-check/Step 2 내부 자동 (분야별 보고지침 라우팅) |
| 13 | verify-7layer | post-workshop full audit |
| 14 | (선택 안 한 humanize 언어) | 부록 |

### Tier 3 — Post-workshop only

| # | Skill | 사용 |
|---|---|---|
| 15 | revision-response | R&R 받았을 때 |

### Meta — Workshop wrap

| # | Skill | 사용 |
|---|---|---|
| 16 | hitl-dial-recommender | 워크숍 마지막 + 사후 매 논문 종료 시 |

## 의존성

### 필수
- **Claude Desktop (Code 탭)** — 개인 Claude Max 구독 1개면 충분. 외부 API 키 전혀 불요.
- Python 3.9+ (결정적 검증 스크립트용 — 시스템에 이미 있을 가능성 높음)

### 선택
- python-docx (Step 7/8 `.docx` manuscript 변환 시): `pip install python-docx`

> sam-workshop(임상팩)에 있던 "선택: ChatGPT/Gemini 외부 critic·figure" 항목은 여기 없다 — critic의 다관점은 Claude 인-모델 멀티페르소나로 대체됐다(위 "Claude 단독" 절). `figure-prompt-eng`는 이미지 생성 도구 프롬프트를 만들어주는 보조 skill로 성격이 달라 경량 유지.

## 10-step 스파인

정본 파이프라인: **1 Idea Lock → 2 Deep Research → 3 Story & Outline → 4 Draft → 5 Verify → 6 Critic → 7 Humanize & Package → 8 Submission → 9 Review Response → 10 Wrap & Next.**
운전 모드(`gate_plan`) + 정차 ①⑤⑥⑩는 discipline과 무관하게 동일 — 상세는 `start-here/SKILL.md`, 시각화는 `_shared/templates/pipeline_map.md`.
각 skill이 어느 step에 쓰이는지는 위 "Skill Pack 구성" 표 참조. (figure-prompt-eng = step 7 옵션, hitl-dial-recommender = step 10)

## Skill 사용 예 (자연어 트리거)

```
"시작하자" / "어디서부터" → start-here (분야 확정부터)
"내 논문 어느 저널에 투고할까?" → journal-fit-check
"outline 짜줘" → story-design
"reference/사료 검증" → verify-reference-essential
"통계 일관성 점검" → stats-consistency (P2)
"critic 받아줘" → critic-multi-persona
"점수 매겨줘" → scorecard-9d
"figure prompt 만들어줘" → figure-prompt-eng
"AI 시그니처 제거" → humanize-en (영문) / humanize-ko (국문)
"투고 전 마지막 점검" → desk-reject-precheck
"섹션 경계 확인" → section-boundary
"reporting checklist" → reporting-guideline-router
"full 7-Layer 검증" → verify-7layer
"reviewer 응답 작성" → revision-response (post-workshop)
"다음 논문 dial 처방" → hitl-dial-recommender (workshop wrap)
```

## 폴더 구조 표준

각 논문 = Code 탭 작업 폴더 1개 = 로컬 폴더 1개:

```
paper_home/
├── 00_intake/
├── 01_design/
├── 02_research/
├── 03_outline/
├── 04_draft/        ← manuscript.md (Live Artifact)
├── 05_verify/
├── 06_critic/
├── 07_figures/
├── 08_package/
└── .sam/
    ├── hitl/events.jsonl
    └── memory/
```

자세한 규약: `_shared/templates/paper_home_layout.md`

## 7개 공통 개선 항목 (모든 skill 적용)

1. ★ Description 자동 트리거 7요소 (when use, when NOT use, input, output, pipeline 위치, self-gate, discipline context)
2. ★ Solo + Claude-only (외부 엔진 자체가 없음 — Claude 다중 페르소나가 기본값, "fallback"이 아니라 유일한 경로)
3. ★ Time-budget 3 모드 (workshop-mini / standard / deep-audit)
4. 결정적 검증 vs LLM 추론 분리 (DOI/PMID/regex는 script, 의미·해석은 LLM)
5. Code 탭 로컬 폴더 상대경로 표준화
6. Structured output 표준 (issue table / scorecard / checklist / JSONL log)
7. HITL Event Emit hook (모든 skill 종료 시 `.sam/hitl/events.jsonl` append)

## HITL Floor (영구 — dial과 무관, 모든 skill 적용)

다음 4영역은 **항상 본인 결정** (위임 불가):

1. **연구윤리 / IRB / 연구참여자 비식별** — 질적연구도 예외 없음(인터뷰·관찰·설문만으로도 연구참여자가 있으면 심의 대상)
2. **1차 사료의 맥락·번역·anachronism (의사학)** — 자동검증 불가, 인간확인 fail-closed
3. **AI 활용 공개문 / authorship / COI** (Publication Ethics) — 저널 정책 확인 포함
4. **Reference/사료 인용 핵심 paraphrase 검증** — desk reject 직접 트리거. 확인 안 된 인용을 근거 문장만으로 통과시키지 않는다

## Self-Gate (4개)

| Gate | 위치 | 통과 기준 |
|---|---|---|
| **A_design** | Step 1+3 후 | journal locked, outline 통과, evidence map 작성 |
| **B_draft** | Step 5 후 | verify-reference-essential PASS, stats-consistency 정당화(P2) 또는 사료 인간확인 완료(P3) |
| **C_verify_critic** | Step 6 후 | scorecard-9d ≥ 32, 차원 9 = Pass |
| **D_finish** | Step 7 후 | scorecard-9d ≥ 36, desk-reject-precheck 0 critical fail (작성 완료 게이트 — 제출 전 최종 검증·제출은 ⑩ Human Final Gate) |

## HITL Dial 5단계

| Dial | 이름 | 워크숍 사용 |
|---|---|---|
| H4 | 10-gate hand-holding | 초보자 옵션 |
| **H3** | 4-gate standard | **워크숍 default** |
| H2 | 2-gate accelerated | 경험자 옵션 |
| H1 | 1-gate Auto-Pilot | 워크숍 미사용 (사후 옵션) |
| H0 | 0-gate Sakana style | 논문 제출용 비권장 |

## 라이센스 / 출처

- 기반: Sam AI Pipeline (sam-ai-autopilot v1.x, sam-ai-collab v1.x) → sam-workshop(임상 워크숍팩) v1.5.0 → **sam-medhum**(인문사회의학 fork)
- 워크숍 변형: 단독저자 모드, **Claude 단독**(API 키 불요 — Gemini/GPT 등 외부 엔진 미사용)
- 작성: 안상현 (Sam, MD) — 2026-07
- 라이센스: 워크숍 참가자 본인 사용 (재배포는 출처 표기)

## 다음 작업

- [ ] 나머지 재조율 담당분(story-design·section-boundary·scorecard-9d·reporting-guideline-router·evidence-harvest-claim-bank / journal-fit-check·verify-reference-essential·desk-reject-precheck) 완료 후 통합 검증
- [ ] 전체 skill pack에 남은 `sam-workshop` 문자열 잔재 일괄 정리(코디네이터)
- [ ] 신규 fresh-machine 설치 리허설 (평평 복사 실측)
- [ ] 참가자 사전 안내문 작성 (`medhum.html` 랜딩)

미해결 항목·앵커 상세는 `_MEDHUM_BUILD_ANCHOR.md` 참조.

## 문의 / 개선 제안

안상현 (Sam) — admin@modoc-ai.com — 본 skill pack에 대한 피드백/이슈/개선 제안.

---

🎯 본 skill pack은 교수 1년+ 라이프사이클 자산입니다. 워크숍 2.5h는 시작점.
