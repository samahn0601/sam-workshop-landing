---
name: section-boundary
description: >
  Use this skill to detect discipline-appropriate structure/boundary problems in
  a humanities/social-medicine manuscript. For qualitative med-education (P1,
  default): missing reflexivity/positionality, themes not grounded in quotes,
  quote-dumping without analysis, over-generalization/causal language,
  abstract↔findings theme mismatch — NOT the strict IMRaD Results↔Discussion
  split (integration is allowed). For quantitative med-education (P2): classic
  IMRaD boundary violations (interpretation in Results, new data in Discussion).
  For history of medicine (P3): argument/sources/analysis/contribution flow +
  footnote norms (claims anchored to sources, primary/secondary distinction).
  Trigger when user says "섹션 경계", "구조 점검", "section boundary", "성찰성
  누락", "인용 근거", "IMRaD 위반", "각주 규범", or after Step 4 Draft / Step 6
  Revision. Frequently auto-invoked by scorecard-9d (dimension 9). Do not use for
  figure caption (figure-prompt-eng) or reference verification
  (verify-reference-essential). Input: paper_home/04_draft/manuscript.md +
  paper_home/.sam/hitl/paper_profile.json (discipline). Output:
  paper_home/05_verify/section_boundary.md (Pass/Fail + issues list).
  Pipeline position: sam-medhum after Step 4 (auto), before Self-Gate C.
  Context: qualitative trustworthiness structure, IMRaD discipline, historical
  argument apparatus — the structure problems reviewers catch most. Trigger
  keywords: section boundary, 구조, 섹션 경계, 성찰성, 인용 근거, IMRaD, 각주,
  reflexivity, thematic structure.
---

# section-boundary (Tier 2 — auto)

> 분야별 **구조/경계 문제** 자동 검출. scorecard-9d 차원 9(Pass/Fail)와 직접 연동. **엔진 = Claude 단독.**

## 분야 분기 (먼저 읽는다)

`paper_home/.sam/hitl/paper_profile.json`의 **`discipline`**에 따라 검사 규칙이 완전히 다르다. **엉뚱한 규칙을 적용하면 오탐** — 특히 P1 질적연구에 IMRaD를 강요하지 않는다:

- **P1 의학교육-질적 (기본)** → 신뢰성 구조 검사(Q1–Q5). Results↔Discussion 통합 허용.
- **P2 의학교육-양적** → 고전 IMRaD 경계 검사(B1–B5).
- **P3 의사학** → 논증 흐름 + 각주 규범 검사(H1–H5).

> `discipline` 미기록이면 P1로 가정하고 명시(fail-closed).

## 모드

기본 자동(scorecard-9d 호출 시 함께). 단독 실행도 가능.

| 모드 | 시간 |
|---|---|
| `workshop-mini` | 5분 |
| `standard` | 15분 (수정 제안 포함) |

## 입력

- `paper_home/04_draft/manuscript.md`
- `paper_home/.sam/hitl/paper_profile.json` (discipline)

---

## P1 의학교육-질적 — 검사 유형 (기본)

| 유형 | 설명 | 심각도 |
|---|---|---|
| **Q1** 성찰성/위치성 누락 | Methods에 연구자 위치성(positionality)·성찰성(reflexivity) 진술 없음 | Major |
| **Q2** 주제-인용 미정박 | Findings의 주제가 예시 인용(발췌)으로 뒷받침 안 됨 | Major |
| **Q3** 과일반화/인과 언어 | "입증했다·일반화된다·유의하게 ~을 야기" 등 양적 주장 언어 | Major |
| **Q4** 인용 나열(quote-dump) | 발췌만 나열되고 분석적 해석이 없음 | Minor→Major |
| **Q5** Abstract↔Findings 주제 불일치 | Abstract의 주제가 본문 Findings에 없음(또는 반대) | Major |

> **금지된 오탐**: P1에서 "Results에 해석이 있다"(B1)를 위반으로 잡지 말 것 — 질적연구는 해석을 findings에 녹이는 것이 정상이며 통합형(Findings+Discussion)도 허용된다. 신뢰성(trustworthiness) 요소 = credibility·transferability·dependability·confirmability의 절차 흔적(member checking, thick description, audit trail)이 Methods에 **있는지**를 본다(내용 품질 채점은 scorecard-9d).

### P1 절차 (5분)
```
당신은 질적연구 구조 검사관입니다. discipline=P1. 다음 manuscript에서:
Q1: Methods에 연구자 위치성·성찰성 진술이 있는가 (없으면 flag)
Q2: 각 Findings 주제가 최소 1개 예시 인용(참여자 발췌)으로 정박됐는가
Q3: 과일반화·인과·통계적 유의성 언어 검출 ("입증", "일반화", "유의하게 야기")
Q4: 해석 없이 인용만 나열된 문단(quote-dump) 검출
Q5: Abstract의 주제 목록 ↔ 본문 Findings 주제 목록 대조
각 이슈: 위치 / 유형 / 인용 문구 / 권고(어떻게 고칠지)
종합: 이슈 0건 → Pass / 1건 이상 → Fail (scorecard 차원 9)
```

---

## P2 의학교육-양적 — IMRaD 경계 (임상팩 골격 유지)

| 유형 | 설명 | 심각도 |
|---|---|---|
| **B1** Results 해석 | Results에 "이는 ~을 시사한다" 류 해석 | Major |
| **B2** Discussion 새 데이터 | Discussion에 처음 등장하는 수치/표 | Major |
| **B3** Methods → Results 누수 | Methods에 결과 진술("우리는 ~을 발견했다") | Minor |
| **B4** Intro에 결론 | Intro에 본 연구 결론("우리는 ~을 보였다") | Minor |
| **B5** Abstract ↔ 본문 불일치 | Abstract에 본문에 없는 결과·결론(수치 상이 자체는 stats-consistency 담당) | Major |

### P2 절차 (5분)
```
당신은 IMRaD 섹션 경계 검사관입니다. discipline=P2.
B1: Results에서 해석성 문장("시사한다","의미한다","해석할 수 있다") 검출
B2: Discussion에서 Results에 없던 수치(N,%,p,OR/HR/RR/CI)·표·그림 처음 등장
B3: Methods에서 결과 진술 검출
B4: Introduction에서 본 연구 결과 진술 검출
B5: Abstract에 있는데 본문에 없는 결과·결론 검출(수치 일치는 stats-consistency)
각 위반: 위치 / 유형 / 인용 / 어디로 옮길지(또는 삭제)
종합: 0건 → Pass / 1건+ → Fail
```
> 수치 일관성 검증은 P2-only 스크립트 `${CLAUDE_SKILL_DIR}/../_shared/scripts/stats_consistency_check.py`(stats-consistency)가 별도 담당 — 본 스킬은 존재/위치만.

---

## P3 의사학 — 논증 흐름 + 각주 규범

| 유형 | 설명 | 심각도 |
|---|---|---|
| **H1** 논지 부재 | Introduction에 논문의 주장(thesis)이 명시되지 않음 | Major |
| **H2** 주장-사료 미정박 | 실질 주장이 각주/인용(사료)에 정박되지 않음 | Major |
| **H3** 각주 규범 위반 | 인용 양식 불일치·1차/2차 사료 미구분·1차 사료 로케이터(소장처·컬렉션·연도) 누락 | Major |
| **H4** 서술↔분석 불균형 | 연대기 나열만 있고 분석적 기여(argument) 부재 | Minor→Major |
| **H5** 역사서술적 기여 부재 | Conclusion에 기존 서술을 어떻게 갱신하는지 없음 | Major |

> **금지된 오탐**: P3에 IMRaD를 적용하지 말 것 — "Discussion에 새 자료"(B2)나 "Results에 해석"(B1)은 의사학에서 위반이 아니다(사료·분석·서술이 통합됨). 대신 논지→사료→분석→기여 흐름과 각주 규범을 본다.

### P3 절차 (5분)
```
당신은 역사학 논문 구조 검사관입니다. discipline=P3.
H1: Introduction에 명시적 논지(thesis statement)가 있는가
H2: 각 실질 주장이 사료 각주/인용에 정박됐는가 (근거 없는 단정 flag)
H3: 각주 양식 일관성 / 1차·2차 사료 구분 / 1차 사료 로케이터(소장처·컬렉션·문서명·연도) 유무
H4: 순수 연대기 서술만 있고 분석/논증이 없는 구간 검출
H5: Conclusion에 역사서술적 기여(기존 서술 갱신)가 있는가
각 이슈: 위치 / 유형 / 인용 / 권고
종합: 0건 → Pass / 1건+ → Fail
```
> P3 1차 사료의 **실재·정확성**은 자동검증 불가 → evidence-harvest의 `PENDING_HUMAN_SOURCE_CHECK` + ⑩ Human Final Gate에서 인간확인(fail-closed). 본 스킬은 각주가 **형식상 갖춰졌는지**만 본다.

---

## Output 표준

`paper_home/05_verify/section_boundary.md`:

```markdown
# Section / Structure Check  (discipline: P1)

## 종합: Fail

## 이슈
| # | 유형 | 위치 | 인용 문구 | 권고 |
|---|---|---|---|---|
| 1 | Q1 | Methods | (성찰성 진술 없음) | 연구자 위치성·성찰성 1단락 추가 |
| 2 | Q2 | Findings §2 Theme 2 | "전공의들은 재학습했다" | 예시 인용(발췌) 최소 1개 정박 |
| 3 | Q3 | Discussion §1 | "이는 재학습을 유의하게 야기한다" | 인과·유의성 언어 → 해석적 표현으로 |

## scorecard-9d 차원 9: Fail
```

## HITL Event Emit

```json
{"ts":"...","step":4,"gate":"B_draft","event_type":"gate_fail","skill":"section-boundary","engine":"claude","category":"structure_violation","severity":3,"description":"P1: 3 issues (Q1 reflexivity, Q2 ungrounded theme, Q3 causal language)"}
```

(실행은 Step 4 직후 가능 — 결과는 B_draft 판정 입력 + scorecard-9d 차원 9로 전달. 본 스킬은 flag만, Pass/Fail 종합 판정은 scorecard가.)

## 자주 발생하는 함정

1. **분야 오적용** — P1 질적연구에 IMRaD(B1 "Results 해석")를 들이대는 것이 최대 오탐. discipline을 먼저 읽어라.
2. **P1 성찰성 누락(Q1)** — 의학교육자가 양적 습관으로 위치성 진술을 빠뜨림 → reviewer 1순위 지적.
3. **P1 quote-dump(Q4)** — 인용만 붙이고 분석 없음.
4. **P3 논지 부재(H1)** — 흥미로운 사료는 많은데 argument가 없음.
5. **P3 로케이터 누락(H3)** — 1차 사료를 소장처·컬렉션 없이 인용 → 검증 불가.

## 다음 단계

→ 이슈 수정 → scorecard-9d 차원 9 Pass → Self-Gate C
