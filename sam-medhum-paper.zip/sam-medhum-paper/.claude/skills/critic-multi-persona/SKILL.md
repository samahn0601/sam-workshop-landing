---
name: critic-multi-persona
description: >
  Use this skill when a humanities/social-medicine manuscript draft (의학교육
  질적/양적 또는 의사학) needs reviewer-style critique before submission:
  methodological weakness (질적=trustworthiness, 양적=validity/statistics,
  의사학=source criticism), educational or historiographical significance,
  structure problems, and reward-hacking risk. Implemented entirely as
  **Claude in-model multi-persona** — 질적 방법론가, 의학교육 학자,
  역사가/의사학자, Editor — activated per paper_profile.json's `discipline`,
  integrated by an Area Chair persona. Runs by default as Claude-only in-model
  multi-persona (no external engine, no API key required); a participant with a
  ChatGPT subscription MAY optionally add GPT as one extra independent critic
  (browser paste or Codex OAuth) — opt-in, never required, never replacing the
  Claude personas. Trigger when user says "critic", "리뷰어 시각",
  "심사자처럼 봐줘", "weakness 점검", "area chair", "전문가 비평", "peer review
  simulation", or operates in Step 6 Critic of the sam-medhum pipeline. Do not
  use for reference verification (use verify-reference-essential) or grammar
  polish (use humanize-en/ko). Input: paper_home/04_draft/manuscript.md (and
  post-Step-5 verify reports + journal_shortlist.md + paper_profile.json의
  discipline 필드). Output: paper_home/06_critic/{claude_personas.md,
  area_chair_round1.md, revision_backlog.jsonl}. Pipeline position: sam-medhum
  Step 6 / Self-Gate C. Medical context: ICMJE 원고 비평 표준, COREQ/SRQR
  trustworthiness 기준(질적), 사료비판·historiography(의사학), RH1-RH4
  reward-hacking 방어. Trigger keywords: critic, 리뷰어, 비평, peer review,
  area chair, weakness, reviewer, critique, 질적 방법론, 사료비판, 역사서술.
---

# critic-multi-persona (Step 6)

> 분야별(discipline-conditional) peer review simulation. 기본은 **Claude 단독** 다중 페르소나 → Area Chair 통합(외부 엔진 불요·API 키 불요) — 워크숍 표준 모드. ChatGPT 구독자는 GPT를 **선택적 제2 관점**으로 추가 가능(아래 "선택: GPT 제2 관점" 절).

## 모드

| 모드 | 시간 | 페르소나 |
|---|---|---|
| `workshop-mini` | 35분 | discipline별 활성 Claude 페르소나(2–3개) → Area Chair |
| `standard` | 60분 | + RH1-RH4 reward hacking full check |
| `deep-audit` | 90분+ | + 저널-specific mock review + (선택) 비활성 페르소나 1개 교차 실행 |

## 페르소나 — discipline 조건부 활성화

`paper_home/.sam/hitl/paper_profile.json`의 `discipline` 값을 먼저 읽고 아래 표대로 활성화한다. 값이 없으면 진행 전 사용자에게 확인(start-here 0-b에서 이미 확정되어 있는 것이 정상 경로).

| 페르소나 | 의학교육-질적 (P1) | 의학교육-양적 (P2) | 의사학 (P3) |
|---|---|---|---|
| **질적 방법론가** | ✓ 필수 | 조건부 — mixed-methods 요소가 있을 때만 | — |
| **의학교육 학자** | ✓ 필수 | ✓ 필수 (방법론 관점 겸임 — 아래 참조) | — |
| **역사가/의사학자** | — | — | ✓ 필수 |
| **Editor** | ✓ 필수 | ✓ 필수 | ✓ 필수 |

> P2(양적)에는 별도 통계 페르소나를 두지 않는다 — 수치 정합성 자체는 Step 5 `stats-consistency`가 이미 검증했으므로, Step 6에서는 **의학교육 학자**가 측정도구 타당도·표본·일반화가능성·인과관계 해석까지 겸해서 본다(중복 방지).

| 페르소나 | 시각 | 출력 |
|---|---|---|
| **질적 방법론가** | trustworthiness(신뢰성/전이성/의존성/확증성), 성찰성, COREQ/SRQR | top 3 weakness |
| **의학교육 학자** | 교육적/이론적 유의미성, 이론-실천 정합성, (P2 겸임) 방법론적 타당도 | top 3 weakness |
| **역사가/의사학자** | 사료비판, historiography, anachronism, 각주 체계 | top 3 weakness |
| **Editor** | 구조, 학술적 함의, novelty, 저널 fit, desk-reject risk | top 3 strategic comment |
| **Area Chair** (Claude) | 통합, RH1–RH4 reward hacking 체크 | Must Fix / Should Fix / Optional |

## 입력

- `paper_home/04_draft/manuscript.md`
- `paper_home/.sam/hitl/paper_profile.json` — `discipline` (페르소나 활성화 조건)
- `paper_home/05_verify/verification_certificate.md` (Step 5 통과 확인)
- `paper_home/03_outline/story_1pager.md` (편집 ↔ 본문 일관성 체크)
- `paper_home/01_design/journal_shortlist.md` (있으면 — Editor가 Scope fit·Fit verdict·Reject risk 반영)

## 절차 (workshop-mini, 35분)

### Phase 1 (20분) — Claude 페르소나 critique (discipline별 2–3개 활성)

각 페르소나 프롬프트를 Code 탭에서 **순차·독립** 발화(페르소나당 6–7분). 이전 페르소나의 산출을 다음 페르소나 프롬프트에 포함하지 않는다 — 앵커링·수렴을 막아 단일 모델 안에서도 관점 차이를 강제하기 위함(아래 "Claude 단독" 절 참조).

#### Persona: 질적 방법론가 (P1 필수 / P2 조건부)
```
당신은 질적연구 방법론 전문가(Qualitative Methodologist)입니다. 다음
manuscript의 방법론적 엄정성(trustworthiness)을 top 3 지적하세요. 각
지적에: location(section+paragraph) / issue(구체적) / severity(Major/Minor)
/ suggested_fix / reward_hacking_risk(RH1-RH4 중 해당 시 표시).

점검 항목:
- Credibility(신뢰성) — 삼각검증·참여자 확인(member checking)·충분한 관여
- Transferability(전이성) — thick description으로 맥락이 충분히 기술되었는가
- Dependability(의존성) — audit trail·연구 절차 투명성
- Confirmability(확증성) — 연구자 성찰성(reflexivity) 진술 존재
- COREQ/SRQR 항목 충족(표본 선정·자료수집·분석 절차 명시)
- 인용-주제 연결 — 제시된 인터뷰 인용이 실제로 해당 주제/코드를 지지하는가
  (과대해석·선택적 인용 여부)
- 표본 크기·이론적 포화(theoretical saturation) 근거 제시 여부

RH1(한계 나열로 점수 올리기): "한계" 섹션만 추가했는가
RH2(검증 우회): 결정적 검증 없이 LLM/저자 의견만으로 통과
RH3(이중 카운트): 같은 이슈를 여러 곳에 흩어 점수 분산 회피
RH4(과장): "최초로/유일하게/결정적으로"로 over-claim
```

#### Persona: 의학교육 학자 (P1·P2 필수)
```
당신은 의학교육학(Medical Education) 학자입니다. 다음 manuscript를 교육학적
관점에서 top 3 지적하세요. 각 지적에 location/issue/severity/suggested_fix/
reward_hacking_risk.

점검 항목:
- Educational significance — 이 연구가 교육자·학습자에게 "그래서 가르침/배움이
  실제로 어떻게 달라지는가"에 답하는가(so-what)
- Theory-practice gap — 이론적 틀(성인학습이론·사회구성주의·Kirkpatrick 등)이
  분석·해석과 실제로 정합적으로 연결되는가, 장식적 인용에 그치지 않는가
- 선행 의학교육 문헌과의 접점(반복 vs 확장 vs 반박)이 명확한가
- (discipline = 의학교육-양적일 때 추가 점검 — 별도 통계 페르소나가 없으므로
  겸임) 측정도구 타당도·신뢰도 보고, 표본 대표성과 일반화가능성, 인과관계 vs
  상관관계 구분, 통계 보고 형식(n/%/p/95% CI) 일관성, 다중비교·교란 처리

RH1-RH4 기준은 질적 방법론가 프롬프트와 동일.
```

#### Persona: 역사가/의사학자 (P3 필수)
```
당신은 의사학(醫史學, History of Medicine) 학자입니다. 다음 manuscript를
역사서술 관점에서 top 3 지적하세요. 각 지적에 location/issue/severity/
suggested_fix/reward_hacking_risk.

점검 항목:
- Source criticism(사료비판) — 1차 사료와 2차 문헌이 구분되어 인용되는가,
  사료의 생산 맥락(누가·언제·왜 작성했는가)이 검토되었는가
- Historiographical framing — 이 논문이 어떤 역사서술 전통/논쟁 지형에
  위치하는지 명시되는가(사실 나열이 아니라 해석적 논증인가)
- Anachronism — 현재의 의학 개념·범주·가치판단을 과거 행위자에게 투사하는
  오류가 있는가(예: 과거 의료행위를 현대 의료윤리 기준만으로 재단)
- 각주 체계 정합성 — 사료 인용의 위치(문서명·소장처·연도)가 추적 가능한가
- 사료 접근의 한계(훼손·편향·부분 보존·번역 문제)가 명시되는가

RH1-RH4 기준 동일. (RH4 과장은 의사학에서 "최초로 밝혀진" 류 표현으로 특히
잦다 — 선행연구 누락 여부를 우선 점검.)
```

#### Persona: Editor (전체 필수)
```
당신은 target 저널의 Editor입니다. journal_shortlist.md가 있으면 그 안의
Scope fit·Fit verdict·Reject risk를 먼저 읽고 반영하세요(Fit verdict가
Risky면 그 사유를 1순위 코멘트로). 본 manuscript에 대해:
- 본 저널 scope 부합?
- Novelty/기여가 독자(교육자·연구자·역사가)에게 실제 가치가 있는가?
- 학술적·실무적 함의가 명확한가?
- Section structure가 저널·보고지침(COREQ/SRQR, STROBE류, 또는 사학 논증
  서사) 표준을 준수하는가?
- One-sentence message가 abstract와 일치하는가?

Top 3 strategic comment + accept_likelihood(low/medium/high) + 사유.
```

산출 → `paper_home/06_critic/claude_personas.md`

### Phase 2 (10분) — Area Chair 통합 (Claude)

```
당신은 Area Chair입니다. 다음 입력을 통합:
- claude_personas.md (이번 논문의 discipline에서 활성화된 페르소나 전원)

다음 산출:
1. 모든 issue를 claim_id 단위로 정리(location 기반 식별자)
2. 두 개 이상 페르소나가 동일 지적 → Must Fix
3. 한 페르소나만 + 타당 → Should Fix
4. 한 페르소나만 + 선택적 → Optional
5. 페르소나 간 상반된 지적 → Sam 판정 + 사유

RH1-RH4 Reward Hacking 체크:
- RH1: limitations만 추가한 척 → reject
- RH2: 검증 없이 의견만으로 통과 → reject
- RH3: 이슈 분산 → reject
- RH4: over-claim → reject

Score-Driven Revert 알림(scorecard-9d 산출이 **있을 때만**):
- v2 → v3 변경 시 종합 scorecard 비교
- 점수 ↓ → 즉시 revert 권고
- scorecard 산출 없으면 명시적으로 skip — 점수 임의 생성 금지

Output:
- Must Fix 목록(우선순위 순)
- Should Fix 목록
- Optional 목록
- Reward hacking으로 reject한 항목 + 사유
```

산출 → `paper_home/06_critic/area_chair_round1.md`

### Phase 3 (5분, Self-Gate C 결정)

본인이:
- [ ] 모든 Must Fix 채택 또는 사유 명시 reject
- [ ] Should Fix 중 시간 허락하는 것 채택
- [ ] Reward hacking reject 항목 재검토
- [ ] manuscript.md 즉석 수정

## Claude 단독 — 다관점을 실제로 분리하는 법

이 skill은 **기본적으로** Claude 하나로 전체 페르소나를 수행한다(외부 엔진 없음, API 키 불요). 단일 모델의 사각지대(같은 학습데이터·같은 맹점)를 줄이기 위해:

1. 각 페르소나는 **독립적으로** 실행 — 이전 페르소나의 산출을 다음 프롬프트에 포함하지 않는다(앵커링·수렴 방지).
2. 페르소나마다 위에 명시된 **서로 다른 점검 항목**을 그대로 사용 — 관점이 겹치면 페르소나를 나누는 의미가 없다.
3. Area Chair(Phase 2)에서 페르소나 간 지적이 서로 겹치기만 하고 **불일치가 하나도 없다면 오히려 의심**하고, "이 지적에 반대 관점이 있다면?"을 자문한다(단일모델 동조 위험 상쇄).
4. deep-audit 모드에서는 discipline상 비활성인 페르소나 1개를 추가로 짧게 돌려 교차 확인할 수 있다(예: P1 논문에 역사가 페르소나를 "이 결과를 역사적 맥락에서 보면?"으로 짧게 투입).

## (선택) GPT 제2 관점 — ChatGPT 구독자 adjunct

기본 경로는 위 Claude 단독 멀티페르소나로 **완결**된다(외부 엔진·API 키 불요). 다만 단일 모델의 사각지대를 한 번 더 줄이고 싶고 **ChatGPT 구독이 있는** 참가자는, GPT를 **독립된 추가 심사자 1인**으로 선택 투입할 수 있다:

- **간단(권장)** — `claude_personas.md`(또는 manuscript 요지 + 핵심 쟁점)를 브라우저 ChatGPT에 붙여넣고 *"가장 가혹한 독립 심사자로서 top 3 weakness를 location / issue / severity(Major·Minor) / suggested_fix로, RH1–RH4 해당 시 표시"* 로 요청. 설정 불요, 구독만 있으면 됨.
- **무과금 연결(Codex OAuth)** — Code 탭에서 Claude에게 *"codex로 GPT에게 이 원고 비평을 받아줘"* 로 지시(ChatGPT 구독 쿼터 사용 · 별도 `OPENAI_API_KEY` 과금 없음). ⚠️ 환경에 따라 codex 설정이 필요할 수 있고, 안 되면 위 '간단' 경로로 대체 — 결과 가치는 동일하다.

GPT 산출은 **Area Chair(Phase 2)에 또 하나의 독립 origin(`GPT`)** 으로 넣는다(페르소나 1인처럼 취급). Claude 페르소나와 **불일치하는 지적일수록 가치가 크다** — 단일 모델 동조 위험을 상쇄하는 것이 GPT를 더하는 유일한 이유다(위 "Claude 단독" 3번과 같은 취지). `revision_backlog.jsonl`의 `origin`에 `GPT` 조합으로 표기(예: `"GPT+MES-01"`).

> ⚠️ **선택(opt-in)이며 워크숍 필수가 아니다.** GPT 없이 Claude 단독으로도 Step 6은 완전하다. 학술적 해석·채택 결정·연구윤리·1차 사료 판단은 GPT 관여와 무관하게 **저자 최종 책임**(아래 Floor 유지). GPT 출력도 미검증 인용·주장을 담을 수 있으므로 Step 5 검증 원칙이 그대로 적용된다.

## Output 표준

### `area_chair_round1.md`
```markdown
# Area Chair Round 1

## Must Fix (우선순위 순)
| # | claim_id | location | issue | persona | suggested_fix |
|---|---|---|---|---|---|
| 1 | C-Methods-3 | 방법 §3.2 | 성찰성(reflexivity) 진술 부재 | QM | 연구자 위치성 문단 추가 |
| 2 | ... |

## Should Fix
| ... |

## Reward Hacking Rejected
| # | original | reject reason |
|---|---|---|
| 1 | "한계 여러 개를 나열해 점수 올리려는 의도" | QM detected: cosmetic only |

## Score Comparison (v2 → v3 if applicable)
| 차원 | v2 | v3 (예상) |
|---|---|---|
| 방법론적 엄밀성 | 3 | 4 |
```

### `revision_backlog.jsonl` (표준 포맷 — 필수)

Area Chair가 채택한 모든 항목 + reward-hacking으로 거부한 항목 모두 한 줄씩 JSONL로 emit. humanize/drift-check가 입력으로 사용하므로 **다음 필드 모두 필수**.

| 필드 | 타입 | 의무 | 설명 |
|---|---|:---:|---|
| `id` | string | ✓ | "AC-01", "AC-02" 형식 순차 |
| `section` | string | ✓ | "§3", "abstract", "references" 등 위치 |
| `severity` | enum | ✓ | "major" / "minor" |
| `accepted` | boolean | ✓ | true=채택, false=reject |
| `action` | string | ✓ | 1문장 명령형("Add reflexivity statement per §3.2") |
| `origin` | string | ✓ | 원 페르소나 식별자 조합("QM-02+MES-01" 형식 — QM=질적방법론가, MES=의학교육학자, HIST=역사가/의사학자, ED=Editor) |
| `claim_id` | string | — | claim_bank 참조 시(있으면) |
| `reward_hacking_reason` | string | — | reject 시 사유(RH1-RH4 표시 또는 자유 텍스트) |
| `score_impact` | object | — | `{"dim_2_methods": "+1"}` 형식(scorecard-9d 연동 시) |

#### 예시

```jsonl
{"id":"AC-01","section":"§3.2","severity":"major","accepted":true,"action":"Add reflexivity/positionality statement","origin":"QM-02+MES-01"}
{"id":"AC-08","section":"references","severity":"minor","accepted":true,"action":"Distinguish primary vs secondary source citation format","origin":"HIST-04"}
{"id":"AC-XX","section":"§7","severity":"minor","accepted":false,"action":"Inflate limitations list","origin":"QM-rh","reward_hacking_reason":"QM: limitations만 추가하여 점수 ↑ 의도"}
```

#### 검증

`humanize-en/ko`는 `accepted: true`만 입력으로 받음. `accepted: false`는 audit trail로만 보존하며 본인 사후 검토용. 포맷 위반 시 humanize skill이 `revision_backlog_format_invalid` 카테고리로 HITL event emit.

## HITL Event Emit

각 critic 의견 채택/거절 시:
```json
{"ts":"...","step":6,"gate":"C_verify_critic","event_type":"critique_decision","skill":"critic-multi-persona","engine":"claude_personas","category":"methods_critique","severity":3,"description":"Reflexivity statement missing","decision":"accepted","backlog_id":"AC-01"}
```

## 결정적 vs LLM 분리

전부 LLM. 단:
- Reward hacking 체크는 **rule-based**(RH1-RH4 정의 기반)
- Score comparison은 **결정적**(수치 비교 — scorecard-9d 산출 있을 때만)

## Floor (절대 위임 불가)

- **학술적 해석·결론의 방향** — AC가 채택해도 본인 최종 결정
- **IRB / 연구윤리** — AC 의견과 무관하게 본인 검토(질적연구도 예외 없음)
- **1차 사료의 맥락·번역·anachronism 판단(의사학)** — AC 의견과 무관하게 본인 최종 확인
- **Reward hacking 거부** — AC가 reject한 것 중 본인이 valid하다 판단하면 다시 채택 가능(단 사유 명시)

## Self-Gate C 체크리스트

- [ ] Must Fix 100% 처리
- [ ] Score-Driven Revert 발동 시 본인 ratify
- [ ] Reward hacking reject 항목 본인 검토
- [ ] manuscript.md 수정 반영

## 자주 발생하는 함정

1. **AC가 모든 critic 채택** — 거꾸로 reward hacking. 본인 판단 무 → reject 일부 정당
2. **페르소나들이 서로 수렴** — 독립 실행을 안 지키면(이전 페르소나 산출을 다음 프롬프트에 끼워 넣으면) Claude 단독 특성상 관점이 비슷해진다. Phase 1 절차대로 순차·독립 실행 유지
3. **Editor 페르소나가 too positive** — accept_likelihood 너무 후함. "가장 가혹한 desk editor" 페르소나 강화
4. **Score 비교 없이 진행** — scorecard-9d 산출이 있으면 v2/v3 비교 필수, 없으면 명시적으로 skip(임의 점수 금지)
5. **discipline과 안 맞는 페르소나만 돌림** — 예: 의사학 논문에 질적 방법론가만 돌리고 역사가/의사학자를 빠뜨림. Phase 1 진입 전 표(위)로 활성 페르소나 재확인

## 다음 단계

→ Self-Gate C 통과 → Step 7 Humanize & Package (figure brief는 step 7 옵션)
