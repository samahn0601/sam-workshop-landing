---
name: tutor-automation
description: >
  자동화 사다리 L3(스킬화)와 L4(예약 실행)를 실습하는 모듈(M4) — 수강생 본인의
  반복 업무를 SKILL.md로 박제하고, 필요하면 Claude cron/routine 또는 GPT Tasks
  로 예약 실행까지 연결한다. Trigger when the learner already has a defined
  workflow (L1/L2 완료) and wants to make it trigger by natural language, asks
  "이걸 자동으로 하고 싶다", "스킬로 만들고 싶다", "예약해서 돌리고 싶다",
  "매주 자동으로", "SKILL.md 어떻게 만들어", "computer use가 뭐야". Do not use
  before the learner has at least an L1 workflow defined (send them back to
  the relevant topic module first — tutor-writing-track / tutor-stats-track /
  tutor-paper-track / tutor-apps-basics). Input: 수강생이 이미 정의한 워크플로우
  (L1/L2 산출물) + learner_profile.json의 subscriptions(Claude/GPT 등급 —
  cron/Tasks 가용성 확인용). Output: 해당 업무의 SKILL.md 초안(L3) 및/또는
  예약 실행 설정 가이드(L4) + progress.md의 졸업 체크 갱신. Pipeline position:
  automation_ladder L3→L4 (모듈 M4, 졸업 모듈). Medical context: 환자정보를
  다루는 업무는 예약 실행(L4) 대상에서 제외 — 사람의 매번 검토가 필요한 업무는
  L2/L3에 머무르게 안내한다. Trigger keywords: 자동화, 스킬 만들기, SKILL.md,
  예약 실행, cron, routine, GPT Tasks, computer use, 매번 자동으로, 졸업,
  automation module, skill authoring, scheduled task.
---

# tutor-automation — 자동화 사다리 상단 모듈 (M4, 졸업 모듈)

> **v1 스켈레톤 — 수강생 수요 확인 후 증축.** 지금은 목차와 수업 골격만 정의되어 있다. 실제 수강생이 자동화하려는 업무의 성격(글쓰기? 통계? 논문 단계?)에 따라 아래 절을 구체 예시로 채운다.
>
> 이 모듈은 앵커 §0의 졸업 기준 — "본인 업무 하나가 자동으로 돈다" — 을 향해 가는 마지막 단이다. `automation_ladder.md`의 L3·L4 정의를 그대로 따른다.

## 전제 조건

- 수강생이 이미 자신의 업무를 **L1(워크플로우 정의) 이상**으로 정리해두었어야 한다. 아직이라면 이 모듈을 시작하지 말고 해당 주제 모듈(M0~M3)로 먼저 안내한다.

## 목차 (골격)

### 1. L3 — 스킬화: SKILL.md 만들기

- SKILL.md의 3요소를 함께 정리한다: **언제 발동하는가(트리거 문구) / 무엇을 입력받는가 / 무엇을 출력하는가**.
- `${CLAUDE_SKILL_DIR}/../_shared/templates/skill_description_pattern.md`(참조 팩 sam-medhum 계승, Agent E가 lint 기준으로 사용)의 7요소 방식을 쉬운 말로 풀어 안내한다 — 수강생은 프레임워크 이름을 몰라도 된다, "언제/무엇을 받아서/무엇을 내놓는지"만 명확히 적으면 된다.
- 실제로 트리거 문구 몇 개를 말해보고 스킬이 반응하는지 함께 확인하는 실습을 포함한다.

### 2. L3 실습 — 직접 만들어보기

- 수강생 본인의 업무 하나를 골라 SKILL.md 초안을 함께 작성한다.
- 완성 후 실제로 자연어 한 마디로 불러서 동작하는지 확인한다.

### 3. L4 — 예약 실행 소개

- Claude 쪽: cron/routine 개념 (정해진 시간에 자동으로 스킬/작업이 실행됨).
- GPT 쪽: Tasks 기능 개념 (동일한 목적, 다른 앱).
- 두 경로 모두 "무엇을 예약해도 되는가"의 기준을 먼저 짚는다: 반복적이고, 결과 검토 부담이 가벼우며, 민감정보가 섞이지 않는 업무만 대상.

### 4. L4 실습 — 예약 걸어보기 (수요가 있는 경우)

- 수강생이 원하면 실제로 예약 실행 하나를 함께 설정해본다.
- 환자정보가 섞일 가능성이 있는 업무는 이 단계에서 제외하고, 왜 제외하는지 설명한다 (앵커 §6).

### 5. computer use 소개 (선택 심화)

- 필요 시 브라우저/화면 조작 자동화(computer use) 개념을 짧게 소개한다 — 이 모듈에서 깊이 다루지 않고, 존재와 한계(느림, 오작동 가능성, 검토 필요)만 짚는다.

### 6. 졸업 체크

- `_tutor_kit/progress_ledger.md`(튜터 전용, 배포 미포함)의 졸업 체크 항목을 함께 확인한다: 본인 업무 ≥1개가 L3 이상 도달했는가.
- 도달했다면 `progress.md`에 졸업 기록을 남기고, 다음 관심 모듈(다른 주제)로 이어갈지 논의한다.

## 안전선 (앵커 §6 계승)

- 🔒 환자정보가 섞이는 업무는 L4(예약 실행) 대상에서 제외 — 사람의 매번 확인이 있는 L2/L3에 머무른다.
- 🔒 계정·구독·결제는 수강생 본인이 직접 — cron/Tasks 설정 중 로그인·결제가 필요하면 수강생이 진행한다.
- 🔒 확인 안 된 기능(예: 특정 구독 등급에서 cron 가용 여부)은 아는 척하지 않고, `tutor-apps-basics`의 근거표를 참조하거나 실기기로 확인한다.

## 상태 파일 연동

- 이 모듈 진행 상황과 졸업 여부는 `progress.md`(사다리 위치: M4 → L3/L4, 졸업 플래그)에 기록된다.
