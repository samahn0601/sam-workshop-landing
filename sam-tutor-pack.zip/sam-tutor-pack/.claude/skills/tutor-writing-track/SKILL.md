---
name: tutor-writing-track
description: >
  칼럼·강의자료·환자 안내문 등 논문이 아닌 글쓰기 워크플로우를 과외 형식으로
  익히는 모듈(M2). Trigger when the learner wants help with a column, lecture
  handout, patient information leaflet, or other non-paper writing task, or
  says "칼럼 쓰고 싶다", "강의자료 만들어야 한다", "환자 안내문", "글쓰기
  도와줘", "논문 말고 다른 글". Do not use for full academic manuscripts (use
  tutor-paper-track instead) or for the initial app-onboarding session (use
  tutor-apps-basics). Input: learner_profile.json의 topics_priority/goal_text +
  (있다면) 기존 초고. Output: 해당 글쓰기 워크플로우의 L1(입력→단계→출력 정의)
  ~L2(고정 템플릿 프롬프트) 산출물 + progress.md 갱신 근거. Pipeline position:
  automation_ladder L1→L2 (모듈 M2). Medical context: 의사·교수 대상이므로
  예시 소재에 실제 환자 식별정보가 들어가지 않도록 안전선(앵커 §6)을 매 세션
  확인한다. Trigger keywords: 칼럼, 강의자료, 강의노트, 환자 안내문, 환자
  교육자료, 원고 청탁, 글쓰기, 에세이, 기고문, writing track, column, lecture
  material, patient handout.
---

# tutor-writing-track — 글쓰기 워크플로우 모듈 (M2)

> **v1 스켈레톤 — 수강생 수요 확인 후 증축.** 지금은 목차와 수업 골격만 정의되어 있다. 실제 수강생이 어떤 글쓰기(칼럼? 강의자료? 환자 안내문?)를 우선하는지에 따라 각 절을 구체 러닝시트로 채운다.

## 이 모듈이 다루는 것

논문이 아닌, 그러나 학술·임상 활동에서 반복되는 글쓰기 업무들:

1. 학회지·매체 칼럼·기고문
2. 강의자료·강의노트 (교수용)
3. 환자 안내문·환자 교육자료 (개원의·봉직의용)
4. (수요 확인 후 추가 후보) 학회 초록, 보도자료, 소셜 콘텐츠 등

## 목차 (골격)

### 1. 인테이크 — 어떤 글쓰기가 우선인가

- `learner_profile.json`의 `topics_priority`, `goal_text`, `role`을 참조해 위 후보 중 우선순위를 재확인한다.
- 기존 초고나 예시가 있으면 (환자 식별정보 제거 확인 후) 함께 검토한다.

### 2. 워크플로우 정의 — L1

- 그 글쓰기 업무를 "입력 → 단계 → 출력"으로 함께 문장화한다 (`automation_ladder.md` L1 참고).
- 예: 칼럼이라면 "주제 청탁 → 선행 자료 확인 → 개요 → 초안 → 윤문" 순.

### 3. 첫 실습 — 같은 소재로 시범

- 수강생이 가져온(또는 만든) 소재로 짧은 초안을 함께 만들어본다.
- 톤·형식(예: 환자 안내문의 평이한 어휘, 강의자료의 구조화된 개조식)을 이 단계에서 확인한다.

### 4. 고정 템플릿화 — L2

- 반복해서 쓸 수 있는 프롬프트 템플릿(입력 위치·출력 형식 고정)을 정리한다.
- 필요하면 `gn-voice`/`humanize-korean` 등 기존 윤문 스킬과의 연계 지점을 표시한다 (본 모듈은 그 스킬들을 대체하지 않는다).

### 5. 다음 단계 안내

- L3(스킬화)를 원하면 `tutor-automation` 모듈로 연결.
- 학술 논문 자체를 쓰고 싶어지면 `tutor-paper-track`으로 연결.

## 안전선 (앵커 §6 계승)

- 예시 소재에 환자 식별정보 금지 — 환자 안내문 실습 시 특히 확인.
- 확인 안 된 사실(예: 특정 저널·매체의 형식 규정)은 아는 척하지 않는다. 필요하면 수강생에게 원본 규정 확인을 요청한다.

## 상태 파일 연동

- 이 모듈 진행 상황은 `progress.md`(사다리 위치: M2 → L1/L2)에 기록된다. 갱신은 `tutor-start`가 세션 종료 시 수행.
