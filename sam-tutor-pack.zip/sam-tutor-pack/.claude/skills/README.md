# sam-tutor — Sam AI 과외 파이프라인

의사·교수를 위한 **1:1 AI 과외** 스킬 팩. 양대 AI 앱(Claude·ChatGPT) 기본기부터 논문·글쓰기·통계·자동화까지, 여러 세션에 걸쳐 **본인 업무 하나를 실제로 자동화**하는 것을 목표로 한다.

> 대상: CS/코딩 배경이 없는 의사·교수. 정체성·안전선·모듈 상세는 `CLAUDE.md`, 전체 빌드 근거는 `_TUTOR_BUILD_ANCHOR.md`(소스 repo 전용 — 배포 ZIP 미포함).

## ⚠️ 먼저 알아둘 것 — Code 탭 전용입니다

이 팩은 **Claude Desktop 의 `Code` 탭에서만** 동작한다.
- Desktop 앱은 `Chat` / `Cowork` / `Code` 세 탭이 있는데, **Cowork 탭은 claude.ai 계정에 등록된 스킬만 읽고 이 팩처럼 로컬 폴더에 설치한 스킬은 읽지 못한다** → Cowork 에서 부르면 "not found"로 뜬다.
- 반드시 **`Code` 탭**에서 열어 사용한다. (근거: research_claude.md §4.2)

## 요구사항

| 항목 | 필요 | 비고 |
|---|---|---|
| Claude 구독 | **Pro 이상** | Code 탭·Cowork 는 **무료 플랜 불가**(Pro/Max/Team/Enterprise) |
| OS | Windows 10+ / macOS 11+ | |
| Git | **Windows 는 필수** | Code 탭 로컬 세션에 필요. Windows 는 Git for Windows 설치 후 앱 재시작. Mac 은 대개 기본 포함 |
| Python | **불필요** | v1 은 md/json 만으로 동작(스크립트 0개 원칙) |
| ChatGPT 구독 | 선택 | GPT 트랙 실습 시. 없어도 Claude 트랙만으로 진행 가능 |

(구독·git·가격 근거: `_tutor_kit/research/research_claude.md`(소스 repo 전용 — 배포 ZIP 미포함), 확인일 2026-07-20. 가격·기능은 변동될 수 있으니 수업 당일 재확인 권장.)

## 설치 (ZIP flat 설치)

1. `sam-tutor-pack.zip` 을 받는다.
2. 압축을 풀면 나오는 스킬 폴더들을 **`.claude/skills/` 바로 아래**에 평평하게(flat) 넣는다.
   - Windows: `C:\Users\<이름>\.claude\skills\`
   - Mac: `~/.claude/skills/`
   - 폴더를 깊이 중첩하지 않는다 — flat 이 아니면 스킬이 로드되지 않는다.
3. Claude Desktop 을 (재)시작하고 **`Code` 탭**을 연다.
4. 아무 폴더나 과외 홈으로 열고 이렇게 입력한다: **"과외 시작하자"**
   → `tutor-start` 가 발동해 인테이크부터 시작한다.

설치 후 폴더 구조(예):
```
.claude/skills/
  tutor-start/        SKILL.md      ← 진입점
  tutor-apps-basics/  SKILL.md      ← M0
  tutor-paper-track/  SKILL.md      ← M1
  tutor-writing-track/ SKILL.md     ← M2 (스켈레톤)
  tutor-stats-track/  SKILL.md      ← M3 (스켈레톤)
  tutor-automation/   SKILL.md      ← M4 (스켈레톤)
  _shared/
    schemas/learner_profile.schema.json
    templates/progress_template.md
    templates/automation_ladder.md
```
(같은 `.claude/skills/` 에 sam-medhum·sam-workshop 이 함께 있어도 이 팩의 스킬은 전부 `tutor-` prefix 라 충돌하지 않는다.)

## 모듈 목록

| 모듈 | skill | v1 | 무엇을 |
|---|---|---|---|
| 진입 | `tutor-start` | 완성 | 학습자 인테이크 → 커리큘럼 추천 → 진도 재개 → 모듈로 안내 |
| M0 양대 앱 | `tutor-apps-basics` | 완성 | Claude·ChatGPT 설치·탭/모드 구분·기능 비교·첫 실습 |
| M1 논문 | `tutor-paper-track` | 완성 | 논문 종류 진단 → 적합 팩 설치 안내 → 10-step 을 과외 호흡으로 |
| M2 글쓰기 | `tutor-writing-track` | 스켈레톤 | 칼럼·강의자료·환자안내문 워크플로우 (목차 골격) |
| M3 통계 | `tutor-stats-track` | 스켈레톤 | 프라이버시-우선 통계 흐름 (원자료 비반입, 목차 골격) |
| M4 자동화 | `tutor-automation` | 스켈레톤 | 스킬 만들기·예약 실행·computer use (목차 골격) |

## 자동화 사다리 (모든 모듈이 오르는 축)

```
L0 앱 세팅 → L1 워크플로우 글로 적기 → L2 파이프라인화 → L3 스킬화 → L4 예약 실행
```
**졸업 = 본인 업무 하나가 L3 이상(자연어 한 마디로 돎)에 도달.** (전개: `_shared/templates/automation_ladder.md`)

## 세션은 이렇게 이어진다

- 매 세션 끝에 `tutor-start` 가 `<과외홈>/.sam/tutor/progress.md` 에 진도·숙제를 저장한다.
- 다음 세션에 "이어서 하자"라고 하면 그 파일을 읽고 "지난 시간 여기까지, 숙제 어땠어요?"로 이어간다.

## 안전선 (요약)

- 환자정보·개인정보 비반입 (통계는 원자료 비반입)
- 계정·결제·설치는 수강생 본인이 직접 — AI 는 비밀번호·카드번호를 받지 않음
- 논문(M1)은 연구윤리 floor(IRB·AI 공개문·authorship·COI) 상속, 실제 투고는 사람이
- 확인 안 된 기능·가격은 아는 척하지 않음 — 산출물의 최종 책임은 수강생 본인

상세: `CLAUDE.md` §6.

---
작성: 안상현 (Sam, MD) — 2026-07. 기반: sam-workshop → sam-medhum → sam-tutor.
