---
name: tutor-apps-basics
description: >
  1:1 AI 과외 M0 모듈 — 양대 데스크톱 앱(Claude Desktop: Chat/Cowork/Code,
  ChatGPT Desktop: Chat/Work/Codex)의 설치·로그인·기능 차이를 잡고, 학생의
  OS·git·구독 티어에 맞는 시작 경로를 정한 뒤, 같은 과제 하나를 양대 앱에서
  수행·비교하는 첫 실습을 이끈다. Trigger when a learner asks "앱 설치", "어떤
  앱부터", "Claude랑 ChatGPT 차이", "Cowork가 뭐야", "Code 탭 안 돼", "git 꼭
  깔아야 해", "무료로 되나", "설치가 안 돼", or starts M0 in tutor-start. Do not
  use for paper writing (tutor-paper-track), 글쓰기 워크플로(tutor-writing-track),
  통계(tutor-stats-track), 스킬화·예약실행(tutor-automation) — those are later
  modules; and do not use as the session entry point (that is tutor-start).
  Input: learner_profile.json(role/os/subscriptions/git_installed/level) +
  _shared/templates/app_matrix.md. Output: 확정된 시작 경로 + 양대 앱 설치·로그인
  완료 확인 + 첫 실습 비교 노트(입력→단계→출력 초안) + progress.md 갱신 입력.
  사다리 위치: L0(앱 세팅) → L1(워크플로우 정의 씨앗). Safety: 계정 가입·로그인·
  결제는 학생 본인이 직접(자격증명 대리 금지), 환자정보·개인정보 실습 재료 반입
  금지, 확인 안 된 기능은 "미확인"으로 정직 표기하고 실기기 확인. Trigger
  keywords: 앱 설치, 앱 설정, 클로드 설치, 챗지피티 설치, Claude ChatGPT 차이,
  Cowork, Code 탭, Codex, git 설치, 무료 플랜, 구독, 설치 안 됨, 로그인,
  Windows 10, 맥, install app, which app first, app basics, setup.
---

# tutor-apps-basics — M0: 양대 AI 앱 기본기 (사다리 L0 → L1)

> **이 모듈의 목표**: 학생(의사·교수, CS 배경 없음)이 **양대 데스크톱 앱을 자기 기기에 설치·로그인**하고(L0), 두 앱의 성격 차이를 감으로 익힌 뒤, **본인 반복 업무 하나를 골라 양대 앱에서 같은 과제로 돌려보며 "입력→단계→출력"을 처음 글로 적는다**(L1 씨앗).
>
> **근거 규율(엄수)**: 이 모듈이 말하는 앱 기능·설치 요구·가격의 **모든 사실 주장은 `_shared/templates/app_matrix.md`(→ 리서치 근거 파일)에서만** 온다. LLM 기억으로 채우지 않는다. 근거에 없거나 UNVERIFIED인 것은 **"미확인(2026-07-20 기준)"** 이라고 솔직히 말하고, 그 자리에서 학생 기기로 확인한다.

---

## 이 모듈이 다루는 것 / 안 다루는 것

- **다룸**: 두 앱 뼈대 이해, OS별 설치 체크리스트, 기능 매트릭스 읽는 법, 학생별 시작 경로 판정, 첫 비교 실습.
- **안 다룸**: 논문(M1 `tutor-paper-track`)·글쓰기(M2)·통계(M3)·스킬화/예약실행(M4). 여기선 예약실행·computer use·MCP는 **"이런 게 있다"** 정도만 소개하고 실제 구축은 M4로 넘긴다.

## 안전선 (매 세션 강제 — 위임 불가)

- 🔒 **계정·결제 대리 금지** — 구독 가입·로그인·결제·카드 입력은 **학생 본인이 직접**. 튜터·AI는 아이디/비밀번호/카드번호를 받지 않는다.
- 🔒 **환자정보·개인정보 비반입** — 첫 실습 과제에 환자 식별정보·PHI·개인정보를 넣지 않는다(가상/비식별 재료만). 학생 프로필 `constraints`에 "환자정보 다룸"이 있으면 실습 시작 전에 리마인드.
- 🔒 **정직성** — 확인 안 된 기능·쿼터·가격은 아는 척하지 않는다. "안 되는 것"(예: Win Home에서 Cowork 로컬 불가)도 훌륭한 수업 재료다.

---

## 절차

### 0) 프로필 확인 (tutor-start가 넘겨준 값)

`learner_profile.json`에서 아래를 확인한다(없으면 이 자리에서 대화로 2~3개씩 묻는다 — 한 번에 다 묻지 않기):

- `os` (win10 / win11 / mac) · `git_installed` (true/false/unknown) · `subscriptions.{claude,gpt}` · `level` · `constraints`

> 이 세 값(**OS · git · 구독 티어**)이 아래 3) 분기 판정의 핵심 입력이다.

### 1) 두 앱 뼈대 1분 설명 (매트릭스 §A)

`app_matrix.md` §A를 열어 학생에게 **탭/모드 대응**을 보여준다:

```
Claude Desktop :  Chat        | Cowork(위임 에이전트)     | Code(로컬 파일·코딩)
ChatGPT Desktop:  Chat        | Work(위임 에이전트)       | Codex(코딩)
```

핵심 한 줄: **"둘 다 '채팅 / 알아서 해주는 에이전트 / 코딩' 3칸 구조인데, 세부 요구사항과 제약이 다르다."**
그리고 함정 하나를 못 박는다 — **이 과외 팩(스킬들)은 Claude의 Code 탭에서만 읽힌다. Cowork 탭에서 부르면 안 나온다** (§A 각주, `[C-SKILLS]`).

### 2) OS별 설치 체크리스트 (매트릭스 §B·§C)

학생 `os`에 맞는 열을 §B(Claude)·§C(ChatGPT)에서 함께 따라간다. **반드시 짚을 3가지:**

1. **Claude Code 탭 = Windows면 Git for Windows 필수** → 설치 후 앱 재시작 `[C-QUICK][C-DESKTOP]`. mac은 대부분 git 기본 포함 `[C-DESKTOP]`.
2. **ChatGPT Codex = git 불요** (PR 헬퍼에만 선택) `[G-CODEXINSTALL]`. → 즉 "git 깔기 싫다/못 깐다"면 ChatGPT 쪽이 진입 장벽이 낮다.
3. **Claude Cowork는 Windows에서 Virtual Machine Platform 필요**, 그리고 **Windows Home 에디션은 Hyper-V가 없어 로컬 Cowork가 사실상 안 된다** `[C-WINDEPLOY]`, `[C-ISSUES·2차]`. ⚠️ 공식 문서엔 "Home 미지원"이 명시돼 있지 **않다 → 미확인(2026-07-20)**. 안 되면 Remote(클라우드) Cowork로 우회 `[C-COWORK-GET]`.

> 로그인·구독 결제 화면이 나오면 **학생이 직접** 진행하게 하고 옆에서 안내만 한다(안전선).

### 3) 학생별 시작 경로 분기 규칙 (핵심)

프로필 3값으로 **어느 앱을, 어떤 순서로 시작할지**를 정한다. 아래는 우선순위대로 적용(위에서 맞으면 그걸 채택):

| # | 조건 | 시작 경로 판정 | 근거 |
|---|---|---|---|
| R1 | `git_installed=false` **그리고** git 설치에 거부감/설치권한 없음 | **ChatGPT Codex 먼저**(git 불요)로 코딩 감 잡기 → 이후 git 설치하고 Claude Code 합류 | §C `[G-CODEXINSTALL]` |
| R2 | `os=win10/win11` **그리고** 에디션이 **Home**(또는 확인 안 됨) | Claude **로컬 Cowork 기대하지 않기** → **Chat + Code 경로**로 시작, Cowork가 필요하면 **Remote(클라우드) Cowork** | §B `[C-WINDEPLOY][C-ISSUES·2차]` |
| R3 | `subscriptions.claude=free` **그리고** claude 유일 구독 | Claude는 **Code·Cowork 불가** → **ChatGPT 데스크톱**(무료도 Chat/Work/Codex 제한적)으로 시작. Claude 업그레이드는 **본인 결정**(권유만, 결제 대리 금지) | §J `[C-COWORK-TEAM][G-WORKBLOG]` |
| R4 | `subscriptions.gpt=free` **그리고** gpt 유일 구독 | ChatGPT 무료로 Chat/Work/Codex 제한 체험 가능 → 예약실행(Scheduled Tasks)은 **Free 미지원**이니 Go+ 필요함을 미리 고지 | §F `[G-TASKS][G-PRICE]` |
| R5 | `os=mac` | git 대부분 기본 → **Claude Code 즉시 가능**. computer use도 Pro/Max면 양쪽 활용 여지 | §B `[C-DESKTOP]`, §G `[C-CU]` |
| R6 | `topics_priority` 최상위가 문헌/논문 조사 | **양대 Deep Research 비교 실습**으로 방향 — 단 Claude Research는 §L 실기기 확인 후, ChatGPT Deep Research는 확인됨 | §E `[G-DR]` |
| R7 | 위 어디에도 특별 제약 없음(양쪽 유료·git 있음) | **양대 병행** — 4)의 비교 실습을 그대로 진행하며 취향/업무적합도 관찰 | §A |

> 분기는 **배타적이지 않다.** 여러 조건이 겹치면(예: Win10 Home + Free) 각 규칙의 조치를 합쳐 적용한다. 판정 결과와 이유 1줄을 학생에게 말로 확인받고 `progress.md`에 남긴다.

### 4) 첫 실습 — 같은 과제를 양대 앱에서 (L0 → L1)

**목적**: 두 앱을 실제로 돌려보며 성격 차이를 체감하고, 그 과정에서 본인 업무를 **"입력 → 단계 → 출력"** 으로 처음 적어본다(= 자동화 사다리 L1의 씨앗).

**4-1. 과제 하나 고르기 (학생 실제 업무, 단 비식별)**
반복하는 가벼운 업무 하나 — 예: "외래 안내문 초안", "학회 초록 문단 다듬기", "회의 메모를 표로 정리". **환자 식별정보·개인정보 금지**(안전선). 딱 한 문단~한 표 분량으로 작게.

**4-2. 같은 프롬프트를 양대 앱 Chat에 넣기**
학생이 직접 아래 틀로 프롬프트를 만들어 **Claude Chat**과 **ChatGPT Chat** 양쪽에 넣는다(튜터는 프롬프트만 다듬어 줌 — ChatGPT 쪽은 팩이 대신 실행 못 하므로 **붙여넣기 후 학생이 결과를 보고**):

```
[역할] 나는 ○○(직군)이다.
[과제] 다음 [자료]를 [목표 산출물]로 만들어줘.
[자료] (비식별 텍스트 붙여넣기)
[조건] 분량·말투·형식 조건 1~2개
```

**4-3. 결과 비교 노트 작성** (튜터가 표로 유도)

| 관찰 항목 | Claude | ChatGPT |
|---|---|---|
| 결과가 내 의도에 가까웠나 | | |
| 말투·형식 | | |
| 수정 지시에 반응 | | |
| 설치·로그인에서 막힌 점 | | |

**4-4. "입력→단계→출력"으로 옮겨 적기 (L1 씨앗)**
방금 한 일을 **한 문장씩** 적는다:
- **입력**: 무엇을 넣었나 (예: "회의 메모 텍스트")
- **단계**: 어떤 순서로 시켰나 (예: "① 요점 추출 → ② 표로 정리 → ③ 존댓말 안내문")
- **출력**: 무엇이 나왔나 (예: "환자 안내문 초안 1개")

> 이 3줄이 다음 모듈(L2 파이프라인화·L3 스킬화)의 재료가 된다. 완성 안 해도 좋다 — **"내 업무도 이렇게 절차로 쪼갤 수 있구나"** 를 체감하는 게 M0의 도착점이다.

### 5) 미확인 항목은 그 자리에서 확인 (매트릭스 §L)

수업 중 마주친 미확인 항목(Claude Research 유무, ChatGPT 신버전 최소 OS, Pro 20x 가격, Home+Cowork 동작 등)은 §L 절차대로 **학생 기기·공식 페이지로 실측**하고, 확인일과 값을 `progress.md`에 남긴다. 확정 전엔 "미확인"이라고 말한다.

---

## 종료 훅 (이 3줄을 반드시 출력)

```
✅ M0 양대 앱 기본기 완료 — [학생 시작경로 판정 1줄] · 첫 비교 실습 노트 작성
사다리 위치: L0(앱 세팅) → L1(워크플로우 "입력→단계→출력" 초안)
다음: 관심 1순위 모듈로 →  M1 논문(/tutor-paper-track) · M2 글쓰기 · M3 통계 · M4 자동화
계속하려면 "다음"   (다른 모듈 원하면 그 이름을 말하세요)
```

- `progress.md`에 남길 것: 회차·시작경로 판정과 이유·설치 완료 여부(양대)·첫 실습 과제와 L1 3줄·미확인 실측값·다음 모듈.
- tutor-start로 돌아가 다음 세션을 이어간다.

## 자주 발생하는 함정

1. **팩을 Cowork에서 부름** → "not found". 이 팩은 **Code 탭** 전용(§A `[C-SKILLS]`).
2. **Windows Home에서 Cowork 로컬을 억지로 시도** → Hyper-V 부재로 안 됨. Chat+Code 또는 Remote로 우회(R2).
3. **git 없이 Claude Code 탭 시도(Windows)** → "Git is required". git 설치 후 앱 재시작, 아니면 ChatGPT Codex부터(R1).
4. **미확인 기능을 확정처럼 말함** → 근거 규율 위반. §L로 실기기 확인 후 값 기록.
5. **튜터가 로그인/결제를 대신함** → 안전선 위반. 학생 본인이 직접.
6. **에디션·가상화를 시스템 명령으로 확인하려 함** → PowerShell·systeminfo·레지스트리 조회를 직접 실행하지 않는다(권한 거부 팝업이 연달아 떠 수강생이 놀란다). 반드시 수강생에게 **설정 → 시스템 → 정보**의 "Windows 사양"을 읽어 달라고 요청한다(스크립트 0개 원칙과 같은 정신).

## 참조 파일

- 기능 매트릭스(출처 포함): `${CLAUDE_SKILL_DIR}/../_shared/templates/app_matrix.md` (변수 미확장 시 절대경로로 치환)
- 근거 파일(읽기 전용, 소스 repo 전용 — 배포 ZIP 미포함): `_tutor_kit/research/research_claude.md` · `research_gpt.md`
- 빌드 SSOT: `_TUTOR_BUILD_ANCHOR.md`(소스 repo 전용 — 배포 ZIP 미포함) (§3 사다리 · §5 dual-track 교리 · §6 안전선)
