---
name: tutor-stats-track
description: >
  프라이버시-우선 통계 워크플로우를 과외 형식으로 익히는 모듈(M3) — 원자료
  (환자 raw data)는 어떤 경우에도 세션에 반입하지 않고, 요약 통계·구조 설명
  만으로 진행한다. Trigger when the learner wants help planning or
  understanding a statistical analysis, asks "통계 분석 어떻게 하지", "기술
  통계", "군간 비교", "회귀분석 설명해줘", "통계 계획서", or mentions medical
  research data analysis in a tutoring context. Do not use for full SAP
  authoring or actual data-crunching on real patient data (use
  medical-statistics-analysis skill for that, and only outside this tutoring
  pack with proper privacy controls) — this module teaches concepts and
  planning, never touches raw rows. Input: learner_profile.json의 goal_text +
  수강생이 구두로 설명하는 요약 통계(표·평균·건수 등, 원자료 아님). Output:
  통계 워크플로우의 L1(분석 계획 문장화)~L2(반복 가능한 분석 절차 정리) 산출물.
  Pipeline position: automation_ladder L1→L2 (모듈 M3). Medical context: 환자
  원자료 비반입 원칙(앵커 §6)이 이 모듈의 최우선 제약이며, 실제 통계 실행이
  필요하면 통계 전문가 또는 별도 프라이버시 통제 하의 medical-statistics-
  analysis 파이프라인으로 안내한다. Trigger keywords: 통계, 통계분석, 기술통계,
  회귀분석, 군간비교, p값, 신뢰구간, SAP, 분석계획서, statistics track,
  data analysis planning.
---

# tutor-stats-track — 통계 워크플로우 모듈 (M3)

> **원자료(환자 raw data) 비반입 원칙** — 이 모듈은 골격 단계에서도 이 원칙을 최우선으로 명시한다. 세션 중 어떤 형태로든 환자 단위 원자료(엑셀 행 단위 데이터, 식별 가능한 사례 등)를 채팅·파일 업로드로 반입하지 않는다. 다루는 것은 **요약 통계(평균·건수·비율·이미 집계된 표), 분석 개념, 계획 수립**뿐이다. 실제 원자료를 다뤄야 하는 순간이 오면, 이 모듈이 아니라 별도의 프라이버시 통제가 갖춰진 통계 파이프라인(예: `medical-statistics-analysis` 스킬)과 통계 전문가 검토로 안내한다.
>
> **v1 스켈레톤 — 수강생 수요 확인 후 증축.** 지금은 목차와 수업 골격만 정의되어 있다.

## 이 모듈이 다루는 것

1. "내 연구 질문에 어떤 분석이 필요한가"를 개념적으로 정리하는 법
2. 기술통계(평균·중앙값·표준편차·빈도)를 읽고 설명하는 법
3. 군간 비교(t-검정, 카이제곱 등)의 개념과 언제 쓰는지
4. 회귀분석의 기본 개념 (원자료 없이, 결과표 해석 위주)
5. 분석 계획서(SAP) 골격 작성 감각

## 목차 (골격)

### 1. 인테이크 — 무엇을 알고 싶은가

- `learner_profile.json`의 `goal_text`를 참조해 실제 필요(예: "논문에 들어갈 표 하나 이해하고 싶다" vs "직접 분석 계획을 세우고 싶다")를 확인한다.
- 원자료 비반입 원칙을 첫 세션 시작 시 짧게 안내한다.

### 2. 개념 정리 — L1

- 수강생의 연구 질문을 "무엇을 비교/설명하려는가"로 문장화한다.
- 필요한 분석 종류를 개념 수준에서 짚는다 (계산은 하지 않는다 — 원자료가 없으므로).

### 3. 요약 통계로 실습

- 수강생이 이미 가지고 있는 **집계된** 표(예: "군당 평균 나이, 표준편차")를 가지고 해석 연습을 한다.
- 원자료가 아닌지 매번 확인한다 (행 단위 데이터가 보이면 즉시 중단하고 안내).

### 4. 분석 계획 문장화 — L2

- "이 연구 질문 → 이 분석 방법 → 이런 형태의 표/그림"을 반복 가능한 절차로 정리한다.
- 실제 실행(원자료 처리)이 필요한 지점에서는 통계 전문가 협업 또는 `medical-statistics-analysis` 파이프라인으로 넘긴다는 것을 명시한다.

### 5. 다음 단계 안내

- 논문의 결과 섹션에 이 통계를 반영하고 싶다면 `tutor-paper-track`으로 연결.

## 안전선 (앵커 §6 계승 — 이 모듈의 1순위 규칙)

- 🔒 원자료(환자 raw data) 비반입 — 요약 통계·구조만.
- 🔒 수강생 `constraints`에 "환자정보 다룸"이 있으면 이 모듈 시작 시 반드시 리마인드.
- 🔒 실제 분석 실행이 필요한 경우, 이 모듈은 실행하지 않고 적절한 경로(통계 전문가/전용 파이프라인)로 안내만 한다.

## 상태 파일 연동

- 이 모듈 진행 상황은 `progress.md`(사다리 위치: M3 → L1/L2)에 기록된다.
