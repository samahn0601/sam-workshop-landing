# 양대 AI 앱 기능 매트릭스 (M0 근거 템플릿)

> **이 표의 모든 사실 주장은 리서치 근거 파일에서만 왔다.** LLM 학습지식으로 채우지 않는다.
> 근거 파일(소스 repo 전용 — 배포 ZIP 미포함): `_tutor_kit/research/research_claude.md` · `_tutor_kit/research/research_gpt.md` (모두 확인일 2026-07-20).
> 셀마다 대괄호 출처키를 달았다. 근거 파일에 없는 항목은 **"미확인(2026-07-20 기준)"** 으로 정직 표기하고, 수업에서 실기기로 확인한다(맨 아래 §L 절차).
> ⚠️ AI 앱은 빠르게 바뀐다. **가격·쿼터·최소 OS는 수업 당일 실기기/공식 페이지로 재확인**한 뒤 확정 숫자를 말한다.

---

## 출처키 범례 (Legend)

**Claude 쪽 (research_claude.md)**

| 키 | URL |
|---|---|
| C-INSTALL | https://support.claude.com/en/articles/10065433-install-claude-desktop |
| C-WINDEPLOY | https://support.claude.com/en/articles/12622703-deploy-claude-desktop-for-windows |
| C-DESKTOP | https://code.claude.com/docs/en/desktop |
| C-QUICK | https://code.claude.com/docs/en/desktop-quickstart |
| C-COWORK-GET | https://support.claude.com/en/articles/13345190-get-started-with-claude-cowork |
| C-COWORK-USE | https://support.claude.com/en/articles/15520349-use-claude-cowork-on-web-desktop-and-mobile |
| C-COWORK-TEAM | https://support.claude.com/en/articles/13455879-use-claude-cowork-on-team-and-enterprise-plans |
| C-COWORK-ARCH | https://support.claude.com/en/articles/14479288-claude-cowork-architecture-overview |
| C-COWORK-SAFE | https://support.claude.com/en/articles/13364135-use-claude-cowork-safely |
| C-SKILLS | https://code.claude.com/docs/en/skills |
| C-SCHED | https://code.claude.com/docs/en/desktop-scheduled-tasks |
| C-SCHED-CLI | https://code.claude.com/docs/en/scheduled-tasks |
| C-CU | https://code.claude.com/docs/en/computer-use |
| C-CHROME | https://code.claude.com/docs/en/chrome |
| C-MCP | https://code.claude.com/docs/en/mcp |
| C-PRICE | https://claude.com/pricing |
| C-MAX | https://support.claude.com/en/articles/11049741-what-is-the-max-plan |
| C-ISSUES | https://github.com/anthropics/claude-code/issues (#27316·#29887·#37265·#45715·#27330, **2차 소스**) |

**ChatGPT 쪽 (research_gpt.md)**

| 키 | URL |
|---|---|
| G-WORKBLOG | https://openai.com/index/chatgpt-for-your-most-ambitious-work/ (발표 2026-07-09) |
| G-WORK | https://openai.com/chatgpt-work/ |
| G-CLASSIC | https://help.openai.com/en/articles/9982051-using-the-chatgpt-windows-app |
| G-WINAPP | https://learn.chatgpt.com/docs/windows/windows-app |
| G-CODEXPLAN | https://help.openai.com/en/articles/11369540-using-codex-with-your-chatgpt-plan |
| G-CODEXINSTALL | https://github.com/openai/codex/blob/main/docs/install.md |
| G-CODEXCLI | https://learn.chatgpt.com/docs/codex/cli |
| G-CODEXPRICE | https://developers.openai.com/codex/pricing |
| G-TASKS | https://help.openai.com/en/articles/10291617-tasks-in-chatgpt |
| G-DR | https://help.openai.com/en/articles/10500283-deep-research-faq |
| G-PRICE | https://chatgpt.com/pricing |
| G-AGENT | https://help.openai.com/en/articles/11752874-chatgpt-agent |
| G-BROWSER | https://help.openai.com/en/articles/20001277-using-the-built-in-browser-in-the-chatgpt-desktop-app |
| G-MCP | https://help.openai.com/en/articles/12584461-developer-mode-and-mcp-apps-in-chatgpt |

> 표기 규약: `[출처키]` = 공식 1차 소스. `[출처키·2차]` = 커뮤니티/블로그 등 비공식. `미확인(2026-07-20)` = 근거 파일에서 확정 못 함 → §L 라이브 확인.

---

## §A. 두 앱의 뼈대 한눈에

| | **Claude Desktop** | **ChatGPT Desktop** |
|---|---|---|
| 탭/모드 구성 | **Chat / Cowork / Code** 3개 탭 `[C-QUICK]` | **Chat / Work / Codex** 3개 모드 (2026-07-09 통합앱) `[G-WORKBLOG]` |
| 채팅(파일 접근 없음) | Chat `[C-QUICK]` | Chat `[G-WORKBLOG]` |
| 위임형 에이전트 | Cowork (샌드박스 VM, 백그라운드) `[C-QUICK][C-COWORK-GET]` | Work (앱 넘나들며 결과물 생성, Plan 모드 승인) `[G-WORK]` |
| 코딩/로컬파일 | Code 탭 (로컬 파일 직접, 실시간 승인) `[C-QUICK][C-DESKTOP]` | Codex (로컬 워크플로 + 클라우드 위임) `[G-CODEXPLAN]` |
| 이 과외팩이 도는 곳 | **Code 탭** (로컬 `.claude/skills/`) `[C-SKILLS]` | (팩 아님 — 붙여넣기 프롬프트로 실습) |

> ⚠️ **팩 설치 위치 함정**: 이 sam-tutor 팩은 Code 탭의 로컬 스킬 폴더에서만 읽힌다. **Cowork 탭·클라우드 세션은 claude.ai 계정에 등록된 스킬만 읽고 로컬 스킬은 못 본다** → 팩을 Cowork에서 부르면 "not found". `[C-SKILLS]`

---

## §B. 설치 체크리스트 — Claude Desktop (OS별)

| 항목 | Windows 10 | Windows 11 | macOS |
|---|---|---|---|
| OS 최소 요구 | Windows 10 이상 지원 `[C-INSTALL]` | 지원 `[C-INSTALL]` | macOS 11(Big Sur) 이상 `[C-INSTALL]` |
| 설치파일 | x64 / ARM64 별도 `[C-QUICK]` | x64 / ARM64 별도 `[C-QUICK]` | 단일 `[C-INSTALL]` |
| **Code 탭 — git** | **Git for Windows 필수** → 설치 후 앱 재시작 `[C-QUICK][C-DESKTOP]` | 동일: **git 필수 + 재시작** `[C-DESKTOP]` | 대부분 git 기본 포함 → 보통 바로 됨 `[C-DESKTOP]` |
| Node.js | 불필요(앱에 Claude Code 내장) `[C-DESKTOP]` | 불필요 `[C-DESKTOP]` | 불필요 `[C-DESKTOP]` |
| **Cowork 전제** | **Virtual Machine Platform 활성화 필요** (`Enable-WindowsOptionalFeature -Online -FeatureName VirtualMachinePlatform -All -NoRestart`) `[C-WINDEPLOY]` | 동일 `[C-WINDEPLOY]` | 로컬 VM 지원(별도 VMP 명령 불요) `[C-COWORK-ARCH]` |
| **Cowork — Win Home 함정** | ⚠️ **Win10 Home은 Hyper-V 부재로 로컬 Cowork 사실상 불가** `[C-ISSUES·2차]`; Pro여도 "Virtualization is not available" 버그 보고 `[C-ISSUES·2차]`. **공식 문서엔 "Home 미지원" 명시 없음 → 미확인(2026-07-20)** | ⚠️ 동일: Win11 **Home = Hyper-V 없음** `[C-ISSUES·2차]`; 공식 미명시 → 미확인(2026-07-20) | 해당 없음 |
| 관리자 권한 | 개인설치 시 Cowork 등 전체기능엔 관리자 권한 필요(일반 권한이면 "Cowork on desktop will not be available") `[C-WINDEPLOY]` | 동일 `[C-WINDEPLOY]` | — |
| Cowork 안 될 때 우회 | Remote(클라우드) Cowork로 우회 가능 `[C-COWORK-GET]` | 동일 | — |
| gh CLI(GitHub) | PR 자동 모니터링에만 필요(선택) `[C-DESKTOP]` | 선택 `[C-DESKTOP]` | 선택 `[C-DESKTOP]` |
| 플랜 전제 | Code·Cowork는 **Pro/Max/Team/Enterprise**, Free 불가 `[C-QUICK][C-COWORK-TEAM]` | 동일 | 동일 |

---

## §C. 설치 체크리스트 — ChatGPT Desktop (OS별)

| 항목 | Windows 10 | Windows 11 | macOS |
|---|---|---|---|
| 신규 통합앱(Chat/Work/Codex) | 2026-07-09부터 Windows 제공, **무료 포함 전 플랜** 데스크톱에서 3모드 `[G-WORKBLOG]` | 동일 `[G-WORKBLOG]` | Mac 제공, 동일 `[G-WORKBLOG]` |
| OS 최소 빌드(신버전) | **미확인(2026-07-20)** — learn 문서에 수치 없음 `[G-WINAPP]` | 미확인(2026-07-20) `[G-WINAPP]` | 미확인(신버전 명시 없음) — Codex 문맥엔 "macOS 12+" 문자열 존재하나 앱 요구와 구분 불명 `[G-WINAPP]` |
| 참고: 레거시 "Classic" 앱 | Windows 10 (x64/arm64) v17763.0+ `[G-CLASSIC]` | 동일 `[G-CLASSIC]` | — |
| **Codex — git** | **불필요** (PR 내장 헬퍼에만 git 2.23+ 선택 권장) `[G-CODEXINSTALL][G-CODEXCLI]` | 불필요 `[G-CODEXINSTALL]` | 불필요 `[G-CODEXINSTALL]` |
| Codex 로그인 | ChatGPT 구독 OAuth 로그인 → **추가 과금 없음**, Free/Go 포함 전 플랜에 Codex 포함 `[G-CODEXPLAN][G-CODEXPRICE]` | 동일 | 동일 |
| 로컬 vs 클라우드 | Codex Local(내 기기) / Codex Cloud(위임) 구분 `[G-CODEXPLAN][G-CODEXCLI]` | 동일 | 동일 |

> 정리: **Claude Code 탭 = git 필수(Windows), ChatGPT Codex = git 불요.** 이 차이가 M0 분기의 핵심 입력이다(§K).

---

## §D. 채팅·에이전트·코딩 기본 기능

| 기능 | Claude | ChatGPT |
|---|---|---|
| 일반 채팅 | Chat 탭 `[C-QUICK]` | Chat 모드 `[G-WORKBLOG]` |
| 위임형 에이전트 | Cowork — "outcome 기술 → 자리 비움 → 완성물" `[C-COWORK-GET]` | Work — GPT-5.6 에이전트, 앱 넘나들며 문서/슬라이드/시트/Sites 생성 `[G-WORK]` |
| 에이전트 승인 모드 | Manual / Auto / Skip `[C-COWORK-USE]` | Plan 모드(착수 전 계획 검토·승인) `[G-WORK]` |
| 코딩/로컬파일 승인 | Code 탭 5모드: Manual·Accept edits·Plan·Auto·Bypass `[C-DESKTOP]` | Codex: diff 인라인 편집·PR 리뷰 `[G-WORKBLOG]` |
| 에이전트 플랜 전제 | Cowork = Pro/Max/Team/Enterprise(Free 불가) `[C-COWORK-TEAM]` | Work 데스크톱 = 전 플랜; 웹/모바일은 Plus·Pro·Business·Enterprise·Edu `[G-WORK]` |

---

## §E. Research / Deep Research

| | Claude | ChatGPT |
|---|---|---|
| 심층 문헌조사 기능 | **미확인(2026-07-20)** — research_claude.md에 Claude "Research" 기능 항목 없음 → §L에서 실기기 확인 | **Deep Research** 존재 `[G-DR]` |
| 플랜별 가용 | 미확인(2026-07-20) | Free/Go=제한적, Plus/Pro=예 `[G-PRICE]`; 정확한 월 횟수는 공식이 수치 비공개(인앱 카운터) `[G-DR]` |
| 연결앱 사용 범위 | 미확인(2026-07-20) | 연결앱은 **읽기 전용**("read actions only") `[G-DR]` |

> ⚠️ Claude Research는 근거 파일에 없으므로 **아는 척하지 않는다.** 수업에서 Chat 탭을 열어 Research 토글 존재 여부를 실기기로 확인한다(§L). ChatGPT Deep Research는 확인됨.

---

## §F. 예약 실행 (자동 스케줄 — 사다리 L4)

| | Claude | ChatGPT |
|---|---|---|
| 방식 | Cloud routines / Desktop tasks / `/loop` 3종 `[C-SCHED]` | Scheduled Tasks + Codex automations `[G-TASKS]` |
| 컴퓨터 꺼도 실행 | Cloud=Yes / Desktop=No / loop=No `[C-SCHED]` | 미확인(2026-07-20 기준) — 수업에서 실기기 확인 |
| 최소 주기 | Cloud=1시간 / Desktop=1분 / loop=1분 `[C-SCHED]` | 작업당 **시간당 1회 초과 불가** `[G-TASKS]` |
| Desktop 실행 조건 | 앱이 열려 있고 컴퓨터 깨어 있을 때만 `[C-SCHED]` | — |
| 플랜/한도 | (플랜 명시 없음 — 미확인 세부) | **Free=없음**; Go 3 / Plus 5 / Pro·Enterprise 15 활성작업 `[G-TASKS][G-PRICE]`; **Business·Edu는 10 vs 15로 문서 내부 불일치 → 미확인(2026-07-20)** `[G-TASKS]` |
| 비고 | 반복작업 7일 후 자동 만료(CLI) `[C-SCHED-CLI]` | Codex 모드 안엔 Scheduled 페이지 없음 `[G-TASKS]` |

---

## §G. Computer Use (컴퓨터 화면 조작 대행)

| | Claude | ChatGPT |
|---|---|---|
| 존재/형태 | Desktop computer use(리서치 프리뷰) `[C-CU]` | 내장 브라우저 + Computer Use + Chrome 확장 + 클라우드 브라우저 4갈래 `[G-BROWSER][G-AGENT]` |
| 플랜 제한 | **Pro/Max만. Team·Enterprise 불가** `[C-DESKTOP][C-CU]` | 전 플랜 "Limited*" — `*`는 플랜이 아닌 **지역(geo) 제한** `[G-CODEXPRICE]` |
| OS | Desktop=macOS+Windows / CLI=macOS만 `[C-CU]` | 내장 브라우저 macOS+Windows `[G-BROWSER]` |
| 기본 상태 | 꺼짐(off) → 설정 토글 `[C-CU]` | — |
| 옛 이름 주의 | — | **"ChatGPT agent"는 폐기됨 → ChatGPT Work로 흡수** `[G-AGENT]` |

> ⚠️ 교재에서 "ChatGPT agent"라는 옛 이름을 쓰지 않는다 — 현재는 Work의 내장 브라우저/Computer Use/Chrome 확장/클라우드 브라우저다 `[G-AGENT]`.

---

## §H. MCP (외부 도구 연결)

| | Claude | ChatGPT |
|---|---|---|
| Code/Codex(개발자 표면) | Code 탭 = 로컬+원격 MCP 직접 지원 `[C-MCP][C-DESKTOP]` | Codex = 로컬+원격 MCP 직접 지원 `[G-CODEXCLI]` |
| 일반 앱 표면 | Cowork = claude.ai 계정 커넥터(로컬 파일과 별개 저장소) `[C-DESKTOP]` | ChatGPT 챗 = **원격 서버만**(로컬은 Secure MCP Tunnel 경유) `[G-MCP]` |
| 쓰기(modify/write) | (Code 탭 도구 사용) `[C-MCP]` | 풀 MCP(쓰기)는 Business/Enterprise/Edu 베타; Pro=읽기 전용; Free/Go=불가 `[G-MCP]` |
| 모바일 | — | MCP 앱 모바일 미지원(웹 전용) `[G-MCP]` |

> 대비 포인트: **Codex는 로컬 MCP 직접 / ChatGPT 챗은 원격만** — 같은 회사인데 아키텍처가 다르다 `[G-MCP][G-CODEXCLI]`.

---

## §I. 스킬(Skills) — 이 팩이 어디서 읽히나

| 실행 위치 | 스킬 소스 |
|---|---|
| Claude Code 탭 로컬 세션 | `~/.claude/skills/` + `.claude/skills/` (로컬 파일) `[C-SKILLS]` |
| Claude Cowork(로컬/원격) | claude.ai 계정 등록 스킬만(로컬 미읽음) `[C-SKILLS]` |
| Claude Desktop 예약작업(로컬) | 로컬 세션과 동일 `[C-SKILLS]` |
| ChatGPT | (SKILL.md형 스킬 개념은 근거 파일에 없음 — 붙여넣기 프롬프트로 대체) |

> **결론: sam-tutor 팩은 Claude Code 탭에서 돈다.** ChatGPT 실습은 팩이 출력한 붙여넣기 프롬프트를 학생이 ChatGPT 앱에 직접 넣어 수행한다.

---

## §J. 구독 티어 · 가격 (⚠️ 당일 재확인 대상)

**Claude** `[C-PRICE][C-MAX]`

| 플랜 | 가격(USD) | Code·Cowork |
|---|---|---|
| Free | $0 | 불가 |
| Pro | 연 $17/월(선결제) 또는 월 $20 | 포함 |
| Max 5x | $100/월 | 포함 |
| Max 20x | $200/월 | 포함 |
| Team | 표준 $20~$25/시트, 프리미엄 $100~$125/시트 | 포함 |
| Enterprise | $20/시트 + 사용량 | 포함 |

**ChatGPT** `[G-CODEXPRICE][G-PRICE]`

| 플랜 | 가격(USD) | Codex·Work(데스크톱) |
|---|---|---|
| Free | $0 | 데스크톱 제한적 포함 |
| Go | $8/월 | 포함 |
| Plus | $20/월 | 포함 |
| Pro | "From $100/월"(5x/20x); **20x=$200는 2차 소스만, 미확인(2026-07-20)** `[G-CODEXPRICE]` | 포함 |
| Business | $20~$25/유저 | 포함 |
| Enterprise/Edu | 영업문의 | 포함 |

> 공식 면책: "Price and plans are subject to change." `[C-PRICE]` → **당일 `claude.com/pricing` · `chatgpt.com/pricing` 재확인.**

---

## §K. 이 매트릭스로 학생 분기 판정하기 (요약 — 상세 규칙은 SKILL.md §분기)

- **git 미설치 & 설치 거부감** → ChatGPT Codex 먼저(git 불요 §C) → 이후 git 설치하고 Claude Code 합류.
- **Windows Home(10/11)** → Claude 로컬 Cowork 기대 말 것(§B) → Chat+Code 경로 또는 Remote Cowork.
- **Free 플랜만 보유** → Claude Code/Cowork 불가(§J) → ChatGPT 데스크톱(무료 3모드 제한적)로 시작, 업그레이드는 본인 결정.
- **mac** → git 대부분 기본 → Claude Code 즉시 가능(§B).
- **문헌 검색이 목표** → ChatGPT Deep Research(확인됨) + Claude Research(§L 실기기 확인 후) 비교.

---

## §L. "미확인" 항목 라이브 확인 절차 (수업 중 실기기로)

미확인 항목은 아는 척하지 않고, 학생 본인 기기에서 함께 확인한 뒤 표에 실측값을 적는다("안 되는 것"도 수업 재료).

1. **Claude Research 기능** — Claude Desktop Chat 탭을 열어 Research/연구 토글이 있는지 확인 → 있으면 §E에 "확인(날짜)", 없으면 "본 플랜 미제공".
2. **ChatGPT 신버전 최소 Windows 빌드** — 설치 실패 시 `winver`로 빌드 확인 → 공식 페이지와 대조.
3. **ChatGPT Pro 20x 가격** — 당일 `chatgpt.com/pricing`에서 실측.
4. **ChatGPT Scheduled Tasks Business/Edu 한도** — 해당 플랜 학생이면 앱 내 카운터로 실측.
5. **Windows Home + Cowork** — 실기기에서 Cowork 실행 시도 → 오류 메시지 원문을 캡처해 표에 기록.
6. **가격·쿼터 전반** — 표의 모든 $·횟수는 확정 발언 전 당일 공식 페이지 재확인.

> 실측한 값은 학생의 `progress.md` 또는 이 표 사본에 "확인일 YYYY-MM-DD, 값" 형식으로 남긴다.
