---
name: tutor-start
description: >
  Sam AI 과외의 첫 진입점(오케스트레이터). 한 번 부르면 (1) 학습자 인테이크를
  대화형으로 진행해 learner_profile.json 을 만들고 (2) 관심주제 우선순위 기반으로
  커리큘럼(모듈 순서)을 추천하고 (3) progress.md 가 있으면 읽어 "지난 시간 여기까지,
  숙제 어땠어요?"로 이어가며 (4) 해당 모듈 skill(tutor-apps-basics /
  tutor-paper-track / tutor-writing-track / tutor-stats-track / tutor-automation)
  을 반자동으로 이어 호출한다. 수강생이 개별 skill 이름을 몰라도 흐름을 탄다.
  Do not use for a specific module task — call that module's skill directly.
  Input: (선택) .sam/tutor/learner_profile.json · .sam/tutor/progress.md.
  Output: learner_profile.json (최초 1회) + progress.md 갱신 + 첫 모듈 진입.
  Pipeline position: sam-tutor 진입점 / 인테이크 → 커리큘럼 → 진도재개 → 모듈 라우팅.
  Medical context: 대상=의사·교수(CS 배경 없음), 환자정보 비반입 리마인드, 계정·결제
  대리 금지, 연구윤리 floor 상속.
  Trigger keywords: 과외 시작, 수업 시작, 오늘 수업, 튜터, 과외, 수업하자,
  이어서 하자, 지난 시간, 숙제, 어디까지 했지, 커리큘럼, 뭐부터 배울까,
  start tutoring, tutor start, resume lesson, where were we.
---

# tutor-start — AI 과외 진입점 (인테이크 → 커리큘럼 → 진도재개 → 모듈)

> Sam(안상현, MD) 모티프 1:1 AI 과외의 **첫 발화 진입점**. 대상 수강생은 **의사·교수 — CS/코딩 배경 없음**. 설명은 늘 평이하게, skill 이름을 몰라도 따라올 수 있게 한다.
>
> ⚠️ **이 팩은 Claude Desktop 의 Code 탭 전용이다.** Cowork 탭은 claude.ai 계정에 등록된 스킬만 읽고 **로컬 `.claude/skills/` 를 읽지 않아** 이 팩이 "not found"로 뜬다. 수강생이 Cowork 에서 불렀는데 안 보이면 → "Code 탭에서 다시 열어 주세요"로 안내한다. (근거: research_claude.md §4.2)
>
> ⚠️ **"끝까지 무인 자동"이 아니다.** Claude Code 에서 skill 은 확정적 워크플로 엔진이 아니라 모델이 자연어로 트리거하는 비결정적 구조다. 그래서 tutor-start 는 **각 단계를 안내하는 내비게이터** — 수강생이 **"다음"** 하기 전엔 다음 단계로 넘어가지 않는다(비개발자 통제감·교착 방지).

## 언제 부르나

- 처음 과외를 시작할 때 ("과외 시작하자", "수업 시작") → 인테이크부터.
- 다음 세션을 다시 열 때 ("이어서 하자", "오늘 수업") → `progress.md` 읽고 이어감.
- 특정 모듈 작업만 할 땐 이 skill 이 아니라 **해당 모듈 skill 을 직접** (tutor-apps-basics 등).

## 상태 파일 위치

- `paper_home` 대신 **과외 홈 폴더**(수강생이 지정, 예: `내-과외/`) 아래 `.sam/tutor/` 를 쓴다.
- `learner_profile.json` — 학습자 프로파일(최초 1회). 스키마: `${CLAUDE_SKILL_DIR}/../_shared/schemas/learner_profile.schema.json`.
- `progress.md` — 회차별 진도 원장(매 세션 갱신). 템플릿: `${CLAUDE_SKILL_DIR}/../_shared/templates/progress_template.md`.
- (변수 `${CLAUDE_SKILL_DIR}` 가 그대로 보이면 Claude 가 절대경로로 치환한다.)

## 절차

### 0) 현재 상태 파악 — 신규 vs 이어가기 분기

- `.sam/tutor/progress.md` 와 `learner_profile.json` 존재 확인.
  - **둘 다 있으면 → "이어가기"** (아래 7로 점프). 인테이크는 건너뛰고 재확인만.
  - **없으면 → "신규"** (아래 1 인테이크부터).

### 1) 학습자 인테이크 (신규 최초 1회 · 대화형)

> 핵심 규칙: **한 번에 다 묻지 않는다.** 3~4개씩 나눠 묻고, 답을 받은 뒤 다음 묶음으로. 비개발자가 통제감을 잃지 않게. 답변은 `learner_profile.json`(스키마 준수)에 기록하되, enum 값은 스키마 값 그대로 저장한다(자유 텍스트로 바꿔 쓰지 않음).

**묶음 A — 누구신가요 (3개)**
```
과외를 시작하기 전에 몇 가지만 여쭐게요. 편하게 답해 주세요.
1) 어떤 일을 하세요?  (교수 / 개원의 / 봉직의 / 전공의 / 연구자 / 기타)
2) 주로 쓰는 컴퓨터는?  (Windows 10 / Windows 11 / Mac)
3) AI 앱은 얼마나 써 보셨어요?  (처음이에요 / 챗은 써 봤어요 / 자동화까지 해봤어요)
```
→ `role`, `os`, `level`(초심/중급/상급) 기록.

**묶음 B — 앱·환경 (3개)**
```
좋습니다. 이번엔 지금 갖고 계신 도구를요.
4) Claude 구독은?  (없음 / 무료 / Pro / Max 5x / Max 20x)
5) ChatGPT 구독은?  (없음 / 무료 / Plus / Pro / Business)
6) (Windows면) Git 이라는 프로그램 설치돼 있나요?  (예 / 아니오 / 모르겠어요)
```
→ `subscriptions.claude`, `subscriptions.gpt`, `git_installed` 기록.
- ℹ️ **왜 묻나(수강생에게 설명할 것)**: Claude 의 Code 탭·Cowork 는 **무료 플랜에선 안 됩니다**(Pro 이상 필요). Windows 에서 Code 탭 로컬 작업은 **Git 설치가 필수**입니다(Mac 은 대개 기본 포함). 이게 첫 수업(M0) 진행 경로를 가릅니다. (근거: research_claude.md §3.1, §6)
- git_installed 를 "모르겠어요"로 답하면 `unknown` 으로 두고, M0 에서 실기기 확인한다.

**묶음 C — 무엇을 원하세요 (2개)**
```
마지막이에요.
7) 어떤 걸 먼저 배우고 싶으세요? 순서대로 골라 주세요.
   (앱 기본 / 논문 / 글쓰기 / 통계 / 자동화)
8) 이번 과외로 이루고 싶은 딱 한 가지를 한 줄로 적어 주신다면?
   (예: "외래 안내문 자동으로 만들기", "종설 한 편 마무리")
```
→ `topics_priority`(apps/paper/writing/stats/automation 배열), `goal_text` 기록.

**묶음 D — 주의사항 (조건부 1개)**
```
9) 수업 재료로 환자 정보나 민감한 개인정보를 다룰 일이 있나요? (예 / 아니오)
```
→ `constraints` 기록. "예"면 `"환자정보 다룸"` 을 넣고 **아래 안전선(4) 리마인드를 매 세션 시작 시 반복**한다. 병원 PC 설치권한 문제 등도 자유롭게 이 목록에 담는다.

인테이크가 끝나면 `learner_profile.json` 을 저장하고, 수강생에게 **읽어 주며 한 번 확인**받는다("이렇게 정리했어요 — 맞나요?"). 틀리면 그 필드만 고친다.

### 2) 커리큘럼 추천 (topics_priority 기반 모듈 순서)

인테이크가 끝나면 **자동화 사다리(스파인)**를 1분 소개하고, 모듈 순서를 제안한다.

```
모든 과외는 '자동화 사다리'를 오릅니다:
L0 앱 세팅 → L1 워크플로우 글로 적기 → L2 파이프라인화 → L3 스킬화 → L4 예약 실행
졸업 = 선생님 업무 하나가 L3 이상(자연어 한 마디로 돎)에 도달하는 것.
```
(사다리 상세: `${CLAUDE_SKILL_DIR}/../_shared/templates/automation_ladder.md`)

**모듈 순서 규칙:**
- **level 이 초심/중급 → 항상 M0(양대 앱 기본)부터.** 앱 세팅·탭 구분 없이는 나머지가 안 선다.
- level 이 상급이면 M0 는 빠르게 확인만 하고 `topics_priority` 첫 항목 모듈로 진입 가능.
- M0 이후엔 `topics_priority` 순서대로: `paper`→M1, `writing`→M2, `stats`→M3, `automation`→M4. (`apps` 는 M0 자체.)

| topics_priority 값 | 모듈 | skill | v1 완성도 |
|---|---|---|---|
| apps | M0 양대 앱 기본 | `tutor-apps-basics` | 완성 |
| paper | M1 논문 | `tutor-paper-track` | 완성 |
| writing | M2 글쓰기 | `tutor-writing-track` | 스켈레톤 |
| stats | M3 통계 | `tutor-stats-track` | 스켈레톤 |
| automation | M4 자동화 | `tutor-automation` | 스켈레톤 |

추천을 이렇게 제시한다(예):
```
추천 순서예요: ① M0 앱 기본 → ② M1 논문 → ③ M4 자동화
(선생님이 고른 우선순위: 논문 > 자동화 기준)
오늘은 M0 부터 시작할까요? "다음" 하시면 첫 수업으로 들어갑니다.
```
- 스켈레톤 모듈(M2/M3/M4)은 "아직 뼈대만 있어 목차 위주로 진행됩니다"라고 정직하게 알린다.

### 7) 진도 재개 (이어가기 세션 — progress.md 있음)

`progress.md` 를 읽고 **이렇게 연다**:
```
지난 시간(제N회차)엔 [모듈/단계] 까지 했어요. 사다리는 [모듈 L?] 입니다.
숙제로 [숙제 내용] 를 드렸는데, 해 보셨어요? 어땠나요?
```
- 숙제 확인 → 막힌 곳 있으면 먼저 풀어 준다.
- constraints 에 `"환자정보 다룸"` 이 있으면 여기서 **비반입 리마인드 1줄**을 먼저 붙인다.
- 그다음 `progress.md` 의 "다음 세션 계획"대로 해당 모듈 skill 로 이어간다.
- **재확인만**: 프로파일이 바뀌었는지(구독 업그레이드, git 설치 완료 등) 가볍게 확인하고, 바뀐 필드만 `learner_profile.json` 에 갱신한다. 인테이크 전체를 다시 하지 않는다.

### 3) 모듈 라우팅 + 반자동 내비게이션 (핵심)

각 수업/모듈 **종료 시 반드시 다음 3줄을 출력**(종료 훅 — 수강생이 "지금 어디 있고 다음에 뭘 할지" 항상 알게):
```
✅ [오늘 모듈/회차] 완료 — [핵심 산출물·배운 것 1줄]
다음: [다음 모듈 또는 다음 회차 계획]  →  /[다음-skill-name]
계속하려면 "다음"   (다른 주제로 가려면 말씀만, 오늘 그만하면 진도 저장할게요)
```
- 수강생이 **"다음"** 하기 전엔 다음 모듈로 넘어가지 않는다.
- "다음" 입력 시 해당 모듈 skill 을 Skill tool 로 호출한다. **호출이 불확실하면 멈추지 말고** *"`/[skill-name]` 을 입력해 주세요"* 로 정확한 명령을 제시(수강생이 막히지 않게).
- 모듈 skill 이름: `tutor-apps-basics`, `tutor-paper-track`, `tutor-writing-track`, `tutor-stats-track`, `tutor-automation`.

### 8) 세션 종료 — 진도 저장 (매 세션 끝)

수강생이 "오늘 그만", "여기까지" 하면:
1. `progress.md` 맨 위에 **새 회차 블록**을 추가한다(템플릿의 회차 블록 복사): 회차 번호·오늘 다룬 모듈/단계·사다리 이동·핵심 1~3줄·막힌 곳·**숙제**·다음 세션 계획.
2. 사다리 현황판 표도 갱신(모듈 위치 L?, 상태).
3. 마지막으로 한 줄 요약 + 숙제를 다시 읽어 준다("다음까지 [숙제], 다음엔 [계획] 할게요").

## 안전선 (모드·모듈 무관 강제 — 워크숍팩 계승 + 과외 특화)

- 🔒 **환자정보·개인정보 비반입** — 수강생이 의사이므로 실습 재료에 환자 식별정보·PHI 금지. 통계(M3)는 원자료 비반입(요약통계·구조만). `constraints` 에 "환자정보 다룸"이 있으면 매 세션 시작 시 리마인드.
- 🔒 **계정·결제 대리 금지** — 구독 가입·로그인·결제·설치 실행은 **수강생 본인이 직접**. 튜터·AI 는 자격증명(비밀번호·카드번호)을 받지 않는다.
- 🔒 **연구윤리 상속** — M1(논문)은 기존 팩의 floor(IRB·AI 활용 공개문·authorship·COI) 그대로 따른다.
- 🔒 **정직성** — 확인 안 된 기능·쿼터는 아는 척하지 않는다. "안 되는 것"(예: Cowork 가 이 PC 에선 안 됨)도 훌륭한 수업 재료다.

## 출력

- `.sam/tutor/learner_profile.json` (신규 최초 1회 · 스키마 준수)
- `.sam/tutor/progress.md` (매 세션 갱신)
- 첫 모듈 진입 — 커리큘럼 첫 모듈 skill 호출

## 자주 발생하는 함정

1. **인테이크를 한 번에 다 물음** — 3~4개씩 나눠 묻는다(§1). 비개발자 통제감.
2. **이어가기인데 인테이크를 또 함** — `progress.md` 가 있으면 §7 로 점프, 재확인만.
3. **모듈만 할 건데 tutor-start 재호출** — 특정 모듈만 할 땐 해당 skill 직접(여긴 진입/이어가기 전용).
4. **Cowork 에서 안 보인다고 당황** — 이 팩은 Code 탭 전용. "Code 탭에서 여세요"로 안내.
5. **git/구독 확인 없이 M0 진행** — win + Free 또는 git 미설치면 M0 경로가 갈린다. §1 묶음 B 를 먼저.

## 다음 단계
→ 인테이크·커리큘럼 확정 후 **첫 모듈(대개 M0 `tutor-apps-basics`)** 자동 시작. 이후 각 모듈은 사다리를 오르며 종료 훅으로 이어가고, 세션 끝에 `progress.md` 를 저장한다.
