# Bonus Track — AI 시험 출제 파이프라인 데모

> 의대 교수 워크숍(D-2026-06-20) 보너스 트랙 30~45분 세션용 **end-to-end reference deliverable**.
> 메인 워크숍의 `exam-item-builder`(빠른 단발 생성)와 별도로, **SSOT → Generate → 7-Gate → Answer Package → Appeal**까지 보여주는 완성형 데모 1편.

## 가장 쉬운 시작: Code 탭 ⭐ → [`START_HERE_code.md`](START_HERE_code.md)

Claude Desktop **Code 탭**에서 이 폴더를 열고 **프롬프트 한 번**이면 끝 — 프로젝트 생성·파일 업로드 불필요(Code 탭이 작업 폴더 파일을 직접 읽음). 워크숍 메인 흐름과 동일.

> 💡 **Tip**: Project 기능을 쓰고 싶으면 **Cowork**로 전환(Desktop 앱에서 클릭 한 번) — 샌드박스라 더 안전하고, 이 폴더 자료를 Project 지식으로 등록해 여러 대화에서 재사용 가능.

### 대안: Claude Desktop Project (코드 회피·채팅 전용)

참가자가 모두 Claude 구독자(Pro/Team/Max)면 API 호출 없이 **구독 세션 그대로** Project로도 가능. 설정: [`claude_desktop_bundle/README.md`](claude_desktop_bundle/README.md).

| 항목 | 내용 |
|---|---|
| 폴더 | **`claude_desktop_bundle/`** ⭐ |
| 의존성 | Claude Desktop 앱 또는 claude.ai 웹 |
| API 키 | **불필요** (구독으로 작동) |
| 비용 | **0원** (별도 결제 없음) |
| 자동화 | Chat 1번(one-shot) 또는 5번(step-by-step) |

자세한 사용법은 [`claude_desktop_bundle/README.md`](claude_desktop_bundle/README.md).

## 노트북 옵션 (API 자동화 필요 시)

| 노트북 | 용도 | 의존성 | 비용 |
|---|---|---|---|
| `workshop_standalone.ipynb` | API 자동 chaining (Claude only) | Anthropic Console API 키 | **별도 결제** |
| `workshop.ipynb` | + multi-model 분리 (Claude+OpenAI) | Anthropic + OpenAI 2개 키 | 별도 결제 |

이 두 노트북은 자동 5단계 chaining이나 multi-model 분리가 필요한 고급 사용자용. 일반 배포 기본값은 **Code 탭** ([`START_HERE_code.md`](START_HERE_code.md)).

---

## 폴더 구조

```
bonus_track/exam_pipeline_demo/
│
├── README.md                          ← 본 문서
├── workshop_standalone.ipynb          ⭐ 배포용 단일 노트북 (49 KB, Claude only)
├── workshop.ipynb                     정식판 (14 KB, helper 파일 별도 필요)
│
├── ssot/                              ← SSOT 자산 (정식판이 로드)
│   ├── lecture_chestpain.md
│   └── ssot_package.json
├── specs/
│   ├── blueprint.json
│   ├── item_spec.json
│   └── difficulty_spec.json
├── outputs/                           ← 사전 생성된 reference deliverable
│   ├── 01_generated_item.json
│   ├── 02_gate_report.json
│   ├── 03_model_answer_package.json
│   ├── 04_appeal_decision.json
│   ├── exam.md                        ← 학생 배포본
│   └── appeal_report.md               ← 이의제기 보고서
│
├── prompts.py                         ← 5종 system/user 프롬프트
├── pipeline_steps.py                  ← API wrapper + 5단계 함수
├── build_notebook.py                  ← 정식판 빌더
├── build_standalone_notebook.py       ⭐ 배포판 빌더 (자산을 노트북에 인라인)
│
├── _smoke_test.py                     ← 모듈 + 자산 sanity check
├── _validate.py                       ← 정식판 syntax 검증
└── _validate_standalone.py            ← 배포판 syntax 검증
```

---

## 배포 시나리오 3가지

### A. 단일 파일 배포 (default, 추천) ⭐

**1) 이메일/Drive/Slack 첨부**

`workshop_standalone.ipynb` (49 KB) 한 파일만 첨부해서 보낸다.

**참가자 절차** (5분):
1. [colab.research.google.com](https://colab.research.google.com) 열기
2. `파일 → 노트북 업로드` → 받은 `.ipynb` 선택
3. `Shift+Enter`로 위에서 아래까지 실행
4. Cell 3에서 임시 공용 또는 본인 Anthropic 키 입력
5. 4분 뒤 `outputs/`에 6개 산출물 (4 JSON + exam.md + appeal_report.md)

**장점**: zip 업로드 불필요. Anthropic 키 1개만 있으면 됨.

---

### B. GitHub repo + "Open in Colab" 배지

GitHub Public Repo (또는 Gist)에 푸시 후, README에 배지:

```markdown
[![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/USER/REPO/blob/main/workshop_standalone.ipynb)
```

**참가자 절차** (1분):
1. README의 "Open in Colab" 배지 클릭 → 즉시 Colab에서 열림
2. 위에서 아래로 실행

**장점**: 한 클릭. 사전 배포 없이 워크숍 당일 링크 한 줄만 공유.

**준비 작업**: GitHub repo 생성 → `git push` → README 배지 추가.

---

### C. claude.ai Projects (코드 회피, 채팅으로만)

코딩 자체를 피하고 싶은 교수용. Colab/Python 불필요.

**준비 작업**:
1. claude.ai에서 새 Project 생성
2. **Project 지식**에 `ssot/lecture_chestpain.md` 업로드
3. **Project 지침**에 `prompts.py`의 `GENERATOR_SYSTEM` 등을 합쳐서 붙여넣기

**참가자 절차**:
1. Project에서 `"문항 1개 만들어줘 (CP-01, M3)"` 입력 → JSON 응답
2. `"이 문항 7-Gate 검증해줘"` → JSON 응답
3. `"모범답안 패키지 만들어줘"` → JSON 응답
4. `"학생이 'B와 C 둘 다 정답' 이의제기 했어. 처리해줘"` → JSON 응답

**장점**: 코딩 0줄. claude.ai 구독만 있으면 OK.
**단점**: 자동 저장·multi-step 자동 chaining·JSON 검증은 수동.

---

## 모델 설정 (배포판)

`workshop_standalone.ipynb` Cell 3에서:

```python
GENERATOR_MODEL = "claude-sonnet-4-20250514"   # Step 1: 빠른 생성
CRITIC_MODEL    = "claude-opus-4-20250514"     # Step 2: 강한 비판 (Generator와 다른 family)
ANSWER_MODEL    = "claude-sonnet-4-20250514"   # Step 3-4
```

**왜 Sonnet ↔ Opus?** Generator와 Solver를 같은 모델로 돌리면 동질화 오차 — Generator가 만든 함정을 Solver가 못 잡음. Claude family 안에서도 다른 모델을 쓰는 게 안전.

비용 최적화하려면 모두 Sonnet로 두고 system prompt만 강하게 바꿀 수도 있지만, 데모에선 모델 분리가 명확.

---

## 워크숍 데모 흐름 (40분)

| 시간 | 단계 |
|------|------|
| 0~5 | 패러다임 전환: AI가 출제 ≠ 워크플로우를 AI가 강화 |
| 5~10 | 배지 클릭 / 파일 업로드 + Anthropic 키 입력 |
| 10~25 | 강사 데모: 흉통 SSOT → 1문항 → 7-Gate (G4 일부러 fail 시연) → 모범답안 → 이의제기 |
| 25~35 | 참가자 따라하기: 본인 환경에서 동일 흐름 (또는 SSOT 일부 교체) |
| 35~40 | Q&A + 사후 운영 가이드 |

---

## 자기 강의노트로 교체

`workshop_standalone.ipynb` **Cell 4**의 `SSOT = json.loads(r"""..."""` 안 JSON에서 `layers` 배열의 텍스트를 본인 강의 내용으로 교체:

```python
SSOT = json.loads(r"""
{
  "ssot_package": {
    "package_id": "MyTopic_SSOT_2026_v1",
    "topic": "내 강의 주제",
    "layers": [
      {
        "layer": 1, "name": "Learning Objectives",
        "items": [{"id": "MY-01", "text": "내 학습목표 1", ...}]
      },
      {
        "layer": 2, "name": "Lecture Notes",
        "items": [{"id": "LN-MY-01", "text": "내 강의노트 1", ...}]
      },
      ...
    ]
  }
}
""")
```

**Cell 5**의 `BLUEPRINT`에서 `learning_objective_ids`도 본인 LO ID로 교체.

---

## 검증 도구

```bash
python _smoke_test.py            # 모듈 import + 자산 로드 + 렌더 함수 dry-run
python _validate.py              # workshop.ipynb 셀별 syntax 검사
python _validate_standalone.py   # workshop_standalone.ipynb 셀별 + 자산 임베드 확인
```

워크숍 직전 helper 모듈이 망가졌는지 확인.

---

## 설계 근거

`C:\Users\ansan\.claude\skills\3ai-consult\outputs\3ai-consult_20260521-1850_exam-workflow-pipeline.md`
— Claude + Gemini 3.5 Flash + GPT-5.5 3AI 합의안.

## 시작 시점

2026-05-21. D-30(2026-06-15 dry-run) 일정에 맞춰 단계별 산출.

## 의존성 요약

| 노트북 | 패키지 | API 키 |
|---|---|---|
| `workshop_standalone.ipynb` ⭐ | `anthropic` | Anthropic 1개 |
| `workshop.ipynb` | `anthropic` + `openai` | Anthropic + OpenAI 2개 |
| (선택) docx 변환 | `pandoc` (apt-get) | — |

---

## 보안 가이드 (참가자 안내문)

- ✅ API 키는 워크숍 종료 즉시 폐기·회수 (특히 임시 공용 키)
- ✅ 학생 개인정보·실제 출제 예정 문항을 퍼블릭 LLM에 입력 금지
- ✅ 생성된 문항은 본인 분야 정확성 검토 후 사용
- ✅ 실제 시험 투입 전 평가위원회 승인 필수
- ⚠️ 본 노트북은 데모용. 보안 모드는 학내 Sam AI v1.3 파이프라인 사용
