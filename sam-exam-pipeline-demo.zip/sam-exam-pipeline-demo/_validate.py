"""Validate workshop.ipynb structure + Python syntax of code cells + helper modules."""
import ast
import json

nb = json.load(open("workshop.ipynb", encoding="utf-8"))
print(f"cells={len(nb['cells'])}, nbformat={nb['nbformat']}.{nb['nbformat_minor']}")

errors = []
for i, c in enumerate(nb["cells"]):
    src = c["source"] if isinstance(c["source"], str) else "".join(c["source"])
    print(f"  [{i+1:2d}] {c['cell_type']:8s} ({len(src):5d} chars)")
    if c["cell_type"] == "code":
        # strip Jupyter ! shell + % magic lines for ast.parse
        clean = "\n".join(
            L for L in src.split("\n")
            if not L.lstrip().startswith(("!", "%"))
        )
        try:
            ast.parse(clean)
        except SyntaxError as e:
            errors.append(f"cell {i+1}: {e}")

print()
if errors:
    print("SYNTAX ERRORS:")
    for err in errors:
        print(f"  {err}")
else:
    print("All code cells parse OK.")

for fname in ["prompts.py", "pipeline_steps.py"]:
    try:
        ast.parse(open(fname, encoding="utf-8").read())
        print(f"{fname}: parse OK")
    except SyntaxError as e:
        print(f"{fname}: SYNTAX ERROR {e}")
