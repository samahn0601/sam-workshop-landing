"""
워크숍 보너스 트랙 — workshop_standalone.ipynb 빌더.

목적: zip 업로드 못하는 환경(Colab 등)에서도 .ipynb 단일 파일만 업로드하면
즉시 실행되는 self-contained 노트북. Claude API 키 1개만 필요(OpenAI 불필요).

동질화 오차 회피: Generator=Sonnet vs Critic(Verifier+Solver)=Opus로 분리.

실행:
    python build_standalone_notebook.py
산출:
    workshop_standalone.ipynb
"""
import json
from pathlib import Path

BASE = Path(__file__).parent


def _load(p: str) -> str:
    return (BASE / p).read_text(encoding="utf-8")


# ═══════════════════════════════════════════════════════════════════
# 자산 임베드 — 외부 파일을 inline JSON string으로 박음
# ═══════════════════════════════════════════════════════════════════
SSOT_JSON = _load("ssot/ssot_package.json")
BLUEPRINT_JSON = _load("specs/blueprint.json")
ITEM_SPEC_JSON = _load("specs/item_spec.json")
DIFFICULTY_SPEC_JSON = _load("specs/difficulty_spec.json")
# prompts는 따로 inline 셀에 (긴 string)
PROMPTS_PY = _load("prompts.py")


# ═══════════════════════════════════════════════════════════════════
# 13개 셀 정의
# ═══════════════════════════════════════════════════════════════════
CELLS = []

# ── Cell 1: 헤더 ──────────────────────────────────────────────────
CELLS.append(("markdown", """# 🩺 AI 시험 문제 출제 파이프라인 — Standalone 워크숍 노트북

> **Claude only 버전** — Anthropic API 키 1개만으로 5단계 전체 실행.
> OpenAI 키 불필요. zip 없이 본 노트북 한 파일만 업로드하면 끝.

## 배포 방식 3가지

| 방식 | 대상 | 절차 |
|---|---|---|
| **A. 본 단일 노트북** | zip 못 올리는 환경 | Colab → `파일 → 노트북 업로드` → 위에서 아래로 실행 |
| **B. GitHub raw URL** | 공유 링크로 즉시 시작 | Colab → `파일 → 노트북 열기 → URL` 탭에 raw `.ipynb` 주소 |
| **C. claude.ai Projects** | 코딩 회피, 채팅으로만 | Cell 6의 프롬프트를 claude.ai Projects 또는 chat에 직접 사용 |

## 5단계 파이프라인 (모두 Claude)

| 단계 | 역할 | 모델 |
|---|---|---|
| 1️⃣ SSOT 입력 | 다층 강의노트·교과서·지침 | — |
| 2️⃣ 문항 생성 | KMLE SBA 5지선다 | Claude **Sonnet** (Generator) |
| 3️⃣ 7-Gate 검증 + Solver | fail-closed | Claude **Opus** (Critic, 다른 모델 패밀리) |
| 4️⃣ 모범답안 패키지 | 학생용 + 교수용 | Claude Sonnet |
| 5️⃣ 이의제기 대응 | 자동 분류 + 보고서 | Claude Sonnet |

**왜 Sonnet ↔ Opus를 섞나?** Generator와 Solver를 같은 모델로 돌리면 동질화 오차가 생긴다(Generator가 만든 함정을 Solver가 못 잡음). Claude family 안에서도 다른 모델을 쓰는 게 안전.

## ⚠️ 주의

- AI 문항은 **초안**입니다. 실제 시험 사용 전 본인 분야 정확성 검토 + 평가위원회 승인 필수.
- 약물 용량·소아·임신부 문항은 의도적 회피(`avoid_drug_dose_questions: true`).
- API 키는 워크숍 종료 후 즉시 폐기.
"""))

# ── Cell 2: Setup ─────────────────────────────────────────────────
CELLS.append(("code", r"""# 패키지 설치 (Colab 첫 실행 시만)
!pip install -q anthropic

import json, os, re
from typing import Any, Dict
from getpass import getpass
from IPython.display import Markdown, display

print("✅ Imports OK")
"""))

# ── Cell 3: API key + 모델 선택 ───────────────────────────────────
CELLS.append(("code", r"""# Anthropic API 키 입력 + 모델 분리
if not os.environ.get("ANTHROPIC_API_KEY"):
    os.environ["ANTHROPIC_API_KEY"] = getpass("Anthropic API Key (sk-ant-...): ")

print(f"Anthropic key: {os.environ['ANTHROPIC_API_KEY'][:7]}***")

# 모델 분리 — 동질화 오차 회피
# 워크숍 시점(2026-06)의 최신 모델로 자유롭게 교체 가능.
GENERATOR_MODEL = "claude-sonnet-4-20250514"   # Step 1: 빠른 문항 생성
CRITIC_MODEL    = "claude-opus-4-20250514"     # Step 2: 7-Gate Verifier + Solver
ANSWER_MODEL    = "claude-sonnet-4-20250514"   # Step 3-4: 모범답안 + 이의제기

print(f"Generator: {GENERATOR_MODEL}")
print(f"Critic:    {CRITIC_MODEL}  (Verifier + Solver — Generator와 다른 패밀리)")
print(f"Answer:    {ANSWER_MODEL}")
"""))

# ── Cell 4: SSOT inline ───────────────────────────────────────────
CELLS.append(("code", f'''# ═══════════════════════════════════════════════════════════════════
# SSOT — 흉통 감별진단 1페이지 (L1·L2·L3·L4·L5 다층)
#
# 👉 자기 강의노트로 바꾸려면 이 dict의 layers 안 텍스트만 교체하세요.
# ═══════════════════════════════════════════════════════════════════
SSOT = json.loads(r"""
{SSOT_JSON}""")

print(f"📚 SSOT 로드 완료")
print(f"   ID:     {{SSOT['ssot_package']['package_id']}}")
print(f"   주제:    {{SSOT['ssot_package']['topic']}}")
print(f"   레이어: {{len(SSOT['ssot_package']['layers'])}}개")
for layer in SSOT['ssot_package']['layers']:
    n = len(layer.get('items', []))
    print(f"     L{{layer['layer']}} {{layer['name']:<25s}}: {{n}}개 (신뢰도 {{layer.get('trust_score', '?')}})")
'''))

# ── Cell 5: Specs inline ──────────────────────────────────────────
CELLS.append(("code", f'''# Blueprint + Item Spec + Difficulty Spec (인라인)
BLUEPRINT = json.loads(r"""
{BLUEPRINT_JSON}""")

ITEM_SPEC = json.loads(r"""
{ITEM_SPEC_JSON}""")

DIFFICULTY_SPEC = json.loads(r"""
{DIFFICULTY_SPEC_JSON}""")

print("⚙️ Specs 로드 완료")
print(f"   Blueprint:  {{BLUEPRINT['blueprint']['exam_id']}}")
print(f"   형식:       {{ITEM_SPEC['item_spec']['format']}}")
axes = DIFFICULTY_SPEC['difficulty_spec']['axes']
print(f"   3축:        bloom={{axes['bloom_level']}}, year={{axes['year_level']}}, task={{axes['clinical_task']}}")
print(f"   목표 정답률: {{DIFFICULTY_SPEC['difficulty_spec']['psychometric_targets']['target_p_value']}}")
print(f"   안전 정책:  avoid_drug_dose={{BLUEPRINT['blueprint']['safety_constraints']['avoid_drug_dose_questions']}}")
'''))

# ── Cell 6: Prompts inline ────────────────────────────────────────
# prompts.py 내용을 그대로 exec — 변수들이 cell scope에 정의됨
CELLS.append(("code", f'''# ═══════════════════════════════════════════════════════════════════
# 5단계 프롬프트 (Generator / Verifier / Solver / Answer / Appeals)
# 교수가 자기 영역에 맞게 수정 가능. 핵심 규칙은 그대로 유지하세요.
# ═══════════════════════════════════════════════════════════════════
{PROMPTS_PY}

print("📝 프롬프트 5종 로드:")
print(f"   - GENERATOR ({{len(GENERATOR_SYSTEM)}}+{{len(GENERATOR_USER)}} chars)")
print(f"   - VERIFIER  ({{len(VERIFIER_SYSTEM)}}+{{len(VERIFIER_USER)}} chars)")
print(f"   - SOLVER    ({{len(SOLVER_SYSTEM)}}+{{len(SOLVER_USER)}} chars)")
print(f"   - ANSWER    ({{len(ANSWER_PACKAGE_SYSTEM)}}+{{len(ANSWER_PACKAGE_USER)}} chars)")
print(f"   - APPEALS   ({{len(APPEALS_SYSTEM)}}+{{len(APPEALS_USER)}} chars)")
'''))

# ── Cell 7: Helper functions ──────────────────────────────────────
CELLS.append(("code", r'''# ═══════════════════════════════════════════════════════════════════
# 5단계 함수 + API wrapper + JSON 추출 + Markdown 렌더
# (Claude only — OpenAI 의존 없음)
# ═══════════════════════════════════════════════════════════════════

def call_claude(system: str, user: str, model: str, max_tokens: int = 6000) -> str:
    """Anthropic Claude 단일 호출."""
    import anthropic
    client = anthropic.Anthropic()
    resp = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    return resp.content[0].text


def extract_json(text: str) -> Dict[str, Any]:
    """LLM 응답에서 JSON 객체 추출 (```json 블록 포함)."""
    if not text:
        raise ValueError("Empty LLM response.")
    m = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
    if m:
        text = m.group(1)
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError(f"No JSON object in response: {text[:200]}")
    return json.loads(text[start:end + 1])


def _as_str(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2) if isinstance(obj, (dict, list)) else str(obj)


# ─── 5단계 ────────────────────────────────────────────────────────

def step1_generate_item(ssot, blueprint, item_spec, difficulty_spec):
    user = GENERATOR_USER.format(
        ssot=_as_str(ssot), blueprint=_as_str(blueprint),
        item_spec=_as_str(item_spec), difficulty_spec=_as_str(difficulty_spec),
    )
    return extract_json(call_claude(GENERATOR_SYSTEM, user, GENERATOR_MODEL))


def step2_verify_with_solver(item_result, ssot, blueprint, item_spec):
    # 7-Gate Verifier (Opus, 강한 비판)
    user = VERIFIER_USER.format(
        item=_as_str(item_result), ssot=_as_str(ssot),
        blueprint=_as_str(blueprint), item_spec=_as_str(item_spec),
    )
    gate_raw = extract_json(call_claude(VERIFIER_SYSTEM, user, CRITIC_MODEL))
    gate_report = gate_raw.get("gate_report", gate_raw)

    # Solver Agent (Opus, 정답 라벨 제거 후 풀이) — Generator(Sonnet)와 다른 모델
    item_no_ans = json.loads(json.dumps(item_result))
    inner = item_no_ans.get("item", item_no_ans)
    inner.pop("answer_key", None)
    solver_user = SOLVER_USER.format(item_without_answer=_as_str(item_no_ans))
    solver_result = extract_json(call_claude(SOLVER_SYSTEM, solver_user, CRITIC_MODEL))

    return {"gate_report": gate_report, "solver_result": solver_result}


def step3_answer_package(item_result, ssot):
    user = ANSWER_PACKAGE_USER.format(item=_as_str(item_result), ssot=_as_str(ssot))
    return extract_json(call_claude(ANSWER_PACKAGE_SYSTEM, user, ANSWER_MODEL))


def step4_handle_appeal(item_result, answer_package, appeal_text, ssot):
    user = APPEALS_USER.format(
        item=_as_str(item_result), answer_package=_as_str(answer_package),
        appeal_text=appeal_text, ssot=_as_str(ssot),
    )
    return extract_json(call_claude(APPEALS_SYSTEM, user, ANSWER_MODEL))


# ─── 저장 / 렌더 ──────────────────────────────────────────────────

def save_json(obj, path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def save_text(text, path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def render_exam_markdown(item_result, answer_package):
    it = item_result.get("item", item_result)
    pkg = answer_package.get("model_answer_package", answer_package)
    sf = pkg.get("student_facing_explanation", {})
    options_md = "\n".join(f"- **{o['label']}.** {o['text']}" for o in it.get("options", []))
    why_not_md = "\n".join(f"- **{w['option']}**: {w.get('explanation', '')}"
                            for w in sf.get("why_not_others", []))
    meta = it.get("metadata", {})
    return f"""# 문항 {it.get('item_id', 'UNKNOWN')}

> **Bloom**: {meta.get('bloom_level', '?')} / **학년**: {meta.get('year_level', '?')} / **임상과제**: {meta.get('clinical_task', '?')}

## 문제

{it.get('stem', '')}

{options_md}

---

## 정답: **{it.get('answer_key', '?')}**

### 정답 해설
{sf.get('correct_answer_explanation', '')}

### 오답 해설
{why_not_md}

### Take-home
> {sf.get('take_home_message', '')}
"""


def render_appeal_markdown(appeal_result):
    ap = appeal_result.get("appeal", appeal_result)
    cls = ap.get("classification", {})
    dec = ap.get("decision", {})
    return f"""# 이의제기 심사 보고서 (AI 초안)

> ⚠️ **최종 판정은 평가위원회 의결**입니다.

## 분류
- 유형: {cls.get('appeal_type', '?')}
- 주장 정답: {', '.join(cls.get('claimed_correct_options', []))}
- 심각도: {cls.get('severity', '?')}

## 학생 이의제기
> {ap.get('submission_text', '(원문 누락)')}

## 판정: **{dec.get('outcome', '?').upper()}**

### 근거
{dec.get('rationale', '')}

| 항목 | 결정 |
|---|---|
| 정답 변경 | {dec.get('answer_key_status', '?')} |
| 점수 조정 | {dec.get('score_adjustment', '?')} |
| 문항 수정 | {dec.get('need_item_revision', False)} |

## 학생 공식 안내문 초안
{ap.get('student_facing_response', '(누락)')}
"""


print("🛠️  함수 정의 완료 (call_claude + 5단계 + 렌더 헬퍼)")
'''))

# ── Cell 8: STEP 1 ────────────────────────────────────────────────
CELLS.append(("code", r"""# ═══════════════════════════════════════════════════════════════════
# STEP 1. Generator (Claude Sonnet)
# ═══════════════════════════════════════════════════════════════════
print("⏳ STEP 1. Claude Sonnet에게 문항 생성 요청...")
item_result = step1_generate_item(SSOT, BLUEPRINT, ITEM_SPEC, DIFFICULTY_SPEC)

it = item_result.get('item', item_result)
print(f"\n✅ 문항 생성 완료: {it.get('item_id', 'UNKNOWN')}")
print(f"   정답: {it.get('answer_key', '?')}")
print(f"   evidence_links: {len(it.get('evidence_links', []))}개")

options_md = "\n".join(f"- **{o['label']}.** {o['text']}" for o in it['options'])
display(Markdown(f"### 생성된 문항\n\n{it['stem']}\n\n{options_md}"))
"""))

# ── Cell 9: STEP 2 ────────────────────────────────────────────────
CELLS.append(("code", r"""# ═══════════════════════════════════════════════════════════════════
# STEP 2. 7-Gate Verifier + Solver Agent (Claude Opus — Generator와 다른 모델)
# ═══════════════════════════════════════════════════════════════════
print("⏳ STEP 2. Claude Opus가 7-Gate 검증 + Solver Agent 풀이...")
verify_result = step2_verify_with_solver(item_result, SSOT, BLUEPRINT, ITEM_SPEC)

gate_report = verify_result['gate_report']
solver = verify_result['solver_result']

print(f"\n📋 7-Gate 종합 판정: **{gate_report.get('overall_status', '?').upper()}**\n")
for g in gate_report.get('gates', []):
    icon = "✅" if g['status'] == 'pass' else "❌"
    name = g.get('name', f"Gate {g.get('gate', '?')}")
    print(f"  {icon} Gate {g.get('gate', '?')}: {name:<35s} — {g['status']}")
    if g['status'] != 'pass':
        print(f"     사유: {g.get('comment', '')}")

print(f"\n🤖 Solver Agent (정답 라벨 제거 후 Opus가 풀이)")
print(f"   예측 정답:  {solver.get('predicted_answer', '?')} (실제: {it.get('answer_key', '?')})")
print(f"   Confidence: {solver.get('confidence', 0):.2f}")
print(f"   top2 gap:   {solver.get('top2_gap', 0):.2f} (임계값 ≥ 0.20)")

is_match = solver.get('predicted_answer') == it.get('answer_key')
gap_ok = solver.get('top2_gap', 0) >= 0.20
print("\n" + ("✅ Single Best Answer Gate 통과" if (is_match and gap_ok)
              else "⚠️ Single Best Answer Gate 주의 — 인간 검토 권장"))
"""))

# ── Cell 10: STEP 3 ───────────────────────────────────────────────
CELLS.append(("code", r'''# ═══════════════════════════════════════════════════════════════════
# STEP 3. 모범답안 패키지 — 학생용 + 교수용 분리 (Claude Sonnet)
# ═══════════════════════════════════════════════════════════════════
print("⏳ STEP 3. 모범답안 패키지 생성...")
package_result = step3_answer_package(item_result, SSOT)

pkg = package_result.get('model_answer_package', package_result)
sf = pkg.get('student_facing_explanation', {})

why_not_md = "\n".join(f"- **{w['option']}**: {w.get('explanation', '')}"
                        for w in sf.get('why_not_others', []))
display(Markdown(f"""## 📚 학생용 모범답안

**정답**: {pkg.get('answer_key', '?')}

{sf.get('correct_answer_explanation', '')}

### 오답 해설
{why_not_md}

**Take-home**: {sf.get('take_home_message', '')}
"""))

ar = pkg.get('faculty_facing_explanation', {}).get('appeal_risk', {})
print(f"\n📌 예상 이의제기 위험: **{ar.get('risk_level', '?').upper()}**")
for arg in ar.get('possible_appeal_arguments', []):
    print(f"   - {arg}")
'''))

# ── Cell 11: STEP 4 ───────────────────────────────────────────────
CELLS.append(("code", r'''# ═══════════════════════════════════════════════════════════════════
# STEP 4. 이의제기 자동 대응 (Claude Sonnet)
# 시나리오: 학생이 "B 폐색전증도 정답"이라고 주장
# ═══════════════════════════════════════════════════════════════════
STUDENT_APPEAL = """폐색전증도 급성 흉통의 중요한 감별진단입니다.
환자가 50대 후반 남성이고 흡연력이 있어 PE 위험인자에도 해당합니다.
따라서 B(폐색전증)와 C(급성 관상동맥증후군) 둘 다 정답으로 인정되어야 합니다."""

print("📨 학생 이의제기 접수:")
print(f"   '{STUDENT_APPEAL[:80]}...'")
print("\n⏳ STEP 4. AI 자동 분석...")

appeal_result = step4_handle_appeal(item_result, package_result, STUDENT_APPEAL, SSOT)

ap = appeal_result.get('appeal', appeal_result)
print(f"\n⚖️ 판정: **{ap['decision']['outcome'].upper()}**")
print(f"   정답 변경:      {ap['decision'].get('answer_key_status', '?')}")
print(f"   점수 조정:      {ap['decision'].get('score_adjustment', '?')}")
print(f"   문항 수정 필요: {ap['decision'].get('need_item_revision', False)}")
print(f"   인간 검토 필수: {ap.get('human_review_required', True)}")

display(Markdown(render_appeal_markdown(appeal_result)))
'''))

# ── Cell 12: STEP 5 ───────────────────────────────────────────────
CELLS.append(("code", r"""# ═══════════════════════════════════════════════════════════════════
# STEP 5. 결과 저장 (JSON + Markdown) + Colab 다운로드 안내
# ═══════════════════════════════════════════════════════════════════
os.makedirs('outputs', exist_ok=True)
save_json(item_result,    'outputs/01_generated_item.json')
save_json(verify_result,  'outputs/02_gate_report.json')
save_json(package_result, 'outputs/03_model_answer_package.json')
save_json(appeal_result,  'outputs/04_appeal_decision.json')

save_text(render_exam_markdown(item_result, package_result), 'outputs/exam.md')
save_text(render_appeal_markdown(appeal_result),             'outputs/appeal_report.md')

print("💾 저장 완료:\n")
for fn in sorted(os.listdir('outputs')):
    size_kb = os.path.getsize(f'outputs/{fn}') / 1024
    print(f"   outputs/{fn:<35s} ({size_kb:5.1f} KB)")

# Colab에서 ZIP으로 다운로드
print("\n📥 Colab에서 결과 다운로드:")
print("   !zip -r outputs.zip outputs/")
print("   from google.colab import files; files.download('outputs.zip')")

print("\n📄 docx 변환 (선택):")
print("   !apt-get install -qq pandoc")
print("   !pandoc outputs/exam.md -o outputs/exam.docx")
"""))

# ── Cell 13: 마무리 ───────────────────────────────────────────────
CELLS.append(("markdown", """## 🎉 데모 완료

40분 안에 강의노트 → 문항 1개 → 7-Gate 검증 → 모범답안 → 이의제기 대응까지 끝났습니다.

## 자기 강의노트로 교체

1. **Cell 4의 `SSOT` dict**에서 `layers` 안 텍스트를 본인 강의 내용으로 교체
2. **Cell 5의 `BLUEPRINT`**에서 `learning_objective_ids`를 본인 LO ID로 교체
3. **Cell 6의 프롬프트**는 그대로 두거나 본인 영역에 맞게 미세 조정
4. 노트북을 위에서 아래로 다시 실행

## 다른 배포 옵션

### Option B. GitHub raw URL로 공유
이 노트북을 GitHub Public Gist 또는 Repo에 푸시하면, Colab에서:
```
파일 → 노트북 열기 → URL 탭 → https://github.com/USER/REPO/blob/main/workshop_standalone.ipynb
```
한 클릭으로 열림. 또는 README에 "Open in Colab" 배지 추가:
```markdown
[![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/USER/REPO/blob/main/workshop_standalone.ipynb)
```

### Option C. claude.ai Projects (코드 회피)
이 노트북 없이 claude.ai에서만 시연:
1. claude.ai Projects 생성 → SSOT 텍스트 첨부
2. Cell 6의 `GENERATOR_USER` 프롬프트를 chat에 붙여넣기 → 문항 생성
3. 검증·해설·이의제기도 각 프롬프트를 차례로 붙여넣어 진행
4. 단점: 자동 검증·저장·multi-model 분리 불가. 시연용으로만.

## 반드시 기억할 함정 7가지

1. **SSOT 없는 LLM 생성** — 모든 핵심 claim에 `evidence_id` 매핑 강제
2. **"가능한 진단" vs "가장 가능성 높은 진단" 혼동** — stem에 음성 소견 명시
3. **AI 검증 = 인간 승인 오해** — 최종 판정은 평가위원회 의결
4. **L2 강의노트와 L4 최신 지침 충돌 묵인** — fail-closed → 인간 검토
5. **Solver와 Generator 같은 모델** — 본 노트북은 Sonnet ↔ Opus로 분리 회피
6. **fail/needs_review 배너가 출력에서 사라짐** — 출력 상단 명시 유지
7. **약물 용량/소아/임신부 문항** — 검증 부담 큼, 본 데모는 회피

## 워크숍 종료 후

- ✅ API 키 즉시 폐기·회수 (특히 임시 공용 키)
- ✅ 생성된 문항은 본인 분야 정확성 검토 후 사용
- ✅ 실제 시험 투입 전 평가위원회 승인 필수
- ✅ 학생 개인정보·실제 출제 예정 문항을 퍼블릭 LLM에 입력 금지

---
*Bonus Track Standalone v1.0 / Claude only / 2026-05-21 / Workshop D-30*
"""))


# ═══════════════════════════════════════════════════════════════════
# 직렬화
# ═══════════════════════════════════════════════════════════════════

def make_notebook(cells):
    nb_cells = []
    for ctype, source in cells:
        cell = {"cell_type": ctype, "metadata": {}, "source": source}
        if ctype == "code":
            cell["execution_count"] = None
            cell["outputs"] = []
        nb_cells.append(cell)
    return {
        "cells": nb_cells,
        "metadata": {
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python", "version": "3.10"},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }


def main():
    nb = make_notebook(CELLS)
    out = BASE / "workshop_standalone.ipynb"
    out.write_text(json.dumps(nb, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"Created {out.name} with {len(CELLS)} cells ({out.stat().st_size / 1024:.1f} KB)")


if __name__ == "__main__":
    main()
