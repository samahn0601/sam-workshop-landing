"""
워크숍 보너스 트랙 — AI 시험 출제 파이프라인 5단계 helper.

사용:
    from pipeline_steps import (
        step1_generate_item, step2_verify_with_solver,
        step3_answer_package, step4_handle_appeal,
        save_json, render_exam_markdown, render_appeal_markdown,
    )

환경변수 ANTHROPIC_API_KEY, OPENAI_API_KEY 필요.
"""
from __future__ import annotations

import json
import os
import re
from typing import Any, Dict

from prompts import (
    GENERATOR_SYSTEM, GENERATOR_USER,
    VERIFIER_SYSTEM, VERIFIER_USER,
    SOLVER_SYSTEM, SOLVER_USER,
    ANSWER_PACKAGE_SYSTEM, ANSWER_PACKAGE_USER,
    APPEALS_SYSTEM, APPEALS_USER,
)


# ─── 모델 설정 (필요 시 변경) ─────────────────────────────────────
ANTHROPIC_MODEL = "claude-sonnet-4-20250514"
OPENAI_MODEL = "gpt-5.5"
OPENAI_EFFORT = "medium"  # 빈 응답 발생 시 'low'로 강등


# ═══════════════════════════════════════════════════════════════════
# API 호출 wrapper
# ═══════════════════════════════════════════════════════════════════

def call_anthropic(system: str, user: str,
                   model: str = ANTHROPIC_MODEL,
                   max_tokens: int = 4096) -> str:
    """Anthropic Claude 호출. ANTHROPIC_API_KEY 환경변수 필요."""
    import anthropic
    client = anthropic.Anthropic()
    resp = client.messages.create(
        model=model,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    return resp.content[0].text


def call_openai(system: str, user: str,
                model: str = OPENAI_MODEL,
                effort: str = OPENAI_EFFORT) -> str:
    """OpenAI GPT 호출. OPENAI_API_KEY 환경변수 필요."""
    from openai import OpenAI
    client = OpenAI()
    resp = client.chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        reasoning_effort=effort,
    )
    content = resp.choices[0].message.content
    if not content:
        # operations notes: medium 빈 응답 시 low로 강등 재시도
        resp2 = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            reasoning_effort="low",
        )
        content = resp2.choices[0].message.content
    return content or ""


# ═══════════════════════════════════════════════════════════════════
# JSON 추출 (LLM이 ```json 블록으로 감싸도 OK)
# ═══════════════════════════════════════════════════════════════════

def extract_json(text: str) -> Dict[str, Any]:
    """LLM 응답에서 JSON 객체를 추출."""
    if not text:
        raise ValueError("Empty LLM response.")
    # 1) ```json ... ``` 블록 우선
    m = re.search(r"```(?:json)?\s*\n?(.*?)\n?```", text, re.DOTALL)
    if m:
        text = m.group(1)
    # 2) 첫 { 부터 마지막 }
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1:
        raise ValueError(f"No JSON object found in response: {text[:200]}")
    return json.loads(text[start:end + 1])


def _as_str(obj: Any) -> str:
    """dict/list → JSON 문자열, str은 그대로."""
    if isinstance(obj, (dict, list)):
        return json.dumps(obj, ensure_ascii=False, indent=2)
    return str(obj)


# ═══════════════════════════════════════════════════════════════════
# 5단계 파이프라인
# ═══════════════════════════════════════════════════════════════════

def step1_generate_item(ssot: dict, blueprint: dict,
                        item_spec: dict, difficulty_spec: dict) -> Dict[str, Any]:
    """STEP 1. Generator(Claude) — SSOT/spec → 문항 1개."""
    user = GENERATOR_USER.format(
        ssot=_as_str(ssot),
        blueprint=_as_str(blueprint),
        item_spec=_as_str(item_spec),
        difficulty_spec=_as_str(difficulty_spec),
    )
    response = call_anthropic(GENERATOR_SYSTEM, user)
    return extract_json(response)


def step2_verify_with_solver(item_result: dict, ssot: dict,
                             blueprint: dict, item_spec: dict) -> Dict[str, Any]:
    """STEP 2. 7-Gate Verifier(GPT) + Solver Agent(GPT, 정답라벨 제거)."""
    # ─ 7-Gate Verifier
    verifier_user = VERIFIER_USER.format(
        item=_as_str(item_result),
        ssot=_as_str(ssot),
        blueprint=_as_str(blueprint),
        item_spec=_as_str(item_spec),
    )
    gate_response = call_openai(VERIFIER_SYSTEM, verifier_user)
    gate_report_raw = extract_json(gate_response)
    gate_report = gate_report_raw.get("gate_report", gate_report_raw)

    # ─ Solver Agent — 정답 라벨 제거 후 풀이
    item_no_answer = json.loads(json.dumps(item_result))  # deep copy
    inner = item_no_answer.get("item", item_no_answer)
    inner.pop("answer_key", None)

    solver_user = SOLVER_USER.format(item_without_answer=_as_str(item_no_answer))
    solver_response = call_openai(SOLVER_SYSTEM, solver_user)
    solver_result = extract_json(solver_response)

    return {"gate_report": gate_report, "solver_result": solver_result}


def step3_answer_package(item_result: dict, ssot: dict) -> Dict[str, Any]:
    """STEP 3. 모범답안 패키지(Claude) — student + faculty 분리."""
    user = ANSWER_PACKAGE_USER.format(
        item=_as_str(item_result),
        ssot=_as_str(ssot),
    )
    response = call_anthropic(ANSWER_PACKAGE_SYSTEM, user, max_tokens=6000)
    return extract_json(response)


def step4_handle_appeal(item_result: dict, answer_package: dict,
                        appeal_text: str, ssot: dict) -> Dict[str, Any]:
    """STEP 4. 이의제기 대응(Claude) — 분류 → SSOT 대조 → 판정 → 보고서."""
    user = APPEALS_USER.format(
        item=_as_str(item_result),
        answer_package=_as_str(answer_package),
        appeal_text=appeal_text,
        ssot=_as_str(ssot),
    )
    response = call_anthropic(APPEALS_SYSTEM, user, max_tokens=6000)
    return extract_json(response)


# ═══════════════════════════════════════════════════════════════════
# 저장 / Markdown 렌더
# ═══════════════════════════════════════════════════════════════════

def save_json(obj: dict, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def save_text(text: str, path: str) -> None:
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def render_exam_markdown(item_result: dict, answer_package: dict) -> str:
    """문항 + 모범답안 → 인쇄용 Markdown."""
    it = item_result.get("item", item_result)
    pkg = answer_package.get("model_answer_package", answer_package)
    sf = pkg.get("student_facing_explanation", {})

    options_md = "\n".join(
        f"- **{o['label']}.** {o['text']}" for o in it.get("options", [])
    )
    why_not_md = "\n".join(
        f"- **{w['option']}**: {w.get('explanation', '')}"
        for w in sf.get("why_not_others", [])
    )
    meta = it.get("metadata", {})

    return f"""# 문항 {it.get('item_id', 'UNKNOWN')}

> **Bloom**: {meta.get('bloom_level', '?')} / **학년**: {meta.get('year_level', '?')} / **임상과제**: {meta.get('clinical_task', '?')}
> **학습목표**: {', '.join(meta.get('learning_objective_ids', []))}

## 문제

{it.get('stem', '')}

{options_md}

---

## 정답: **{it.get('answer_key', '?')}**

### 정답 해설

{sf.get('correct_answer_explanation', '')}

### 오답 해설

{why_not_md}

### Take-home message

> {sf.get('take_home_message', '')}
"""


def render_appeal_markdown(appeal_result: dict) -> str:
    """이의제기 결과 → 인쇄용 Markdown."""
    ap = appeal_result.get("appeal", appeal_result)
    classification = ap.get("classification", {})
    decision = ap.get("decision", {})

    return f"""# 이의제기 심사 보고서 (AI 초안)

> ⚠️ 본 보고서는 AI 권고안입니다. **최종 판정은 평가위원회 의결**입니다.

## 분류

- **유형**: {classification.get('appeal_type', '?')}
- **주장 정답**: {', '.join(classification.get('claimed_correct_options', []))}
- **심각도**: {classification.get('severity', '?')}

## 학생 이의제기 원문

> {ap.get('submission_text', '(원문 누락)')}

## 판정: **{decision.get('outcome', '?').upper()}**

### 근거

{decision.get('rationale', '')}

| 항목 | 결정 |
|---|---|
| 정답 변경 | {decision.get('answer_key_status', '?')} |
| 점수 조정 | {decision.get('score_adjustment', '?')} |
| 문항 수정 필요 | {decision.get('need_item_revision', False)} |

## 학생 공식 안내문 초안

{ap.get('student_facing_response', '(누락)')}

---

**인간 검토 필수**: {ap.get('human_review_required', True)}
**사유**: {ap.get('human_review_reason', '')}
"""
