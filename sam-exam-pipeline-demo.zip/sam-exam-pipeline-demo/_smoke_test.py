"""Smoke test — module imports + asset file accessibility (no API call)."""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))

# 1. Prompts import (no external deps)
import prompts  # noqa: E402
assert prompts.GENERATOR_SYSTEM
assert prompts.VERIFIER_USER
assert prompts.SOLVER_SYSTEM
assert prompts.ANSWER_PACKAGE_USER
assert prompts.APPEALS_SYSTEM
print("[OK] prompts.py — 5종 system/user prompt 로드")

# 2. pipeline_steps module-level import (anthropic/openai는 함수 내부 import이므로 OK)
import pipeline_steps  # noqa: E402
assert callable(pipeline_steps.step1_generate_item)
assert callable(pipeline_steps.step2_verify_with_solver)
assert callable(pipeline_steps.step3_answer_package)
assert callable(pipeline_steps.step4_handle_appeal)
assert callable(pipeline_steps.render_exam_markdown)
print("[OK] pipeline_steps.py — 5단계 함수 + 렌더 헬퍼 import")

# 3. JSON 자산 로드 (노트북 Cell 4-5가 하는 일)
with open("ssot/ssot_package.json", encoding="utf-8") as f:
    ssot = json.load(f)
print(f"[OK] ssot/ssot_package.json — package_id={ssot['ssot_package']['package_id']}, "
      f"layers={len(ssot['ssot_package']['layers'])}")

for spec_file in ["specs/blueprint.json", "specs/item_spec.json", "specs/difficulty_spec.json"]:
    with open(spec_file, encoding="utf-8") as f:
        data = json.load(f)
    print(f"[OK] {spec_file} — top keys: {list(data.keys())}")

# 4. Render 함수 dry-run (저장된 outputs/01 + outputs/03 사용)
with open("outputs/01_generated_item.json", encoding="utf-8") as f:
    item = json.load(f)
with open("outputs/03_model_answer_package.json", encoding="utf-8") as f:
    pkg = json.load(f)
with open("outputs/04_appeal_decision.json", encoding="utf-8") as f:
    appeal = json.load(f)

exam_md = pipeline_steps.render_exam_markdown(item, pkg)
appeal_md = pipeline_steps.render_appeal_markdown(appeal)
assert "정답" in exam_md and "오답 해설" in exam_md
assert "이의제기 심사 보고서" in appeal_md and "REJECT" in appeal_md.upper()
print(f"[OK] render_exam_markdown — {len(exam_md)} chars")
print(f"[OK] render_appeal_markdown — {len(appeal_md)} chars")

# 5. extract_json 함수
sample = '```json\n{"a": 1, "b": [2, 3]}\n```'
parsed = pipeline_steps.extract_json(sample)
assert parsed == {"a": 1, "b": [2, 3]}
print("[OK] extract_json — code block 추출")

print("\nALL SMOKE TESTS PASSED")
