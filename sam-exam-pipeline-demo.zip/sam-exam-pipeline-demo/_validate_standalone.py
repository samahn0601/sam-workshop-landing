"""Validate workshop_standalone.ipynb — all 13 cells parse + assets embed properly."""
import ast
import json

nb = json.load(open("workshop_standalone.ipynb", encoding="utf-8"))
print(f"cells={len(nb['cells'])}, nbformat={nb['nbformat']}.{nb['nbformat_minor']}")

errors = []
for i, c in enumerate(nb["cells"]):
    src = c["source"] if isinstance(c["source"], str) else "".join(c["source"])
    print(f"  [{i+1:2d}] {c['cell_type']:8s} ({len(src):6,d} chars)")
    if c["cell_type"] == "code":
        clean = "\n".join(L for L in src.split("\n") if not L.lstrip().startswith(("!", "%")))
        try:
            ast.parse(clean)
        except SyntaxError as e:
            errors.append(f"cell {i+1}: line {e.lineno}: {e.msg}")
            # show offending line
            lines = clean.split("\n")
            if e.lineno and e.lineno <= len(lines):
                errors.append(f"    > {lines[e.lineno-1][:100]}")

print()
if errors:
    print("SYNTAX ERRORS:")
    for err in errors:
        print(f"  {err}")
else:
    print("All code cells parse OK")

# Spot-check: SSOT, BLUEPRINT, etc. assignments exist?
all_src = "\n".join(
    (c["source"] if isinstance(c["source"], str) else "".join(c["source"]))
    for c in nb["cells"]
)
for name in ["SSOT = json.loads", "BLUEPRINT = json.loads", "ITEM_SPEC = json.loads",
             "DIFFICULTY_SPEC = json.loads", "GENERATOR_SYSTEM", "VERIFIER_SYSTEM",
             "SOLVER_SYSTEM", "ANSWER_PACKAGE_SYSTEM", "APPEALS_SYSTEM",
             "def call_claude", "def step1_generate_item", "def step2_verify_with_solver",
             "def step3_answer_package", "def step4_handle_appeal",
             "GENERATOR_MODEL", "CRITIC_MODEL", "ANSWER_MODEL"]:
    if name not in all_src:
        print(f"  ❌ MISSING: {name}")
    else:
        print(f"  ✅ Found:   {name}")
