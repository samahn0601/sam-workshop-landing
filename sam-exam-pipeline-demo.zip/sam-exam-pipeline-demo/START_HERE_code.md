# 시작하기 — Code 탭 (가장 쉬움) ⭐

> Claude Desktop 앱의 **Code 탭**에서 이 폴더를 열고 **프롬프트 한 번**이면 끝.
> 프로젝트 생성·파일 업로드 불필요 — Code 탭이 작업 폴더의 파일을 직접 읽습니다. (워크숍 메인 흐름과 동일)

## 2단계

1. **Claude Desktop → Code 탭 → 폴더 선택(Select folder)** 으로 이 폴더(`sam-exam-pipeline-demo`)를 엽니다.
2. 아래 프롬프트를 붙여넣습니다:

```
이 작업 폴더의 자료로 'AI 시험 출제 5단계'를 진행해줘.
- 역할 정의: claude_desktop_bundle/02_project_instructions.md 를 읽어 5개 역할(Generator·Verifier·Solver·Answer·Appeals)을 파악
- 근거(SSOT·스펙): claude_desktop_bundle/project_files/ 의 ssot.md, blueprint.md, item_spec.md, difficulty_spec.md

순서대로 진행:
STEP 1 문항 생성 (흉통 ACS vs PE, M3, Bloom=analyze, 음성 소견(호흡곤란 없음·SpO2 정상·하지 부종 없음)을 stem에 명시)
STEP 2 7-Gate 검증 (Gate 4 '단일 정답'을 적극적으로 의심)
STEP 3 Solver — 정답 라벨을 잊고 학생처럼 풀어 각 보기 0~1 점수 + top2_gap
STEP 4 모범답안 패키지 (학생용 + 교수용)
STEP 5 이의제기 처리 ("B(폐색전증)와 C(ACS) 둘 다 정답" 주장)

각 단계 결과를 outputs_new/ 폴더에 JSON으로 저장하고, 마지막에 5단계 요약 표(Pass/Fail/Risk/Outcome)를 보여줘.
```

→ Claude가 폴더 파일을 읽고 5단계를 실행하며 `outputs_new/`에 저장합니다. 사전 생성된 참고 산출물은 `outputs/`에 있습니다(망이 느릴 때 바로 보여주기 용).

## 자기 강의노트로 교체
`claude_desktop_bundle/project_files/ssot.md`만 본인 강의 내용으로 바꾸면 같은 흐름이 다른 주제(복통·두통·발열 등)에도 그대로 작동합니다.

---

## 💡 Tip — Cowork의 Project 기능도 활용 가능

Code 탭에는 없는 **Project 기능**을 쓰고 싶으면 **Cowork**로 전환(Desktop 앱에서 클릭 한 번):

- Cowork는 **샌드박스**라 더 안전합니다(대신 약간의 기능 제한).
- 이 폴더 자료를 **Project 지식**으로 등록해 여러 대화에서 반복 재사용할 수 있습니다 — 같은 SSOT로 문항을 계속 뽑을 때 편리.
- 설정법은 `claude_desktop_bundle/`의 Project 가이드(`01_setup.md`) 참고.

## 코드를 전혀 안 쓰고 채팅만 원하면 (대안)
`claude_desktop_bundle/01_setup.md`의 Project 방식(프로젝트 생성 → 지침 → 파일 업로드)을 따르세요. 단, **위 Code 탭 방식이 가장 간단**합니다.

## (선택) API 자동화
Colab 노트북 `workshop_standalone.ipynb` — Anthropic API 키 필요(유료). 자동 5단계 chaining이 필요할 때만.
