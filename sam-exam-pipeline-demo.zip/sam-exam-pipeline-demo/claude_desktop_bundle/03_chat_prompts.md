# Chat 프롬프트 — Project 설정 후 chat에 붙여넣기

> Project 지침이 02_project_instructions.md로 설정되어 있고, project_files/의 5개 파일이 업로드되어 있다고 가정.

---

## 모드 선택

| 모드 | 메시지 수 | 시간 | 용도 |
|---|---|---|---|
| **A. One-shot** | 1번 | 3~5분 | 워크숍 시연 (빠른 데모) |
| **B. Step-by-step** | 5번 | 8~12분 | 각 단계 깊이 검토 |

---

## 모드 A: One-shot — 한 번에 5단계 전체

> 새 conversation에서 아래를 통째로 붙여넣기.

```
첨부된 SSOT(ssot.md), Blueprint(blueprint.md), Item Spec(item_spec.md), Difficulty Spec(difficulty_spec.md)을 기반으로 5단계 워크플로우를 모두 진행해주세요.

각 단계 결과를 명확히 구분해서 출력:

== STEP 1: GENERATOR ==
KMLE SBA 5지선다 문항 1개 생성 (주제: 흉통 감별진단, M3, Bloom=analyze, clinical_task=diagnosis).
정답 1개 + 음성 소견(호흡곤란 없음, SpO2 정상, 하지 부종 없음 등)을 stem에 명시.
JSON으로 출력.

== STEP 2: VERIFIER ==
방금 생성한 문항을 7-Gate fail-closed 정책으로 검증.
JSON gate_report로 출력.

== STEP 3: SOLVER ==
방금 생성한 문항의 정답 라벨을 제거하고, 학생 입장에서 정답을 풀어보세요.
각 보기에 0~1 점수 매기고 top2_gap 계산.
JSON으로 출력.

== STEP 4: ANSWER PACKAGE ==
학생용(짧고 명확) + 교수용(상세 reasoning) 모범답안 패키지 작성.
appeal_risk와 preemptive_response 포함.
JSON으로 출력.

== STEP 5: APPEALS ==
다음 가상의 학생 이의제기를 처리해주세요:

"폐색전증도 급성 흉통의 중요한 감별진단입니다. 환자가 50대 후반 남성이고 흡연력이 있어 PE 위험인자에도 해당합니다. 따라서 B(폐색전증)와 C(급성 관상동맥증후군) 둘 다 정답으로 인정되어야 합니다."

분류 → SSOT 대조 → 판정 → 학생 안내문 초안까지 모두 JSON으로 출력.

마지막에 5단계 요약 표(Pass/Fail/Risk Level/Outcome)를 Markdown으로.
```

> 응답 길이 ~10~15K characters. 워크숍에서 빠르게 보여줄 때 사용.

---

## 모드 B: Step-by-step — 5번에 나눠서

### Step 1: 문항 생성

```
STEP 1: GENERATOR 역할로 작동해주세요.

첨부된 SSOT(ssot.md), Blueprint(blueprint.md), Item Spec(item_spec.md), Difficulty Spec(difficulty_spec.md)을 기반으로 KMLE 스타일 SBA 5지선다 문항 1개를 작성하세요.

요구사항:
- 주제: 흉통 감별진단 (ACS vs PE)
- 학년: M3
- Bloom: analyze
- 임상과제: diagnosis
- 정답 1개 + 음성 소견(호흡곤란 없음, SpO2 정상, 하지 부종 없음)을 stem에 명시
- 모든 핵심 claim에 evidence_id 매핑 (LN-ACS-01, LN-PE-01, GL-ACS-01 등)

JSON으로 출력하세요. item_id는 "CP-ACS-001"로.
```

---

### Step 2: 7-Gate 검증

```
STEP 2: VERIFIER 역할로 작동해주세요.

방금 생성한 문항(CP-ACS-001)을 7-Gate fail-closed 정책으로 검증하세요.

각 Gate에 대해:
- status: pass | fail | needs_human_review
- comment: 판정 사유
- evidence: SSOT의 evidence_id 또는 구체적 근거

특히 Gate 4 (Single Best Answer)에서는:
- 정답 외 보기 중에 정답이 될 수 있는 것이 있는지 적극적으로 의심
- "가능한 진단"과 "가장 가능성 높은 진단"의 차이를 명확히 구분

JSON gate_report로 출력하세요.
```

---

### Step 3: Solver Agent

```
STEP 3: SOLVER 역할로 작동해주세요.

방금 생성한 문항(CP-ACS-001)에서 정답 라벨을 완전히 잊고, 한국 의대 본과 학생 입장에서 문제를 풀어보세요.

각 보기 A~E에 대해:
- score: 0~1 (정답 가능성)
- rationale: SSOT 단서에 기반한 짧은 근거

마지막에:
- predicted_answer: 가장 높은 점수의 보기
- confidence: 그 보기의 점수
- top2_gap: 1위와 2위 점수 차이

특히 PE(B)와 ACS(C) 사이에서 적극적으로 비교하세요. 이 차이가 작으면 (top2_gap < 0.20) Gate 4 fail입니다.

JSON으로 출력.
```

---

### Step 4: 모범답안 패키지

```
STEP 4: ANSWER PACKAGE 역할로 작동해주세요.

방금 생성·검증한 문항(CP-ACS-001)의 모범답안 패키지를 작성하세요.

요구사항:

학생용(student_facing):
- correct_answer_summary: 한 문장
- correct_answer_explanation: 2~4문장 학생용 해설
- why_not_others: 각 오답 A·B·D·E에 대한 짧은 배제 사유
- take_home_message: 학습 요점 한 문장

교수용(faculty_facing):
- clinical_reasoning: problem_representation + key_positive_findings + key_negative_findings + diagnostic_steps (evidence_id 매핑 필수)
- differential_diagnosis_table: 5개 보기 모두에 대한 DDx 분석 (most_likely/less_likely/unlikely)
- citations: SSOT 인용 (source_id + quoted_text)
- appeal_risk: 예상 이의제기 위험도와 preemptive_response

JSON으로 출력.
```

---

### Step 5: 이의제기 자동 처리

```
STEP 5: APPEALS 역할로 작동해주세요.

가상의 학생 이의제기가 접수되었습니다:

"폐색전증도 급성 흉통의 중요한 감별진단입니다. 환자가 50대 후반 남성이고 흡연력이 있어 PE 위험인자에도 해당합니다. 따라서 B(폐색전증)와 C(급성 관상동맥증후군) 둘 다 정답으로 인정되어야 합니다."

다음 4단계를 모두 진행:
(a) 이의 요지 분류 (appeal_type, claimed_correct_options, severity)
(b) SSOT 대조 (B와 C 각각에 대한 supporting_features_in_stem vs missing_or_arguing_against_features, ssot_evidence quoted_text까지)
(c) 수용/기각/재검토 판단 (decision.outcome + rationale)
(d) 학생 공식 안내문 초안 (student_facing_response — 정중·학술적 톤, 학습 경로 피드백 포함)

JSON으로 출력. 마지막에 human_review_required 명시.
```

---

## 자기 강의노트로 교체 시 (워크숍 후)

1. **Project 파일 ssot.md를 본인 강의 내용으로 교체** (형식만 유지)
2. **Project 파일 blueprint.md의 learning_objective_ids를 본인 LO ID로 교체**
3. Project 새 대화 열기
4. 위의 모드 A (one-shot) 또는 모드 B (step-by-step) 그대로 사용

## Pro tip

- Claude Desktop에서는 응답에서 ```json 블록을 클릭 → "Copy"로 즉시 복사 가능
- 결과를 로컬에 저장하려면 응답 우상단 "..." 메뉴 → "Export" 또는 직접 복사
- Project에 등록된 파일은 모든 대화에서 자동 참조됨 → 매번 첨부 불필요
