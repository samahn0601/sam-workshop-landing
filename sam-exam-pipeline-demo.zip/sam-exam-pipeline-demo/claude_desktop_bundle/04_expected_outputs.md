# 예상 출력 샘플 — 참가자 비교용

> 5단계 각각에서 받게 될 출력의 예시. 본인 출력과 비교해서 7-Gate가 제대로 작동했는지, 모범답안 형식이 맞는지 확인.

> 본 예시는 사전에 3AI consult로 합의된 reference deliverable. 실제 Claude Desktop 출력은 변동 가능.

---

## STEP 1 예상 출력 — 생성된 문항

```json
{
  "item": {
    "item_id": "CP-ACS-001",
    "stem": "58세 남자가 30분 전부터 발생한 흉통으로 응급실에 왔다. 통증은 흉골 뒤쪽의 압박감으로 시작되어 왼쪽 팔로 방사된다. 식은땀과 오심을 동반한다. 과거력으로 고혈압과 제2형 당뇨병이 있고 30갑년의 흡연력이 있다. 활력징후는 혈압 150/90 mmHg, 맥박 96회/분, 호흡수 18회/분, 산소포화도 98%(실내공기)이다. 호흡곤란은 호소하지 않고, 양측 폐음은 깨끗하며, 하지 부종이나 압통은 없다. 12-lead 심전도에서 명확한 ST 분절 변화는 관찰되지 않았다. 이 환자에서 가장 가능성이 높은 진단은?",
    "options": [
      {"label": "A", "text": "위식도역류질환"},
      {"label": "B", "text": "폐색전증"},
      {"label": "C", "text": "급성 관상동맥증후군"},
      {"label": "D", "text": "늑연골염"},
      {"label": "E", "text": "공황발작"}
    ],
    "answer_key": "C",
    "metadata": {
      "learning_objective_ids": ["CP-01", "CP-02", "CP-03"],
      "bloom_level": "analyze",
      "year_level": "M3",
      "clinical_task": "diagnosis"
    },
    "evidence_links": [
      {
        "claim": "흉골하 압박감 + 좌측 팔 방사통 + 발한 + HTN/DM/흡연 → ACS 가능성 높음",
        "evidence_ids": ["LN-ACS-01", "TB-ACS-MECH"]
      },
      {
        "claim": "호흡곤란 없음 + SpO2 정상 + 하지 부종/압통 없음 → PE 가능성 낮음",
        "evidence_ids": ["LN-PE-01", "TB-PE-MECH"]
      }
    ]
  }
}
```

**체크리스트**:
- [ ] 음성 소견 3건 이상 stem에 포함 (호흡곤란 없음, SpO2 정상, 하지 부종 없음)
- [ ] 모든 보기가 진단명 카테고리
- [ ] evidence_links에 LN-* 또는 GL-* 매핑 1개 이상

---

## STEP 2 예상 출력 — 7-Gate 리포트

```json
{
  "gate_report": {
    "item_id": "CP-ACS-001",
    "overall_status": "pass",
    "gates": [
      {"gate": 1, "name": "Scope Gate", "status": "pass",
       "comment": "CP-01·CP-02·CP-03에 매핑. M3 적합."},
      {"gate": 2, "name": "Source Gate", "status": "pass",
       "comment": "모든 핵심 claim에 L2 또는 L3 citation 매핑."},
      {"gate": 3, "name": "Medical Accuracy Gate", "status": "pass",
       "comment": "L2 강의노트와 L4 가이드라인 충돌 없음."},
      {"gate": 4, "name": "Single Best Answer Gate", "status": "pass",
       "comment": "PE 시사 단서 6건 모두 음성으로 명시되어 B 가능성 낮춤."},
      {"gate": 5, "name": "Item-Writing Gate", "status": "pass",
       "comment": "옵션 균질·길이 균일·금지표현 없음."},
      {"gate": 6, "name": "Difficulty & Blueprint Gate", "status": "pass",
       "comment": "Bloom=analyze, M3, diagnosis 3축 일치."},
      {"gate": 7, "name": "Appeal-Readiness Gate", "status": "pass",
       "comment": "PE 배제 근거 명시. 이의제기 대응 가능."}
    ]
  }
}
```

**체크리스트**:
- [ ] 7개 Gate 모두 status 명시
- [ ] overall_status: pass / fail / needs_human_review 중 하나

> **워크숍 시연 포인트**: Gate 4가 일부러 fail되는 변형도 시연 가능. 음성 소견을 stem에서 제거하고 다시 검증하면 B 점수가 0.32까지 올라가 Gate 4 fail이 발생. 그 후 음성 소견을 추가하면 통과.

---

## STEP 3 예상 출력 — Solver Agent

```json
{
  "predicted_answer": "C",
  "confidence": 0.91,
  "option_scores": [
    {"option": "A", "score": 0.05, "rationale": "GERD는 작열감·식후 악화 패턴, 본 증례와 불일치"},
    {"option": "B", "score": 0.12, "rationale": "PE는 호흡곤란·저산소·DVT 단서 모두 음성으로 명시되어 가능성 낮음"},
    {"option": "C", "score": 0.91, "rationale": "전형적 허혈성 양상 + HTN·DM·30갑년 흡연 → ACS 강력 시사"},
    {"option": "D", "score": 0.03, "rationale": "국소 압통·체위 의존 없음"},
    {"option": "E", "score": 0.04, "rationale": "심혈관 위험인자 고위험군, 배제 진단 조건 미충족"}
  ],
  "top2_gap": 0.79
}
```

**체크리스트**:
- [ ] predicted_answer == STEP 1의 answer_key (정답 일치)
- [ ] top2_gap >= 0.20 (단일정답 임계 통과)

---

## STEP 4 예상 출력 — 모범답안 패키지 (요약)

학생용 핵심:
- 정답 C 해설: 흉골하 압박감 + 좌측 팔 방사 + 발한 + HTN/DM/흡연 → ACS
- 오답 해설: A·B·D·E 각각의 배제 사유
- Take-home: 5대 생명위협 우선 감별, 음성 소견으로 PE 배제

교수용 핵심:
- problem_representation: 심혈관 위험인자 3개를 가진 58세 남자의 급성 흉골하 압박성 흉통
- diagnostic_steps: 5단계 reasoning (각 단계 evidence_id 매핑)
- differential_diagnosis_table: ACS=most_likely, PE=unlikely, 그 외 unlikely
- appeal_risk: **moderate** — "B 폐색전증도 정답" 주장 가능성 사전 식별

**체크리스트**:
- [ ] student_facing + faculty_facing 분리
- [ ] appeal_risk에 possible_appeal_arguments 1개 이상
- [ ] preemptive_response가 있음

---

## STEP 5 예상 출력 — 이의제기 보고서

```json
{
  "appeal": {
    "appeal_id": "AP-CP-ACS-001-001",
    "classification": {
      "appeal_type": "multiple_correct_answers",
      "claimed_correct_options": ["B", "C"],
      "severity": "high"
    },
    "ssot_comparison": {
      "claimed_option_analysis": [
        {
          "option": "B",
          "supporting_features_in_stem": ["acute chest pain", "흡연력"],
          "missing_or_arguing_against_features": [
            "호흡곤란 없음", "SpO2 98% (저산소증 부재)",
            "호흡수 정상", "하지 부종/압통 없음", "강한 DVT 위험인자 부재"
          ],
          "ssot_evidence": [
            {"source_id": "LN-PE-01",
             "quote": "갑작스러운 호흡곤란(가장 흔한 증상), 흉막성 흉통, 빈호흡, 빈맥, 저산소증, 객혈이 동반될 수 있다. DVT 위험인자가 강하게 시사한다."}
          ],
          "assessment": "possible_but_unlikely",
          "correctness_score": 0.12
        }
      ]
    },
    "decision": {
      "outcome": "reject",
      "rationale": "본 문항은 single best answer 단일최선답형. PE는 가능한 감별진단이지만 본 증례에는 PE 시사 핵심 단서 6건이 모두 음성으로 명시되어 있으므로 '가장 가능성 높은 진단'이 될 수 없음.",
      "answer_key_status": "maintain_C",
      "score_adjustment": "none",
      "need_item_revision": false
    },
    "student_facing_response": "본 문항에 대해 학구적 열의를 가지고 이의를 제기해 주신 학생께 감사드립니다. 폐색전증(B)도 급성 흉통의 중요한 감별진단이며 임상 현장에서 ACS와 함께 고려해야 합니다. 다만 본 문항은 '가장 가능성이 높은 진단'을 묻는 단일최선답형(single best answer) 문항입니다. 본 증례에는 PE를 강하게 시사하는 단서(호흡곤란, 저산소증, 빈호흡, 하지 부종/압통)가 명시적으로 부재합니다. 따라서 SBA 원칙과 강의노트(p.45-47), ACC/AHA 2021 Chest Pain Guideline에 의거하여 정답 C(급성 관상동맥증후군)를 단독으로 유지합니다. 끝까지 학업에 매진하여 주시기 바랍니다.",
    "human_review_required": true,
    "human_review_reason": "AI는 recommendation까지. 최종 판정은 평가위원회 의결 필요."
  }
}
```

**체크리스트**:
- [ ] classification → ssot_comparison → decision → student_facing_response 4단계 모두 출력
- [ ] decision.outcome: reject (이 시나리오에서)
- [ ] student_facing_response 톤이 정중·학술적
- [ ] human_review_required: true 명시

---

## 자가 검증 5분 체크리스트

워크숍 직전 또는 본인 강의노트 교체 후:

- [ ] STEP 1: stem에 음성 소견 3건 이상
- [ ] STEP 2: 7개 Gate 모두 명시, overall_status 명확
- [ ] STEP 3: predicted_answer == answer_key, top2_gap >= 0.20
- [ ] STEP 4: student/faculty 분리, appeal_risk 포함
- [ ] STEP 5: classification → comparison → decision → student response 흐름 + human_review_required: true

위 5개 모두 ✓면 데모 준비 완료.
