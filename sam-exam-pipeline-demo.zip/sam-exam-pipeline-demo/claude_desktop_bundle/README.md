# Claude Desktop 워크숍 보너스 트랙 — 시험 출제 파이프라인

> 의대 교수 워크숍(D-2026-06-20) 보너스 트랙 — **구독 세션으로 작동, API 비용 0원**.
> Claude Desktop 앱(macOS/Windows) 또는 claude.ai 웹에서 동일하게 작동.
>
> ⚠️ **의도적 Project(Cowork/Chat) 기반 — Code 탭 전환 대상 아님** (Sam 확정 2026-06-10).
> 사유: 시험문항 데모는 project_files 묶음을 Project 지식으로 올려두고 점심 백그라운드에서
> 채팅 1~5번으로 운영하는 형태가 관리에 유리. 본 파이프라인(논문 10-step lifecycle)·통계 데모의
> "Code 탭 통일" 정리에서 이 번들은 제외할 것. (스킬 버전은 별도: exam-item-builder는 Code 탭)

## ⭐ 왜 이 버전인가

| 기존 API 노트북 | **Claude Desktop Project (본 폴더)** |
|---|---|
| Anthropic Console API 키 필요 | **구독 세션 그대로 사용** |
| 호출당 별도 결제 | **추가 비용 0원** |
| Python·노트북 환경 필요 | **앱/웹만 있으면 됨** |
| 자동 chaining 가능 | Chat 1~5번 수동 호출 |

워크숍 참가자(의대 교수) 모두가 Claude 구독자라면 이 방식이 압도적으로 유리. 비용·진입장벽 둘 다 해결.

---

## 5분 빠른 시작

1. **Project 생성** — Claude Desktop → Projects → Create Project
2. **지침 설정** — `02_project_instructions.md` 통째로 붙여넣기
3. **파일 업로드** — `project_files/`의 5개 `.md` 업로드
4. **첫 대화** — `03_chat_prompts.md`의 **모드 A** 프롬프트 chat에 붙여넣기
5. **결과 받기** — 5단계 전체 결과를 한 응답으로 받음

자세한 절차는 [01_setup.md](01_setup.md).

---

## 폴더 구조

```
claude_desktop_bundle/
├── README.md                          ← 본 문서
├── 01_setup.md                        ← Project 설정 단계별 (5분)
├── 02_project_instructions.md         ← Project "지침"에 통째로 붙여넣기
├── 03_chat_prompts.md                 ← Chat 프롬프트 (one-shot 1개 + 단계별 5개)
├── 04_expected_outputs.md             ← 각 단계 예상 출력 (자가 검증용)
└── project_files/                     ← Project "지식"에 업로드할 5개 파일
    ├── ssot.md                        ← 다층 SSOT (L1~L5)
    ├── blueprint.md                   ← 출제 청사진
    ├── item_spec.md                   ← 문항 형식 사양
    ├── difficulty_spec.md             ← 난이도 명세
    └── workshop_context.md            ← 워크숍 배경·7-Gate·함정
```

총 9개 파일, ~50 KB. 이메일/Drive/Slack으로 한 번에 전송 가능.

---

## 두 가지 모드

| 모드 | 메시지 수 | 시간 | 용도 |
|---|---|---|---|
| **A. One-shot** | 1번 | 3~5분 | 워크숍 시연 (압축 데모) |
| **B. Step-by-step** | 5번 | 8~12분 | 각 단계 깊이 검토 |

워크숍 시연은 모드 A로 빠르게, 참가자 따라하기는 모드 B로 천천히. 둘 다 같은 결과.

---

## 5단계 파이프라인

| Step | 역할 | 출력 |
|---|---|---|
| 1️⃣ | **Generator** | KMLE SBA 5지선다 문항 1개 (JSON) |
| 2️⃣ | **7-Gate Verifier** | fail-closed 검증 리포트 (JSON) |
| 3️⃣ | **Solver Agent** | 정답 라벨 제거 후 풀이 (JSON) |
| 4️⃣ | **Answer Package** | 학생용 + 교수용 모범답안 (JSON) |
| 5️⃣ | **Appeals Agent** | "B와 C 둘 다" → REJECT 보고서 (JSON) |

각 단계의 시스템 지침은 `02_project_instructions.md` 안에 모두 정의. Chat 메시지에서 "STEP 1" 등 키워드로 역할 전환.

---

## 자기 강의노트로 교체 (워크숍 후)

1. `project_files/ssot.md`를 **본인 강의 내용으로 교체** (L1~L5 형식 유지)
2. `project_files/blueprint.md`의 `learning_objective_ids`도 본인 LO ID로
3. Project Files에서 기존 파일 삭제 → 수정한 새 파일 업로드
4. Project 새 대화에서 `03_chat_prompts.md`의 프롬프트 그대로 사용

SSOT만 바뀌면 같은 5단계 흐름이 다른 주제(복통·두통·발열 등)에도 그대로 작동.

---

## 배포 방식

### 강사 → 참가자에게 보낼 때

이메일/Drive/Slack에 **`claude_desktop_bundle/` 폴더 통째로 zip 첨부** (50 KB 이내).
참가자는:
1. zip 다운로드 → 압축 해제
2. Claude Desktop 열기
3. `01_setup.md` 따라 5분 만에 Project 구축
4. `03_chat_prompts.md`의 모드 A 프롬프트로 시작

### 또는 — 워크숍 당일 화면 공유로 시연

강사가 본인 Project로 모드 A 시연 → 참가자는 동일 자료로 본인 환경에서 재현.

---

## 7-Gate fail-closed 정책

| # | Gate | fail-closed 조건 |
|---|---|---|
| 1 | Scope | 학습목표 미매핑 |
| 2 | Source | uncited claim 존재 |
| 3 | Medical Accuracy | SSOT contradiction |
| 4 | **Single Best Answer** | **Solver mismatch OR top2_gap < 0.20** |
| 5 | Item-Writing | 금지 표현·옵션 비균질 |
| 6 | Difficulty & Blueprint | 3축 불일치 |
| 7 | Appeal-Readiness | 정답·오답 근거 누락 |

> **STOP rules**: G3·G4·G7 fail은 자동 통과 절대 금지 → `needs_human_review`.

---

## 워크숍 데모 흐름 (40분)

| 시간 | 내용 |
|------|------|
| 0~5 | 패러다임 전환: AI가 출제 ≠ 워크플로우를 AI가 강화 |
| 5~10 | Claude Desktop 열기 + Project 생성 시연 (참가자도 함께) |
| 10~25 | 강사 데모: 모드 A 한 번에 5단계 → 결과 함께 읽기 |
| 25~35 | 참가자 따라하기: 같은 Project에서 모드 A 실행 또는 모드 B 1~2개 단계 |
| 35~40 | Q&A + 사후 사용 + 자기 강의노트 교체 안내 |

---

## ⚠️ 보안 가이드

- ✅ Project 파일에 공개해도 되는 강의 자료만
- ❌ 학생 개인정보 / 미공개 출제 예정 문항 절대 업로드 금지
- ✅ 워크숍 종료 후 Project 삭제 또는 archive
- ✅ 실제 시험 투입 전 평가위원회 승인 필수
- ⚠️ 본 구성은 데모용. 보안 모드는 학내 Sam AI v1.3 파이프라인 사용

---

## 다른 옵션 (선택)

상위 폴더 `bonus_track/exam_pipeline_demo/`에 있는 두 노트북은 **API 자동화가 필요할 때만**:

| 파일 | 의존성 | 차이 |
|---|---|---|
| `workshop_standalone.ipynb` | Anthropic API 키 (**별도 결제**) | 5단계 자동 chaining |
| `workshop.ipynb` | Anthropic + OpenAI 키 2개 | + multi-model 분리 |

기본 배포 default는 본 `claude_desktop_bundle/`. 노트북은 고급 사용자용.

---

## 설계 근거

- [3AI Consult 합의안](../../.claude/skills/3ai-consult/outputs/3ai-consult_20260521-1850_exam-workflow-pipeline.md) — Claude + Gemini + GPT 3AI 교차 검증
- NBME Item Writing Guide
- Haladyna MCQ item-writing guidelines
- ACC/AHA 2021 Chest Pain Guideline (SSOT L4)
- Harrison's Principles of Internal Medicine 21e (SSOT L3)

## 시작 시점

2026-05-21. D-30(2026-06-15 dry-run) 일정에 맞춰 단계별 검증.
