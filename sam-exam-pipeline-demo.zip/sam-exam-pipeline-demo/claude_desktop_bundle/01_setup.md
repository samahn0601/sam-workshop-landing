# Claude Desktop Project 설정 — 단계별 가이드 (5분)

> Claude Desktop 앱 또는 claude.ai 웹에서 동일하게 작동.

## 사전 준비

- ✅ Claude Pro / Team / Max 구독
- ✅ Claude Desktop 앱 설치 ([claude.ai/download](https://claude.ai/download)) 또는 claude.ai 웹 접속
- ✅ 본 폴더(`claude_desktop_bundle/`)의 파일들이 로컬에 있음

> ❌ Anthropic Console API 키 **불필요** (구독 세션으로 작동)

---

## Step 1: Project 생성 (1분)

### Claude Desktop 앱

1. Claude Desktop 앱 실행
2. 왼쪽 사이드바 **"Projects"** 클릭
3. **"+ Create Project"** 버튼 클릭
4. 이름: `AI 시험 출제 데모 — 흉통 감별`
5. 설명(선택): "워크숍 보너스 트랙 데모. SSOT 다층 + 7-Gate + 모범답안 + 이의제기."
6. **"Create Project"** 클릭

### claude.ai 웹 (동일)

1. [claude.ai](https://claude.ai) 로그인
2. 왼쪽 사이드바 **"Projects"** 클릭
3. **"+ Create Project"** → 위와 동일

---

## Step 2: Project 지침 설정 (1분)

1. 생성한 Project 안에서 우측 사이드바의 **"Set custom instructions"** 또는 **"Instructions"** 영역 찾기
2. `02_project_instructions.md` 파일을 텍스트 에디터로 열고, **첫 줄(`# Project 지침...`)부터 끝까지 전체 선택 후 복사**
3. Claude Desktop의 instructions 영역에 **그대로 붙여넣기**
4. **"Save"** 또는 자동 저장 대기

> Project 지침은 5가지 역할(Generator/Verifier/Solver/Answer Package/Appeals)을 모두 정의합니다. chat에서 STEP 번호 또는 키워드로 역할 전환.

---

## Step 3: Project 파일(지식) 업로드 (2분)

1. Project 안에서 **"Add knowledge"** 또는 **"Project knowledge"** 또는 **"Files"** 영역 찾기
2. **"Upload files"** 또는 드래그앤드롭으로 다음 5개 파일을 모두 업로드:

| 파일 | 역할 |
|---|---|
| `project_files/ssot.md` | 다층 SSOT (강의노트·교과서·진료지침·학습목표·vignette seed) |
| `project_files/blueprint.md` | 출제 청사진 |
| `project_files/item_spec.md` | 문항 형식 사양 |
| `project_files/difficulty_spec.md` | 난이도 명세 |
| `project_files/workshop_context.md` | 워크숍 배경·7-Gate·함정 |

3. 업로드 완료 확인 (5개 파일 모두 보임)

> ⚠️ Project 파일에는 **공개해도 되는 강의 자료만**. 학생 개인정보·실제 출제 예정 문항·미공개 진료 데이터 업로드 금지.

---

## Step 4: 첫 대화 시작 (1분)

1. Project 안에서 **"Start chat"** 또는 메시지 입력창 클릭
2. `03_chat_prompts.md` 열기
3. **모드 A (One-shot, 추천)**: "모드 A" 섹션의 프롬프트 전체를 복사해서 chat에 붙여넣기
4. 또는 **모드 B (Step-by-step)**: 5개 STEP 프롬프트를 차례로 사용

> 첫 응답까지 30초~2분. 응답 길이 ~10K characters (one-shot 모드).

---

## Step 5: 결과 활용

### 응답 복사
- 응답 내 ```json 블록 우상단의 **"Copy"** 버튼 클릭
- 또는 응답 전체 우상단 **"..."** 메뉴 → **"Copy as Markdown"**

### 로컬 저장
- 응답을 `.md` 또는 `.json` 파일로 직접 복사 저장
- 또는 Claude Desktop **"Export conversation"** 기능 사용

### docx 변환
응답 Markdown을 `.docx`로:
```bash
pandoc exam.md -o exam.docx
```
(pandoc 미설치 시: `brew install pandoc` 또는 `winget install pandoc`)

---

## 자기 강의노트로 교체 (워크숍 후)

1. `project_files/ssot.md`를 **본인 강의 내용으로 교체** (L1~L5 형식 유지)
2. `project_files/blueprint.md`의 `learning_objective_ids`도 본인 LO ID로
3. Project Files에서 기존 파일 삭제 → 수정한 새 파일 업로드
4. Project 새 대화에서 `03_chat_prompts.md`의 프롬프트 그대로 사용

> SSOT만 바뀌면 같은 5단계 흐름이 다른 주제(복통·두통·발열 등)에도 그대로 작동.

---

## 자주 발생하는 문제

### "Project instructions가 너무 길다"고 거부됨
- Claude Desktop 일부 버전에서 instructions에 글자수 제한이 있음
- 해결: `02_project_instructions.md`의 5개 역할 중 1~2개만 남기고 나머지는 첫 메시지에서 컨텍스트로 전달

### Project 파일 업로드가 안 됨
- 한 파일 크기 제한 또는 파일 수 제한 (Plan에 따라 다름)
- 해결: 5개 파일을 1개로 합친 `combined_project_files.md` 만들어 업로드 (워크숍 강사가 사전 준비)

### 응답이 JSON 형식을 안 따름
- Claude가 가끔 JSON 대신 Markdown으로 응답
- 해결: 메시지 끝에 "반드시 ```json ... ``` 블록으로만 출력" 명시

### 응답이 SSOT 범위를 벗어남
- Generator가 SSOT에 없는 사실을 만들어냄
- 해결: STEP 2의 7-Gate Verifier가 잡아냄 (Gate 2 Source / Gate 3 Medical Accuracy). 그 후 STEP 1 재실행 요청.

---

## 보안 가이드

- ✅ 워크숍 종료 후 Project를 **삭제하거나 archive** (학생 데이터 우려 시)
- ✅ Project 파일에 실제 학생 정보·미공개 시험 문제 업로드 절대 금지
- ✅ 생성된 문항은 본인 분야 정확성 검토 후 사용
- ✅ 실제 시험 투입 전 평가위원회 승인 필수
- ⚠️ 본 구성은 데모용. 보안 모드는 학내 Sam AI v1.3 파이프라인 사용

---

## 5분 체크리스트

- [ ] Project 생성됨
- [ ] Instructions에 `02_project_instructions.md` 전체 붙여넣기
- [ ] Project 파일 5개 모두 업로드
- [ ] 모드 A 또는 모드 B 첫 메시지 전송 → 응답 받음
- [ ] STEP 1 출력(생성된 문항)에 음성 소견 3건 이상 포함 확인
- [ ] STEP 5 출력에 `human_review_required: true` 포함 확인

위 6개 모두 ✓면 워크숍 데모 준비 완료.
