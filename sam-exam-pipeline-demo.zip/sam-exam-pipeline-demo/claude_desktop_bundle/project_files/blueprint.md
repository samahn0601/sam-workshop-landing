# Blueprint — 출제 청사진

> Project가 문항을 생성할 때 참고할 시험 설계 명세.

## 시험 메타데이터

| 항목 | 값 |
|---|---|
| `exam_id` | Demo_ChestPain_2026 |
| `course` | 임상의학입문 / 순환기학 통합과정 |
| `target_grade` | M3 (본과 3학년) |
| `total_items` | 1 (데모) |
| `ssot_package_id` | ChestPain_SSOT_2026_v1 |

## 출제 도메인

| 영역 | 학습목표 | 문항 수 | Bloom | 임상과제 |
|---|---|---|---|---|
| 흉통 감별진단 | **CP-01, CP-02, CP-03** | 1 | analyze | diagnosis |

## 안전 제약 (의대 워크숍 데모용)

| 항목 | 정책 |
|---|---|
| 약물 용량 문항 | **회피** (검증 부담 큼) |
| 소아 관련 문항 | 회피 |
| 임신부 관련 문항 | 회피 |
| 고위험 claim | fail-closed → 인간 검토 |

## JSON 형태 (참고용)

```json
{
  "blueprint": {
    "exam_id": "Demo_ChestPain_2026",
    "course": "임상의학입문 / 순환기학 통합과정",
    "target_grade": "M3",
    "total_items": 1,
    "ssot_package_id": "ChestPain_SSOT_2026_v1",
    "domains": [
      {
        "domain": "Chest pain differential diagnosis",
        "learning_objective_ids": ["CP-01", "CP-02", "CP-03"],
        "item_count": 1,
        "bloom_level": "analyze",
        "year_level": "M3",
        "clinical_task": "diagnosis"
      }
    ],
    "safety_constraints": {
      "avoid_drug_dose_questions": true,
      "avoid_pediatric_questions": true,
      "avoid_pregnancy_questions": true,
      "high_risk_claim_policy": "fail_closed_human_review"
    }
  }
}
```
