# Item Spec — 문항 형식 사양

> Project가 문항을 작성할 때 따라야 할 형식·금지·검증 규칙.

## 기본 형식

| 항목 | 값 |
|---|---|
| `format` | single_best_answer_5_options |
| `language` | ko |
| `exam_style` | Korean Medical Licensing Exam (KMLE) clinical vignette |
| `option_count` | 5 (A, B, C, D, E) |

## Stem (지문) 규칙

| 항목 | 요구사항 |
|---|---|
| 형태 | clinical vignette |
| 나이 | 명시 필수 |
| 성별 | 명시 필수 |
| 주소증 | 명시 필수 |
| 현병력 | 명시 필수 |
| 활력징후 | 권장 |
| 신체검진 | 권장 |
| 검사/영상 | 권장 |
| **음성 소견 (negative findings)** | **감별진단 문항일 때 필수** — 주요 오답을 배제하는 단서를 stem에 명시 |

> 예: ACS vs PE 감별 시 "호흡곤란 없음, SpO2 정상, 하지 부종 없음"을 명시 → PE 배제

## 선택지 (Options) 규칙

- 모든 선택지가 **같은 카테고리** (진단명/검사/치료/다음 처치 중 하나)
- 길이 균질 (max_length_ratio ≤ 1.5)
- 정답 1개만 (single best answer)
- 모든 보기에 evidence_id 매핑 (해설 단계에서)

## 금지 사항 (Item Writing Rules)

### 절대 금지

| 항목 | 예시 |
|---|---|
| 부정형 lead-in | "~가 아닌 것은?", "EXCEPT" |
| 절대적 표현 | "항상", "절대", "모두", "절대 안 됨" |
| 이중 부정 | "~가 아닌 것이 아닌 것은?" |
| 메타 옵션 | "위 모든 것", "위 중 어느 것도 아님" |
| 문법적 단서 | a/an으로 정답 노출 |

### 경고 (가급적 회피)

- trick wording (속이는 표현)
- teaching-irrelevant rarity (희귀 사례 강조)
- 모호한 수식어 ("가장 적절한"의 정의 없는 사용)

## 정답 검증 (Solver Agent)

- 정답 라벨 제거 후 별도 풀이 시도
- 정답 일치 + top2_gap ≥ 0.20 통과 임계

## 해설 요구사항

- 정답 해설 (단순 정답 + 근거)
- 오답 해설 (각 오답이 왜 배제되는지)
- evidence_id 매핑 필수 (claim별 1개 이상)

## Bloom 레벨

- **허용**: understand, apply, analyze, evaluate
- **금지**: remember (단독 사용 금지 — 단순 암기는 본과 시험 부적격)

## JSON 형태 (참고용)

```json
{
  "item_spec": {
    "format": "single_best_answer_5_options",
    "language": "ko",
    "options": {
      "count": 5,
      "same_category_required": true,
      "length_similarity_required": true,
      "max_length_ratio": 1.5
    },
    "prohibited_phrases": [
      "위 모든 것", "위 중 어느 것도 아님",
      "all of the above", "none of the above"
    ],
    "stem_prohibited": [
      "negative_lead_in", "double_negative",
      "absolute_qualifiers_always_never"
    ],
    "answer_validation": {
      "solver_agent_required": true,
      "solver_must_differ_from_generator": true,
      "top2_correctness_gap_threshold": 0.20
    }
  }
}
```
