# SSOT — 흉통 감별진단 (Acute Chest Pain Differential Diagnosis)

> 워크숍 보너스 트랙 데모용 다층 SSOT 1페이지. 본과 3학년(M3) 임상추론 시험 출제 근거.
>
> **버전**: 1.0.0 / **승인**: 2026-05-21 (의학교육실 가상 승인) / **다음 검토**: 2026-11
>
> **충돌 해결 우선순위**: L1 학습목표집 > L2 강의노트 > L3 교과서 > L4 진료지침(의학적 사실 final) > L5 임상 vignette seed. **L2-L4 충돌 시 fail-closed → 인간 검토 강제**.

---

## 메타데이터

| 항목 | 값 |
|---|---|
| `package_id` | ChestPain_SSOT_2026_v1 |
| `course` | 임상의학입문 / 순환기학 통합과정 |
| `target_grade` | M3 (본과 3학년) |
| `topic` | 급성 흉통 감별진단 |
| `language` | ko |
| `citation_required` | true |

---

## L1 — 학습목표 (Learning Objectives)

| LO ID | Statement | Bloom | Clinical Task |
|---|---|---|---|
| **CP-01** | 급성 흉통 환자에서 생명위협 질환을 우선 감별한다. | analyze | diagnosis |
| **CP-02** | 병력·위험인자·증상 양상을 바탕으로 급성 관상동맥증후군(ACS) 가능성을 판단한다. | analyze | diagnosis |
| **CP-03** | 폐색전증·대동맥박리·기흉·위식도역류질환·근골격계 통증과 ACS를 감별한다. | analyze | diagnosis |
| **CP-04** | 흉통 환자에서 초기 검사(심전도·심근효소·D-dimer·흉부 영상)의 선택과 해석 근거를 설명한다. | apply | interpretation |

---

## L2 — 강의노트 (Lecture Notes)

**출처**: `Lecture-ChestPain-2026` (담당교수 작성, 2026 봄학기). 학교 시험 정합성의 결정자.

### LN-ACS-01 (p.45) — ACS의 전형적 임상양상
흉골하 압박감 또는 조이는 듯한 통증, **왼쪽 팔이나 턱으로의 방사통**, 식은땀(diaphoresis), 오심, 호흡곤란이 동반될 수 있다. **고혈압·당뇨병·고지혈증·흡연·가족력** 등 심혈관 위험인자가 있는 50대 이상 환자에서 가능성이 높아진다. 통증은 보통 운동 또는 스트레스로 유발되거나 안정 시에도 발생할 수 있고, 지속시간은 수분 이상이다.

### LN-PE-01 (p.47) — 폐색전증의 임상양상
**갑작스러운 호흡곤란**(가장 흔한 증상), **흉막성 흉통**, 빈호흡(>20회/분), **빈맥**, **저산소증(SpO2 < 94%)**, 객혈이 동반될 수 있다. **DVT 위험인자**(장기간 부동, 최근 수술, 악성종양, 경구 피임약, 임신, 비만, 흡연)가 강하게 시사한다. **편측 하지 부종·압통**이 동반되면 가능성이 높다.

### LN-AD-01 (p.48) — 대동맥박리의 임상양상
**갑작스럽고 찢어지는 듯한(tearing)** 격렬한 흉통, **등이나 어깨로 방사**, 양측 상지 **수축기 혈압 차이 >20 mmHg**, 신경학적 증상(뇌졸중·하지마비), 박리에 따른 대동맥판 역류 잡음이 동반될 수 있다.

### LN-GERD-01 (p.49) — 위식도역류질환
**작열감(burning)**, 식후 또는 누운 자세에서 악화, 제산제 또는 PPI에 반응. 방사통과 식은땀은 드물다.

### LN-MSK-01 (p.50) — 근골격계(늑연골염)
흉벽의 **국소 압통**, **체위·호흡·움직임에 따라 악화**. 활력징후 정상. 위험인자는 최근 외상·과사용.

### LN-PA-01 (p.51) — 공황발작
갑작스러운 강렬한 불안·이인감, 흉통은 가슴 답답함 형태, 동반 증상은 손저림·과호흡·이상감각. 과거 불안장애력. **신체검진과 ECG 정상**이어야 진단 가능(배제 진단).

### LN-INV-01 (p.52) — 초기 검사 선택의 원칙
모든 급성 흉통 환자에서 **12-lead ECG는 도착 후 10분 이내** 시행. ACS 의심 시 **cardiac troponin** 측정. PE 의심 시 **Wells score → D-dimer → CT pulmonary angiography**. 대동맥박리 의심 시 **흉부 CT angiography**. ECG 정상이고 임상 위험이 낮으면 GERD/MSK/공황 감별.

---

## L3 — 교과서 (Textbook excerpts)

**출처**: Harrison's Principles of Internal Medicine, 21st ed., Chapter "Chest Discomfort".

### TB-ACS-MECH
Myocardial ischemic discomfort is typically described as pressure, tightness, or heaviness rather than sharp or stabbing. **Radiation to the left arm, jaw, or interscapular area** is characteristic. Autonomic features (diaphoresis, nausea) increase the likelihood of ACS.

### TB-PE-MECH
Pulmonary embolism most commonly presents with **dyspnea**, with pleuritic chest pain in 40-50% of patients. **Hypoxemia, tachypnea, and tachycardia** are common findings. Risk stratification with **Wells score** is the standard initial approach.

---

## L4 — 진료지침 (Guidelines) — 의학적 사실의 final arbiter

**출처**: ACC/AHA 2021 Chest Pain Guideline (Gulati M, et al. Circulation. 2021;144(22):e368-e454).

### GL-CP-01 (Initial evaluation, Section 4.1)
All patients presenting with acute chest pain should undergo **12-lead ECG within 10 minutes** of first medical contact, along with focused history and physical examination including bilateral blood pressure measurement.

### GL-ACS-01 (ACS diagnosis, Section 4.2)
In patients with chest pain suggestive of ACS, **high-sensitivity cardiac troponin** measurement is recommended at presentation and at 1-3 hours. Risk stratification tools (HEART, EDACS, TIMI) can be used to guide disposition.

### GL-PE-01 (PE workup, ESC 2019 Acute PE)
Suspected PE requires **clinical probability assessment** (Wells, Geneva) followed by **D-dimer** in low/intermediate probability or direct **CT pulmonary angiography** in high probability cases.

### GL-CP-DDx (Differential, Section 4.4)
The "5 lethal causes" of acute chest pain that must be excluded are: **ACS, aortic dissection, pulmonary embolism, tension pneumothorax, esophageal rupture**. Discriminating features include pain quality, radiation, associated symptoms, and risk factors.

---

## L5 — 임상 Vignette Seed (맥락 보조)

> **직접 근거로 사용 금지**. 문항 vignette의 환자 인구학적·증상 조합 다양성 확보용. 비식별 처리됨.

| seed_id | 연령대 | 성별 | 핵심 risk profile | 주요 증상 패턴 | 어울리는 정답 |
|---|---|---|---|---|---|
| VG-ACS-001 | 50-70 | 남 | HTN+DM+흡연 | 흉골하 압박감 + 좌측 팔 방사 + 발한 | ACS |
| VG-ACS-002 | 55-70 | 여 | DM+고지혈증+폐경 후 | 비전형 통증(피로·턱 통증) + NV | ACS |
| VG-PE-001 | 30-50 | 남/여 | 최근 수술·장기 부동 | 갑작스러운 호흡곤란 + 흉막통 + 빈맥 + SpO2↓ | PE |
| VG-PE-002 | 25-45 | 여 | 경구 피임약 + 흡연 + 비만 | 편측 하지부종·압통 + 호흡곤란 | PE |
| VG-AD-001 | 60-75 | 남 | HTN 조절 불량 | 찢어지는 듯한 통증 + 등 방사 + 양팔 BP 차이 | 대동맥박리 |
| VG-GERD-001 | 30-50 | 남/여 | 비만 + 야간 식사 | 작열감 + 식후 악화 + 제산제 반응 | GERD |

---

## SSOT 사용 규칙 (Project 작동 시 강제)

1. **모든 문항의 핵심 claim에는 evidence_id (예: `LN-ACS-01`, `GL-ACS-01`)가 1개 이상 매핑되어야 한다.** 없으면 G2 Source Gate fail.
2. **약물 용량·치료 알고리즘은 L4가 final**. L2와 L4가 모순되면 자동 통과 금지 → 인간 검토.
3. **L5는 직접 근거로 사용할 수 없다.** vignette 환자 프로파일을 만들 때만 참조.
4. **출제 범위는 L1 LO ID에 매핑된 범위 안에서만**. CP-01~04 이외 LO는 본 SSOT의 출제 범위 밖.
5. **버전 관리**: L4 진료지침이 새로 발표되면 SSOT 버전을 올리고 영향 받는 문항을 모두 재검증한다.
