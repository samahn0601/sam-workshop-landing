# Difficulty Spec — 난이도 명세

> Bloom × 학년 × 임상과제 3축 + 심리측정 목표.

## 난이도 3축

| 축 | 값 |
|---|---|
| Bloom 인지수준 | **analyze** (감별진단 단계) |
| 학년 | **M3** (본과 3학년) |
| 임상과제 | **diagnosis** |

## 복잡도 특성

| 항목 | 값 |
|---|---|
| 양성 단서 수 | 5 |
| 음성 단서 수 (감별) | 3 |
| 산만 단서 수 | 1 |
| 검사 해석 필요 | false |
| 영상 해석 필요 | false |
| 가이드라인 알고리즘 필요 | false |
| **시간 임계 상황** | **true** (응급) |
| 약물 용량 포함 | false |
| 소아 포함 | false |
| 임신부 포함 | false |

## 심리측정 목표

| 지표 | 목표값 | 허용 범위 |
|---|---|---|
| 예상 정답률 (p-value) | 0.55 | 0.30 ~ 0.80 |
| 변별도 (discrimination) | 0.30 | ≥ 0.20 |
| 풀이 예상 시간 | 90초 | — |

## 학년별 가이드라인 (참고)

| 학년 | 기준 |
|---|---|
| M1-M2 | 기초의학·병태생리 중심 |
| **M3** | **임상입문, 진단 reasoning** |
| M4 | 초기처치·우선순위·실제 임상 의사결정 |

## JSON 형태 (참고용)

```json
{
  "difficulty_spec": {
    "axes": {
      "bloom_level": "analyze",
      "year_level": "M3",
      "clinical_task": "diagnosis"
    },
    "complexity_features": {
      "number_of_relevant_positive_findings": 5,
      "number_of_relevant_negative_findings": 3,
      "time_critical_condition": true,
      "involves_drug_dose": false
    },
    "expected_difficulty": "moderate",
    "psychometric_targets": {
      "target_p_value": 0.55,
      "p_value_range_acceptable": [0.30, 0.80],
      "target_discrimination": 0.30,
      "discrimination_minimum_acceptable": 0.20
    },
    "estimated_solving_time_seconds": 90
  }
}
```
