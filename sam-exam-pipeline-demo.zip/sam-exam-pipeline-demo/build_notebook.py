"""
워크숍 보너스 트랙 — workshop.ipynb 빌더.

직접 .ipynb JSON을 손으로 짜는 대신 Python 트리플쿼터로 셀 소스를 정의하고
표준 nbformat 4.5 구조로 직렬화한다.

실행:
    python build_notebook.py
산출:
    workshop.ipynb
"""
import json
from pathlib import Path

# ═══════════════════════════════════════════════════════════════════
# 11개 셀 정의 — (cell_type, source)
# ═══════════════════════════════════════════════════════════════════

CELLS = []

# ── Cell 1: 헤더 ──────────────────────────────────────────────────
CELLS.append(("markdown", """# 🩺 AI 시험 문제 출제 파이프라인 — 워크숍 보너스 트랙

> **D-Day**: 2026-06-20 / **세션 시간**: 30~45분 / **데모 주제**: 흉통 감별진단 (ACS vs PE)

## 5단계 파이프라인

| 단계 | 역할 | 모델 |
|---|---|---|
| 1️⃣ **SSOT 입력** | 다층 강의노트·교과서·지침 | — |
| 2️⃣ **문항 생성** | KMLE SBA 5지선다 | Claude |
| 3️⃣ **7-Gate 검증 + Solver** | fail-closed 정책 | GPT-5.5 (Generator와 다른 모델) |
| 4️⃣ **모범답안 패키지** | 학생용 + 교수용 분리 | Claude |
| 5️⃣ **이의제기 대응** | "B와 C 둘 다" → 자동 REJECT | Claude |

## 사용 방법

- **강사 시연**: 셀을 위에서 아래로 차례대로 실행 (`Shift+Enter`)
- **자기 강의노트로 교체**: `ssot/ssot_package.json` 파일만 교체 (형식 동일)
- **약물 용량 문항은 의도적 회피** (`avoid_drug_dose_questions: true`)

## ⚠️ 주의

> AI가 만든 문항은 **초안**입니다. 실제 시험 사용 전 본인 분야 정확성 검토 + 평가위원회 승인 필수.
> API 키는 워크숍 종료 후 즉시 폐기·회수하세요.
"""))

# ── Cell 2: Setup ─────────────────────────────────────────────────
CELLS.append(("code", """# 패키지 설치 (Colab 첫 실행 시만)
!pip install -q anthropic openai

# 워크숍 자산(prompts.py, pipeline_steps.py, ssot/, specs/)을 같은 폴더에 두세요
import sys, os, json
sys.path.insert(0, '.')

from pipeline_steps import (
    step1_generate_item, step2_verify_with_solver,
    step3_answer_package, step4_handle_appeal,
    save_json, save_text, render_exam_markdown, render_appeal_markdown,
)
from IPython.display import Markdown, display

print("✅ Imports OK")
"""))

# ── Cell 3: API 키 입력 ───────────────────────────────────────────
CELLS.append(("code", """from getpass import getpass

if not os.environ.get(\"ANTHROPIC_API_KEY\"):
    os.environ[\"ANTHROPIC_API_KEY\"] = getpass(\"Anthropic API Key (sk-ant-...): \")
if not os.environ.get(\"OPENAI_API_KEY\"):
    os.environ[\"OPENAI_API_KEY\"] = getpass(\"OpenAI API Key (sk-...): \")

# 마스킹 확인 (실제 키 값은 노출하지 않음)
print(f\"Anthropic key: {os.environ['ANTHROPIC_API_KEY'][:7]}***\")
print(f\"OpenAI key:    {os.environ['OPENAI_API_KEY'][:7]}***\")
"""))

# ── Cell 4: SSOT 로드 ─────────────────────────────────────────────
CELLS.append(("code", """# ═══════════════════════════════════════════════════════════════════
# SSOT 로드 — 흉통 감별진단 1페이지 (L1~L5 다층)
#
# 👉 자기 강의노트로 바꾸려면 ssot/ssot_package.json을 교체하세요.
#    형식만 동일하게 (L1 학습목표 + L2 강의노트 + L3 교과서 + L4 지침 + L5 vignette).
# ═══════════════════════════════════════════════════════════════════

with open('ssot/ssot_package.json', encoding='utf-8') as f:
    SSOT = json.load(f)

print(f\"📚 SSOT 로드 완료\")
print(f\"   ID:     {SSOT['ssot_package']['package_id']}\")
print(f\"   주제:    {SSOT['ssot_package']['topic']}\")
print(f\"   대상:    {SSOT['ssot_package']['target_grade']} ({SSOT['ssot_package']['language']})\")
print(f\"   레이어: {len(SSOT['ssot_package']['layers'])}개\")
for layer in SSOT['ssot_package']['layers']:
    n_items = len(layer.get('items', []))
    print(f\"     L{layer['layer']} {layer['name']}: {n_items}개 항목 (신뢰도 {layer.get('trust_score', '?')})\")
"""))

# ── Cell 5: Specs ─────────────────────────────────────────────────
CELLS.append(("code", """# Blueprint + Item Spec + Difficulty Spec 로드
with open('specs/blueprint.json', encoding='utf-8') as f:
    BLUEPRINT = json.load(f)
with open('specs/item_spec.json', encoding='utf-8') as f:
    ITEM_SPEC = json.load(f)
with open('specs/difficulty_spec.json', encoding='utf-8') as f:
    DIFFICULTY_SPEC = json.load(f)

print(\"⚙️ Specs 설정 완료\")
print(f\"   Blueprint:    {BLUEPRINT['blueprint']['exam_id']}\")
print(f\"   문항 형식:     {ITEM_SPEC['item_spec']['format']}\")
print(f\"   3축:          bloom={DIFFICULTY_SPEC['difficulty_spec']['axes']['bloom_level']}, \"
      f\"year={DIFFICULTY_SPEC['difficulty_spec']['axes']['year_level']}, \"
      f\"task={DIFFICULTY_SPEC['difficulty_spec']['axes']['clinical_task']}\")
print(f\"   목표 정답률:   {DIFFICULTY_SPEC['difficulty_spec']['psychometric_targets']['target_p_value']}\")
print(f\"   안전 정책:    avoid_drug_dose={BLUEPRINT['blueprint']['safety_constraints']['avoid_drug_dose_questions']}\")
"""))

# ── Cell 6: STEP 1 — Generate ─────────────────────────────────────
CELLS.append(("code", """# ═══════════════════════════════════════════════════════════════════
# STEP 1. Item Generator (Claude)
# ═══════════════════════════════════════════════════════════════════
print(\"⏳ STEP 1. Claude에게 문항 생성 요청...\")
item_result = step1_generate_item(SSOT, BLUEPRINT, ITEM_SPEC, DIFFICULTY_SPEC)

it = item_result.get('item', item_result)
print(f\"\\n✅ 문항 생성 완료: {it.get('item_id', 'UNKNOWN')}\")
print(f\"   정답: {it.get('answer_key', '?')}\")
print(f\"   evidence_links: {len(it.get('evidence_links', []))}개 claim\")

# 미리보기
options_md = \"\\n\".join(f\"- **{o['label']}.** {o['text']}\" for o in it['options'])
display(Markdown(f\"### 생성된 문항\\n\\n{it['stem']}\\n\\n{options_md}\"))
"""))

# ── Cell 7: STEP 2 — Verify + Solver ──────────────────────────────
CELLS.append(("code", """# ═══════════════════════════════════════════════════════════════════
# STEP 2. 7-Gate Verifier(GPT) + Solver Agent(GPT, Generator와 다른 모델)
# ═══════════════════════════════════════════════════════════════════
print(\"⏳ STEP 2. 7-Gate Verifier + Solver Agent (GPT-5.5)...\")
verify_result = step2_verify_with_solver(item_result, SSOT, BLUEPRINT, ITEM_SPEC)

gate_report = verify_result['gate_report']
solver = verify_result['solver_result']

print(f\"\\n📋 7-Gate 종합 판정: **{gate_report.get('overall_status', '?').upper()}**\\n\")
for g in gate_report.get('gates', []):
    icon = \"✅\" if g['status'] == 'pass' else \"❌\"
    print(f\"  {icon} Gate {g['gate']}: {g['name']:<35s} — {g['status']}\")
    if g['status'] != 'pass':
        print(f\"     사유: {g.get('comment', '')}\")

print(f\"\\n🤖 Solver Agent (정답 라벨 제거 후 GPT가 풀이)\")
print(f\"   예측 정답:    {solver.get('predicted_answer', '?')} (실제 정답: {it.get('answer_key', '?')})\")
print(f\"   Confidence:   {solver.get('confidence', 0):.2f}\")
print(f\"   top2 gap:     {solver.get('top2_gap', 0):.2f} (임계값 ≥ 0.20)\")

is_match = solver.get('predicted_answer') == it.get('answer_key')
gap_ok = solver.get('top2_gap', 0) >= 0.20
if is_match and gap_ok:
    print(\"\\n✅ Single Best Answer Gate 통과\")
else:
    print(\"\\n⚠️ Single Best Answer Gate 주의 — 인간 검토 권장\")
"""))

# ── Cell 8: STEP 3 — Answer Package ───────────────────────────────
CELLS.append(("code", """# ═══════════════════════════════════════════════════════════════════
# STEP 3. 모범답안 패키지 (Claude) — 학생용 + 교수용 분리
# ═══════════════════════════════════════════════════════════════════
print(\"⏳ STEP 3. 모범답안 패키지 생성 (Claude)...\")
package_result = step3_answer_package(item_result, SSOT)

pkg = package_result.get('model_answer_package', package_result)
sf = pkg.get('student_facing_explanation', {})

# 학생용 미리보기
why_not_md = \"\\n\".join(
    f\"- **{w['option']}**: {w.get('explanation', '')}\"
    for w in sf.get('why_not_others', [])
)
display(Markdown(f\"\"\"## 📚 학생용 모범답안

**정답**: {pkg.get('answer_key', '?')}

{sf.get('correct_answer_explanation', '')}

### 오답 해설

{why_not_md}

**Take-home**: {sf.get('take_home_message', '')}
\"\"\"))

# 교수용 appeal_risk
ff = pkg.get('faculty_facing_explanation', {})
ar = ff.get('appeal_risk', {})
print(f\"\\n📌 예상 이의제기 위험: **{ar.get('risk_level', '?').upper()}**\")
for arg in ar.get('possible_appeal_arguments', []):
    print(f\"   - {arg}\")
"""))

# ── Cell 9: STEP 4 — Appeal ───────────────────────────────────────
CELLS.append(("code", """# ═══════════════════════════════════════════════════════════════════
# STEP 4. 이의제기 자동 대응 (Claude)
# 시나리오: 학생이 "B 폐색전증도 정답"이라고 주장
# ═══════════════════════════════════════════════════════════════════
STUDENT_APPEAL = \"\"\"폐색전증도 급성 흉통의 중요한 감별진단입니다.
환자가 50대 후반 남성이고 흡연력이 있어 PE 위험인자에도 해당합니다.
따라서 B(폐색전증)와 C(급성 관상동맥증후군) 둘 다 정답으로 인정되어야 합니다.\"\"\"

print(\"📨 학생 이의제기 접수:\")
print(f\"   '{STUDENT_APPEAL[:80]}...'\")
print(\"\\n⏳ STEP 4. AI 자동 분석 (Claude)...\")

appeal_result = step4_handle_appeal(item_result, package_result, STUDENT_APPEAL, SSOT)

ap = appeal_result.get('appeal', appeal_result)
print(f\"\\n⚖️ 판정: **{ap['decision']['outcome'].upper()}**\")
print(f\"   정답 변경:      {ap['decision'].get('answer_key_status', '?')}\")
print(f\"   점수 조정:      {ap['decision'].get('score_adjustment', '?')}\")
print(f\"   문항 수정 필요: {ap['decision'].get('need_item_revision', False)}\")
print(f\"   인간 검토 필수: {ap.get('human_review_required', True)}\")

display(Markdown(render_appeal_markdown(appeal_result)))
"""))

# ── Cell 10: STEP 5 — Save ────────────────────────────────────────
CELLS.append(("code", """# ═══════════════════════════════════════════════════════════════════
# STEP 5. 결과 저장 (JSON + Markdown) + docx 변환 안내
# ═══════════════════════════════════════════════════════════════════
os.makedirs('outputs', exist_ok=True)
save_json(item_result,    'outputs/01_generated_item.json')
save_json(verify_result,  'outputs/02_gate_report.json')
save_json(package_result, 'outputs/03_model_answer_package.json')
save_json(appeal_result,  'outputs/04_appeal_decision.json')

save_text(render_exam_markdown(item_result, package_result), 'outputs/exam.md')
save_text(render_appeal_markdown(appeal_result),             'outputs/appeal_report.md')

print(\"💾 저장 완료:\\n\")
for fn in sorted(os.listdir('outputs')):
    size_kb = os.path.getsize(f'outputs/{fn}') / 1024
    print(f\"   outputs/{fn:<35s} ({size_kb:5.1f} KB)\")

print(\"\\n📄 docx 변환 (선택):\")
print(\"   !apt-get install -qq pandoc\")
print(\"   !pandoc outputs/exam.md -o outputs/exam.docx\")
print(\"   !pandoc outputs/appeal_report.md -o outputs/appeal_report.docx\")
"""))

# ── Cell 11: 마무리 ──────────────────────────────────────────────
CELLS.append(("markdown", """## 🎉 데모 완료

40분 안에 강의노트 → 문항 1개 → 7-Gate 검증 → 모범답안 → 이의제기 대응까지 끝났습니다.

## 다음 단계

| 항목 | 방법 |
|---|---|
| 자기 강의노트로 교체 | `ssot/ssot_package.json` 파일 교체 (형식 동일) |
| 다른 주제 확장 | 복통·두통·발열 감별진단 등 |
| docx 변환 | `!pandoc outputs/exam.md -o outputs/exam.docx` |
| 사후 운영 | 학내 Sam AI v1.3 파이프라인 연동 (보안 모드 + 문항은행 등재 자동화) |

## 반드시 기억할 함정 7가지

1. **SSOT 없는 LLM 생성** — 모든 핵심 claim에 `evidence_id` 매핑 강제
2. **"가능한 진단" vs "가장 가능성 높은 진단" 혼동** — stem에 음성 소견(negative findings) 명시
3. **AI 검증 = 인간 승인 오해** — 최종 판정은 평가위원회 의결
4. **L2 강의노트와 L4 최신 지침 충돌 묵인** — fail-closed → 인간 검토 강제
5. **Solver와 Generator 같은 모델** — 동질화 오차. **반드시 다른 모델** (Generator=Claude, Solver=GPT)
6. **fail/needs_review 배너가 출력에서 사라짐** — 출력 상단에 검증 상태 명시 유지
7. **약물 용량/소아/임신부 문항 데모 포함** — 검증 부담 큼, 본 데모는 회피

## 워크숍 종료 후

- ✅ **API 키 즉시 폐기·회수** (특히 임시 공용 키)
- ✅ **생성된 문항은 본인 분야 정확성 검토 후 사용**
- ✅ **실제 시험 투입 전 평가위원회 승인 필수**
- ✅ **학생 개인정보·실제 출제 예정 문항을 퍼블릭 LLM에 입력 금지** (보안)

---

*Bonus Track Reference Deliverable v1.0 / 2026-05-21 / Workshop D-30*
"""))


# ═══════════════════════════════════════════════════════════════════
# 노트북 직렬화
# ═══════════════════════════════════════════════════════════════════

def make_notebook(cells):
    nb_cells = []
    for ctype, source in cells:
        cell = {
            "cell_type": ctype,
            "metadata": {},
            "source": source,
        }
        if ctype == "code":
            cell["execution_count"] = None
            cell["outputs"] = []
        nb_cells.append(cell)
    return {
        "cells": nb_cells,
        "metadata": {
            "kernelspec": {
                "display_name": "Python 3",
                "language": "python",
                "name": "python3",
            },
            "language_info": {
                "name": "python",
                "version": "3.10",
            },
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }


def main():
    nb = make_notebook(CELLS)
    out = Path(__file__).parent / "workshop.ipynb"
    with open(out, "w", encoding="utf-8") as f:
        json.dump(nb, f, ensure_ascii=False, indent=1)
    print(f"Created {out.name} with {len(CELLS)} cells "
          f"({out.stat().st_size / 1024:.1f} KB)")


if __name__ == "__main__":
    main()
