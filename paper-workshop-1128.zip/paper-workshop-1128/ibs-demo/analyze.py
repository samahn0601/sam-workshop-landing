"""Workshop only: run with Python 3, no extra packages required."""
import csv
from pathlib import Path
from decimal import Decimal
from statistics import mean, stdev
from math import ceil, floor

HERE = Path(__file__).resolve().parent
OUT = HERE / 'output'
MISSING = {'', 'NA', 'N/A'}
def write_table(path, fields, rows):
    with path.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.writer(handle)
        writer.writerow(fields)
        writer.writerows(rows)

def main():
    groups = {'0': [], '1': []}
    ids, patients = set(), []
    excluded = dict.fromkeys(groups, 0)
    with (HERE / 'SYNTHETIC_IBS.csv').open(encoding='utf-8-sig', newline='') as fh:
        for row in csv.DictReader(fh):
            ident, group, base, week4 = (row[k].strip() for k in
                ('synthetic_id','synthetic_group','baseline_ibs_sss','week4_ibs_sss'))
            if not ident or ident in ids or group not in groups:
                raise ValueError('Missing/duplicate ID or unexpected group: ' + ident)
            ids.add(ident)
            if base in MISSING or week4 in MISSING:
                excluded[group] += 1
                change = ''
            else:
                change = Decimal(base) - Decimal(week4)
                groups[group].append(float(change))
            patients.append([ident, group, base, week4, change])
    if any(len(vals) < 2 for vals in groups.values()):
        raise ValueError('Each group needs at least two complete pairs for this exercise.')
    OUT.mkdir(exist_ok=True)
    write_table(OUT/'patients.csv',['synthetic_id','synthetic_group','baseline_ibs_sss','week4_ibs_sss','improvement'],patients)
    summary = [[g,len(v),excluded[g],f'{mean(v):.6f}',f'{stdev(v):.6f}'] for g,v in groups.items()]
    write_table(OUT/'summary.csv',['group','n_included','n_excluded','mean','sample_sd'],summary)
    all_values = [v for vals in groups.values() for v in vals] + [0.]
    lo, hi = 25*floor(min(all_values)/25), 25*ceil(max(all_values)/25)
    if hi == lo: hi += 25
    def y(v): return 280 - 225*(v-lo)/(hi-lo)
    svg=['<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 350" role="img"><title>합성 IBS 자료: 군별 개인 변화량과 평균</title><rect width="640" height="350" fill="white"/><g font-family="sans-serif" fill="#182631"><text x="30" y="28">IBS-SSS 변화량 (기저 − 4주, 점)</text>']
    for tick in range(lo,hi+1,25):
        svg.append(f'<path d="M80 {y(tick):.2f}h500" stroke="#d5dbe0"/><text x="69" y="{y(tick)+5:.2f}" text-anchor="end">{tick}</text>')
    for idx,(g,vs) in enumerate(groups.items()):
        x=210+idx*235
        for j,v in enumerate(vs):
            offset=(((j*17)%47)-23)*1.25
            svg.append(f'<circle cx="{x+offset:.2f}" cy="{y(v):.2f}" r="3" fill="#15736f" opacity=".65"/>')
        svg.append(f'<path d="M{x-39} {y(mean(vs)):.2f}h78" stroke="#192c4d" stroke-width="4"/><text x="{x}" y="311" text-anchor="middle">군 {g} (n={len(vs)})</text>')
    svg.append('<text x="80" y="339" font-size="14">점: 개인 변화량　 가로 막대: 군 평균　 양수: 증상 호전</text></g></svg>')
    (OUT/'changes.svg').write_text('\n'.join(svg),encoding='utf-8')
    # Display the actual results from this run inside the participant's chat.
    expected = {'0': (60, 0, 40.82, 50.14), '1': (60, 0, 49.23, 50.84)}
    matched = all((n, exc, round(float(avg), 2), round(float(sd), 2)) == expected[g]
                  for g, n, exc, avg, sd in summary)
    lines = ['합성 IBS 자료의 기저 점수에서 4주 점수를 뺐습니다. 양수는 호전입니다.', '',
             '| 군 | 분석 인원 | 제외 인원 | 평균 변화량(점) | 표본표준편차(점) |',
             '|---|---:|---:|---:|---:|']
    for g,n,exc,avg,sd in summary:
        lines.append(f'| {g} | {n} | {exc} | {float(avg):.2f} | {float(sd):.2f} |')
    svgpath = (OUT/'changes.svg').resolve().as_posix().replace('<','%3C').replace('>','%3E')
    lines += ['', f'[그림 열기](<{svgpath}>)', '',
              '군별 요약값이 실습 기준표와 일치합니다.' if matched else '실습 기준표와 다릅니다. 입력 자료와 분석 규칙을 확인하세요.']
    (OUT/'chat_result.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('Saved patients.csv, summary.csv, changes.svg in', OUT)
if __name__ == '__main__':
    main()
