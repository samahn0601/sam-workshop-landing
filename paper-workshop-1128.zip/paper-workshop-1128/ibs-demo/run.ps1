# Windows PowerShell 5.1 or newer. No administrator rights, pip, or PATH edits.
# Runtime files: https://www.python.org/downloads/release/python-31317/
[CmdletBinding()]
param(
    [switch] $UsePrivateRuntime,
    [string] $CacheDirectory
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
if (-not $CacheDirectory) { $CacheDirectory = Join-Path $PSScriptRoot '.ibs-runtime' }
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
$analysis = Join-Path $PSScriptRoot 'analyze.py'
if (-not [IO.File]::Exists($analysis)) { throw 'analyze.py is missing. Extract the full workshop ZIP first.' }

function Test-Python([string]$exe) {
    if (-not $exe -or -not [IO.File]::Exists($exe)) { return $false }
    # Bare Store app execution aliases can open the Store instead of a usable interpreter.
    if ($exe -match '\\Microsoft\\WindowsApps\\python(?:3)?\.exe$') { return $false }
    try {
        $reply = & $exe -I -c "import sys, csv, statistics, pathlib; print(int(sys.version_info >= (3, 8)))" 2>$null
        return ($LASTEXITCODE -eq 0 -and "$reply".Trim() -eq '1')
    } catch { return $false }
}

function Find-Python {
    $items = New-Object 'System.Collections.Generic.List[string]'
    # Derive the live Codex package directory from its own PATH; version is intentionally not pinned.
    foreach ($part in ($env:Path -split ';')) {
        if ($part -match '(?i)^(.*\\OpenAI\.CodexPrimaryRuntime[^\\]*\\dependencies)(?:\\|$)') {
            $candidate = Join-Path $Matches[1] 'python\python.exe'
            if (-not $items.Contains($candidate)) { $items.Add($candidate) }
        }
    }
    foreach ($cmd in @(Get-Command python.exe,python3.exe -All -CommandType Application -ErrorAction SilentlyContinue)) {
        if ($cmd.Source) { $items.Add($cmd.Source) }
    }
    foreach ($reg in 'HKCU:\Software\Python\PythonCore','HKLM:\Software\Python\PythonCore','HKLM:\Software\WOW6432Node\Python\PythonCore') {
        foreach ($install in @(Get-ChildItem -Path $reg -ErrorAction SilentlyContinue)) {
            $key = Get-Item -LiteralPath (Join-Path $install.PSPath 'InstallPath') -ErrorAction SilentlyContinue
            if ($key) {
                $e = $key.GetValue('ExecutablePath'); if ($e) { $items.Add($e) }
                $dir = $key.GetValue(''); if ($dir) { $items.Add((Join-Path $dir 'python.exe')) }
            }
        }
    }
    foreach ($item in $items) { if (Test-Python $item) { return $item } }
    return $null
}

function Get-Digest([string]$path) {
    $stream = [IO.File]::OpenRead($path)
    $alg = [Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($alg.ComputeHash($stream))).Replace('-','').ToLowerInvariant() }
    finally { $stream.Dispose(); $alg.Dispose() }
}

function Get-PrivatePython {
    $version = '3.13.17'
    $nativeArch = if ($env:PROCESSOR_ARCHITEW6432) { $env:PROCESSOR_ARCHITEW6432 } else { $env:PROCESSOR_ARCHITECTURE }
    switch ($nativeArch.ToUpperInvariant()) {
        'AMD64' { $arch='amd64'; $expected='9e35319bffedab8b36ad44d8f377cb4f1733bcec257a0b6d04d94f01486ddb38' }
        'ARM64' { $arch='arm64'; $expected='7b58787a047b400edbfcb539aa3cdb4e2ed77bf0f22cae42b7c01cedd7dd6614' }
        'X86' { $arch='win32'; $expected='4afd37bc88ed1391209a4c58deb902cd0741a476692412b23d340aff6e9285e7' }
        default { throw "Unsupported Windows processor architecture: $nativeArch" }
    }
    $cache = [IO.Path]::GetFullPath($CacheDirectory)
    [void][IO.Directory]::CreateDirectory($cache)
    $name = "python-$version-embed-$arch"
    $zip = Join-Path $cache ($name + '.zip')
    if (-not [IO.File]::Exists($zip) -or (Get-Digest $zip) -ne $expected) {
        $url = "https://www.python.org/ftp/python/$version/$name.zip"
        $part = Join-Path $cache ([Guid]::NewGuid().ToString('N') + '.partial')
        Write-Host "Installing private workshop Python from $url"
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -UseBasicParsing -Uri $url -OutFile $part -TimeoutSec 90 -ErrorAction Stop
            if ((Get-Digest $part) -ne $expected) { throw 'Python archive checksum mismatch. Download was not used.' }
            [IO.File]::Copy($part,$zip,$true)
        } finally { if ([IO.File]::Exists($part)) { [IO.File]::Delete($part) } }
    }
    # Only extract and load the exact official archive; never load an executable from the ZIP provided by a participant.
    if ((Get-Digest $zip) -ne $expected) { throw 'Cached Python archive checksum mismatch.' }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $fresh = Join-Path $cache ('session-' + [Guid]::NewGuid().ToString('N'))
    [IO.Compression.ZipFile]::ExtractToDirectory($zip,$fresh)
    $script:privateSession = [IO.Path]::GetFullPath($fresh)
    $py = Join-Path $fresh 'python.exe'
    if (-not (Test-Python $py)) { throw 'The verified Python runtime could not start. Check your device or organization execution policy.' }
    return $py
}

$privateSession = $null
$exe = $null
try {
    if (-not $UsePrivateRuntime) { $exe = Find-Python }
    if (-not $exe) { $exe = Get-PrivatePython }
    Write-Host "Using Python: $exe"
    & $exe -I -X utf8 $analysis
    $result = $LASTEXITCODE
} finally {
    if ($privateSession) {
        $root = [IO.Path]::GetFullPath($CacheDirectory).TrimEnd('\')
        if ([IO.Path]::GetDirectoryName($privateSession) -eq $root -and [IO.Path]::GetFileName($privateSession) -match '^session-[0-9a-f]{32}$') {
            Remove-Item -LiteralPath $privateSession -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}
exit $result
