#!/bin/sh
# Launch from any folder: sh "/path/to/ibs-demo/run.sh"
# Only the Python standard library is needed. No sudo and no changes to PATH.
set -eu
dir=$(CDPATH='' cd -P "$(dirname "$0")" && pwd)
[ -f "$dir/analyze.py" ] || { echo 'Cannot find analyze.py next to run.sh.' >&2; exit 1; }
task=${1:-analyze}
arg2=${2:-}
arg3=${3:-}
os=$(uname -s)
usable() {
  [ -n "$1" ] && [ -x "$1" ] || return 1
  # /usr/bin/python3 on a Mac without developer tools may be an installer stub.
  if [ "$os" = Darwin ]; then
    case "$1" in /usr/bin/python|/usr/bin/python3) /usr/bin/xcode-select -p >/dev/null 2>&1 || return 1;; esac
  fi
  "$1" -I -c 'import csv, decimal, statistics, sys; sys.exit(sys.version_info < (3,8))' >/dev/null 2>&1
}
run_analysis() {
  echo "Python: $1" >&2
  case "$task" in
    analyze) exec "$1" -I "$dir/analyze.py";;
    git) exec "$1" -I "$dir/git_practice.py";;
    preview) if [ -n "$arg2" ]; then exec "$1" -I "$dir/publish_github.py" preview "$arg2"; else exec "$1" -I "$dir/publish_github.py" preview; fi;;
    publish) [ -n "$arg2" ] && [ -n "$arg3" ] || { echo 'Missing confirmed owner or name.' >&2; exit 1; }; exec "$1" -I "$dir/publish_github.py" publish "$arg2" "$arg3";;
    *) echo 'Unknown workshop task' >&2; exit 1;;
  esac
}
# Used by release QA to exercise bootstrap even on developer machines.
if [ "${IBS_WORKSHOP_FRESH_RUNTIME:-0}" != 1 ]; then
  for py in "$(command -v python3 || :)" "$(command -v python || :)" /opt/homebrew/bin/python3 /usr/local/bin/python3 /Library/Frameworks/Python.framework/Versions/Current/bin/python3 /usr/bin/python3; do
    if usable "$py"; then run_analysis "$py"; fi
  done
fi
case "$(uname -m)" in aarch64|arm64) arch=aarch64;; x86_64|amd64) arch=x86_64;; *) echo 'Automatic Python installation is unavailable on this CPU. Install Python 3.8+ and retry.' >&2; exit 1;; esac
case "$os" in
 Darwin) target="$arch-apple-darwin"; default_cache="${HOME:?}/Library/Caches";;
 Linux) libc=gnu; case "$(ldd --version 2>&1 || :)" in *musl*) libc=musl;; esac; target="$arch-unknown-linux-$libc"; default_cache="${XDG_CACHE_HOME:-${HOME:?}/.cache}";;
 *) echo 'Use run.ps1 on Windows, or install Python 3.8+.' >&2; exit 1;;
esac
# SHA-256 values from official GitHub release asset metadata:
# https://api.github.com/repos/astral-sh/python-build-standalone/releases/tags/20261124
release=20261124
version=3.13.18
case "$target" in
 aarch64-apple-darwin) digest=296f0903cccda15a5c9d3d8393cd2204718aeffd9b095a00f812d75c7b1c0967;;
 x86_64-apple-darwin) digest=bb16e167ec9e38368118ce3e43ba2c7852fea2cdba16e1852555a8997747f78a;;
 aarch64-unknown-linux-gnu) digest=300d388cef58ff23f101e1a41512dc51db9adae136b138c61af9ae1b1d9703a7;;
 x86_64-unknown-linux-gnu) digest=b56ceb4fc1d8f0c49b7bd4dc91cd176bad7b86a88b9fc509bae6b10b3ee36692;;
 aarch64-unknown-linux-musl) digest=e057c4cc569f259d3435de376e5d88b7ed01055de17f6e5274aca2ad44258ffd;;
 x86_64-unknown-linux-musl) digest=a303b0eb46eed7e2f23ff38f4a0237f02f2954cf2e909b27dc4dc582b099ad50;;
 *) exit 1;;
esac
base="${IBS_WORKSHOP_CACHE:-$default_cache/ibs-workshop}"
dest="$base/python-$version-$release-$target"
if usable "$dest/bin/python3"; then run_analysis "$dest/bin/python3"; fi
umask 077
mkdir -p "$base"
lock="$dest.installing"
if ! mkdir "$lock" 2>/dev/null; then
  echo "Installation in progress or interrupted. Check $lock before retrying." >&2; exit 1
fi
stage=''
cleanup() {
  # Delete only this invocation's private temporary staging directory.
  if [ -n "$stage" ]; then rm -rf "$stage"; fi
  rmdir "$lock" 2>/dev/null || :
}
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
if ! usable "$dest/bin/python3"; then
  if [ -e "$dest" ]; then echo "Unusable cached runtime at $dest; inspect the cache and retry." >&2; exit 1; fi
  stage=$(mktemp -d "$base/.ibs-stage.XXXXXXXX")
  url="https://github.com/astral-sh/python-build-standalone/releases/download/$release/cpython-$version%2B$release-$target-install_only_stripped.tar.gz"
  echo "Installing CPython $version in $dest" >&2
  curl --fail --silent --show-error --location --proto '=https' --proto-redir '=https' --retry 2 --connect-timeout 15 --max-time 240 "$url" -o "$stage/runtime.tgz"
  if command -v shasum >/dev/null 2>&1; then
    actual=$(shasum -a 256 "$stage/runtime.tgz")
  else
    actual=$(sha256sum "$stage/runtime.tgz")
  fi
  [ "${actual%% *}" = "$digest" ] || { echo 'Python archive integrity check failed; not installing.' >&2; exit 1; }
  tar -xzf "$stage/runtime.tgz" -C "$stage"
  usable "$stage/python/bin/python3" || { echo 'The downloaded runtime cannot run on this OS.' >&2; exit 1; }
  mv "$stage/python" "$dest"
fi
cleanup
trap - EXIT HUP INT TERM
run_analysis "$dest/bin/python3"
