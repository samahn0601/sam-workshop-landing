"""Create or verify a strictly synthetic, local, two-commit workshop repository."""
from pathlib import Path
from hashlib import sha256
import html
import json
import os
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
REPO = HERE / "git-practice"
REPORT = HERE / "git-practice-report"
FILES = ("README.md", "summary.csv", "style_figure.py", "figure.svg")
TITLE1 = "Save the original synthetic IBS figure"
TITLE2 = "Emphasize the zero-change line"
PINS = {"summary.csv": "4f62d4c99081a1f1234e305c897c7b3caeaf41e8593718129e4f855547812aaf",
        "changes.svg": "d44f0675bd0fe781a9de64458d91d923ad28c6769bc1795da4383c541c863235"}
ZERO = b'<path d="M80 198.18h500" stroke="#d5dbe0"/><text x="69" y="203.18" text-anchor="end">0</text>'
BOLD = ZERO.replace(b'stroke="#d5dbe0"', b'stroke="#263746" stroke-width="4"')
STYLE = '''"""Restyle only the horizontal grid line labelled zero in figure.svg."""
from pathlib import Path
import re
p = Path(__file__).resolve().with_name("figure.svg")
original = p.read_text(encoding="utf-8")
ZERO_LINE_WIDTH = 1
line = re.compile(r'(<path d="M80 [0-9.]+h500") stroke="[^"]+"(?: stroke-width="[0-9]+")?(/><text [^>]+>0</text>)')
color = "#d5dbe0" if ZERO_LINE_WIDTH == 1 else "#263746"
style = ' stroke="' + color + '"' + ('' if ZERO_LINE_WIDTH == 1 else ' stroke-width="' + str(ZERO_LINE_WIDTH) + '"')
updated, count = line.subn(lambda match: match[1] + style + match[2], original)
if count != 1:
    raise SystemExit("Expected exactly one horizontal line labelled 0.")
p.write_bytes(updated.encode("utf-8"))
'''.encode()
README = """# IBS 변화량 그림: Git 실습

제공된 합성 IBS 자료의 그림과 군별 요약표로 변경 이력을 살펴보는 저장소입니다.
두 군의 인원은 각각 60명입니다. 평균 변화량은 군 0이 40.82점, 군 1이 49.23점입니다.
양수는 4주 점수가 기저보다 낮다는 뜻입니다. 실제 환자 자료나 치료 효과에 대한 결론은 포함하지 않습니다.

![합성 IBS 자료의 개인별 변화량과 군별 평균](figure.svg)

첫 커밋은 원래 그림을, 두 번째 커밋은 0점선을 굵고 진하게 바꾼 그림을 보관합니다.
두 커밋 사이에 군별 요약표는 그대로입니다. 그림 서식을 다시 적용하려면 이 폴더에서
Python 3으로 `style_figure.py`를 실행하세요. 분석 결과는 `summary.csv`에 있습니다.
""".encode()

def checked(ok, msg):
    if not ok:
        raise ValueError(msg)

def normalized(p):
    return p.read_bytes().replace(b"\r\n", b"\n")

def expected_trees():
    d = HERE / "output"
    for name in PINS:
        p = d / name
        checked(p.is_file() and not p.is_symlink(), "먼저 같은 폴더에서 정규 IBS 공통 실습을 마치세요: " + name)
    summary, svg = (normalized(d/name) for name in ("summary.csv","changes.svg"))
    for name, data in (("summary.csv",summary), ("changes.svg",svg)):
        checked(sha256(data).hexdigest() == PINS[name], "배포된 합성 자료의 원래 분석 결과와 다릅니다. 기존 작업을 보존하고 새 실습 폴더에서 IBS 분석부터 실행하세요: " + name)
    checked(svg.count(ZERO)==1,"0점선을 식별할 수 없습니다.")
    before = {"README.md":README, "summary.csv":summary, "style_figure.py":STYLE, "figure.svg":svg}
    return (before, dict(before, **{"style_figure.py":STYLE.replace(b"ZERO_LINE_WIDTH = 1\n",b"ZERO_LINE_WIDTH = 4\n"), "figure.svg":svg.replace(ZERO,BOLD)}))

def find_git():
    path = shutil.which("git")
    if not path and os.name=="nt":
        for location in (os.environ.get("ProgramFiles"),os.environ.get("ProgramW6432"),os.environ.get("LOCALAPPDATA")):
            if location:
                for sub in ("Git/cmd/git.exe","Programs/Git/cmd/git.exe"):
                    p=Path(location)/sub
                    if p.is_file(): return str(p)
    checked(path, "Git을 찾지 못했습니다. QR 안내 ⑩의 Git 설치부터 진행한 뒤 다시 시도하세요.")
    return path

def git(repo, *args, **opts):
    env = {k:v for k,v in os.environ.items() if not k.upper().startswith("GIT_")}
    env.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull, GIT_TERMINAL_PROMPT="0",
               GIT_AUTHOR_NAME="IBS workshop", GIT_COMMITTER_NAME="IBS workshop",
               GIT_AUTHOR_EMAIL="workshop@example.invalid", GIT_COMMITTER_EMAIL="workshop@example.invalid")
    if opts.get("date"):
        env.update(GIT_AUTHOR_DATE=opts["date"], GIT_COMMITTER_DATE=opts["date"])
    command=[find_git(), "-c","core.hooksPath="+os.devnull, "-c","core.fsmonitor=false","-c","core.autocrlf=false","-c","commit.gpgSign=false","-c","core.pager=cat",*args]
    p=subprocess.run(command, cwd=str(repo), env=env, stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode:
        raise ValueError("Git 실행 실패: " + p.stderr.decode("utf-8", "replace").strip())
    return p.stdout

def verify_ready(repo):
    repo=Path(repo)
    checked(not repo.is_symlink() and not (repo/".git").is_symlink() and (repo/".git").is_dir(), "독립된 실습 Git 저장소가 아닙니다.")
    checked(Path(git(repo,"rev-parse","--show-toplevel").decode().strip()).resolve()==repo.resolve(), "상위 저장소를 사용할 수 없습니다.")
    checked(git(repo,"symbolic-ref","--short","HEAD").strip()==b"main","실습 main 브랜치가 아닙니다.")
    checked({f.name for f in repo.iterdir()}==set(FILES)|{".git"},"예상하지 않은 파일이 있어 중단합니다. 기존 파일은 변경하지 않습니다.")
    checked(not git(repo,"status","--porcelain=v1","--untracked-files=all").strip(),"저장소에 별도 변경이 있습니다.")
    refs=set(git(repo,"for-each-ref","--format=%(refname)").decode().splitlines())
    checked(refs <= {"refs/heads/main","refs/remotes/origin/main","refs/remotes/origin/HEAD"}, "예상하지 않은 브랜치 또는 태그가 있습니다.")
    chain=git(repo,"rev-list","--reverse","--parents","HEAD").decode().splitlines()
    checked(len(chain)==2 and len(chain[0].split())==1 and len(chain[1].split())==2 and chain[1].split()[1]==chain[0],"실습의 두 커밋만 업로드할 수 있습니다.")
    ids=[row.split()[0] for row in chain]
    for ix,(commit,tree) in enumerate(zip(ids,expected_trees())):
        tree_id=git(repo,'rev-parse',commit+'^{tree}').decode().strip()
        stamp=int(datetime(2026,11,1,0,ix,tzinfo=timezone.utc).timestamp())
        actor="IBS workshop <workshop@example.invalid> "+str(stamp)+" +0000"
        metadata="tree "+tree_id+"\n"+("parent "+ids[0]+"\n" if ix else "")+"author "+actor+"\ncommitter "+actor+"\n\n"+(TITLE1,TITLE2)[ix]+"\n"
        checked(git(repo,'cat-file','commit',commit)==metadata.encode(),"실습에서 생성한 두 커밋의 원본 메타데이터와 다릅니다.")
        entries=git(repo,"ls-tree","-r","-z",commit).rstrip(b"\0").split(b"\0")
        checked(all(entry.startswith(b"100644 blob ") for entry in entries) and {e.split(b"\t",1)[1].decode() for e in entries}==set(FILES),"커밋에 예상하지 않은 파일이 있습니다.")
        for f in FILES:
            checked(git(repo,"cat-file","blob",commit+":"+f)==tree[f], "공개할 커밋의 내용이 원본 실습과 다릅니다: "+f)
            if ix==1:
                checked(not (repo/f).is_symlink() and normalized(repo/f)==tree[f], "작업 파일 내용이 다릅니다: "+f)
    return tuple(ids)

def create_repo():
    before,after=expected_trees()
    repo=REPO
    if repo.exists() or repo.is_symlink():
        ids=verify_ready(repo)
        checked(not git(repo,"remote").strip(), "이미 원격이 연결되어 있습니다. 기존 저장소는 변경하지 않습니다.")
        return ids
    # Build in a fresh independent repository, then publish locally without touching other work.
    temp=Path(tempfile.mkdtemp(prefix=".ibs-git-create-",dir=str(HERE)))
    git(temp,"init","-q","--template=",".")
    git(temp,"symbolic-ref","HEAD","refs/heads/main")
    for name,data in before.items(): (temp/name).write_bytes(data)
    git(temp,"add","--",*FILES)
    git(temp,"commit","-q","-m",TITLE1,date="2026-11-01T00:00:00Z")
    (temp/"style_figure.py").write_bytes(after["style_figure.py"])
    subprocess.run([sys.executable,"-I",str(temp/"style_figure.py")],cwd=str(temp),check=True)
    checked(all((temp/name).read_bytes()==b for name,b in after.items()),"그림 0점선 외에 예상하지 않은 변경이 있습니다.")
    git(temp,"add","--","style_figure.py","figure.svg")
    git(temp,"commit","-q","-m",TITLE2,date="2026-11-01T00:01:00Z")
    ids=verify_ready(temp)
    checked(not repo.exists() and not repo.is_symlink(),"같은 이름의 폴더가 방금 생성됐습니다.")
    temp.rename(repo)
    return ids

def report(ids):
    files={"before.svg","after.svg","compare.html","changes.diff","receipt.json"}
    if REPORT.exists():
        checked(not REPORT.is_symlink() and REPORT.is_dir() and set(p.name for p in REPORT.iterdir())==files,"기존 비교 폴더가 예상과 다릅니다.")
    else: REPORT.mkdir()
    for f in files:
        checked(not (REPORT/f).is_symlink(),"심볼릭 링크에 덮어쓰지 않습니다.")
    for name,c in zip(("before.svg","after.svg"),ids): (REPORT/name).write_bytes(git(REPO,"show",c+":figure.svg"))
    (REPORT/"changes.diff").write_bytes(git(REPO,"diff","--no-ext-diff","--no-textconv",*ids,"--","style_figure.py","figure.svg"))
    stat=git(REPO,"diff","--name-only",*ids).decode().splitlines()
    checked(set(stat)=={"figure.svg","style_figure.py"},"그림과 서식 코드 외의 파일이 바뀌었습니다.")
    (REPORT/"receipt.json").write_text(json.dumps({"branch":"main","commits":ids,"files":list(FILES),"changed":stat,"summary_unchanged":True},indent=2),"utf-8")
    page='''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>IBS 그림 수정 전후</title><style>body{font:17px system-ui;color:#172a33;margin:4vw auto;padding:0 1.25rem;max-width:1250px}main{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,27rem),1fr));gap:1.5em}figure{margin:0}img{width:100%}figcaption{margin:.75em 0;font-weight:bold}code{font-size:.82em}</style><h1>IBS 그림 수정 전후</h1><p>같은 합성 자료에서 0점선만 굵고 진하게 바꿨습니다. 군별 평균 변화량은 각각 40.82점, 49.23점으로 같습니다.</p><main>'''
    for label,src,c in zip(("수정 전","수정 후"),("before.svg","after.svg"),ids):
        page+='<figure><figcaption>'+label+' · <code>'+html.escape(c[:8])+'</code></figcaption><img src="'+src+'" alt="'+label+'의 합성 IBS 변화량 그림"></figure>'
    (REPORT/"compare.html").write_text(page+'</main><p><a href="changes.diff">두 커밋의 변경 내역</a></p></html>',"utf-8")

def main():
    ids=create_repo()
    report(ids)
    print("Git local practice complete: "+ " -> ".join(i[:8] for i in ids))
    print(str(REPORT/"compare.html"))
    print("Allowlisted files: "+", ".join(FILES))
if __name__=="__main__":
    try: main()
    except (ValueError,OSError,subprocess.CalledProcessError) as exc:
        print(str(exc),file=sys.stderr);sys.exit(1)
