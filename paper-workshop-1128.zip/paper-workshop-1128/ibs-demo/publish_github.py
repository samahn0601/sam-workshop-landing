"""Publish only the two validated synthetic IBS commits to a new, private GitHub repository."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import subprocess
import sys
import tempfile

BASE = Path(__file__).resolve().parent
REPO = BASE / 'git-practice'
STATE = BASE / '.github-workshop-state.json'
HOST = 'github.com'
class Stop(Exception): pass

def require(ok, msg):
    if not ok: raise Stop(msg)

def verified_head():
    spec = importlib.util.spec_from_file_location('git_practice', BASE/'git_practice.py')
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    commits = mod.verify_ready(REPO)
    require(len(commits)==2 and all(re.fullmatch(r'[a-f0-9]{40,64}', c) for c in commits),
            '실습용 커밋 두 개를 먼저 준비하세요.')
    return commits[-1]

def tool(name):
    exe = shutil.which(name)
    require(exe, ('GitHub CLI(gh)가 없습니다. https://cli.github.com 에서 설치한 뒤 '
                  'gh auth login --hostname github.com --web 으로 본인 계정에 로그인하고 다시 시작하세요.'
                  if name == 'gh' else 'Git을 설치한 뒤 같은 폴더에서 다시 시작하세요.'))
    return exe

def call(cmd, check=True):
    # Do not inherit other repo/worktree settings or enable verbose credential/network traces.
    env = {k:v for k,v in os.environ.items() if not k.upper().startswith(('GIT_', 'GCM_', 'GH_DEBUG'))}
    env.update({'GH_HOST':HOST, 'GH_PROMPT_DISABLED':'1','GH_NO_UPDATE_NOTIFIER':'1',
                'GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':os.devnull,'GIT_TERMINAL_PROMPT':'0',
                'GIT_NO_REPLACE_OBJECTS':'1','GIT_ALLOW_PROTOCOL':'https'})
    try:
        proc = subprocess.run(cmd,cwd=str(REPO),env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE,encoding='utf8',errors='replace',timeout=75)
    except (OSError,subprocess.TimeoutExpired):
        raise Stop('Git 또는 GitHub 연결이 완료되지 않았습니다. 연결을 확인한 뒤 같은 폴더에서 다시 시도하세요.') from None
    if check and proc.returncode:
        raise Stop('GitHub 작업을 마치지 못했습니다. 로그인·네트워크·저장소 쓰기 권한을 확인하세요.')
    return proc

def git(*args):
    return call([tool('git'),'-c','core.hooksPath='+os.devnull,*args]).stdout.strip()

def api(path, args=(), missing=False):
    p = call([tool('gh'),'api','--hostname',HOST,*args,path],False)
    if p.returncode:
        if missing and re.search(r'HTTP 404\b',p.stderr): return None
        if path == 'user':
            raise Stop('GitHub 로그인을 확인할 수 없습니다. 네트워크를 확인하고 gh auth login --hostname github.com --web 으로 본인 계정에 로그인하세요. 비밀번호나 토큰은 채팅에 붙여넣지 마세요.')
        if '422' in p.stderr: raise Stop('저장소를 새로 만들 수 없습니다. 같은 이름이 이미 있거나 계정 정책이 제한합니다. 기존 저장소는 변경하지 않았습니다.')
        raise Stop('GitHub API 확인에 실패했습니다. 연결 및 인증 계정의 권한을 확인한 뒤 재시도하세요.')
    try: return json.loads(p.stdout)
    except ValueError: raise Stop('GitHub 응답을 확인할 수 없어 중단했습니다.') from None

def state():
    if not STATE.exists(): return {}
    require(STATE.is_file() and not STATE.is_symlink(),'실습 확인 파일 경로가 예상과 다릅니다.')
    try: obj=json.loads(STATE.read_text(encoding='utf8'))
    except (OSError,ValueError):raise Stop('이전 업로드 확인 파일을 읽을 수 없습니다. 새 실습 폴더에서 시작하세요.') from None
    require(isinstance(obj,dict) and obj.get('format')==1,'이전 업로드 상태 형식이 다릅니다.')
    return obj

def record(obj):
    with tempfile.NamedTemporaryFile(mode='w',encoding='utf8',dir=BASE,delete=False) as f:
        json.dump(obj,f,indent=2); tmp=f.name
    os.replace(tmp,STATE)

def valid_name(s):
    require(isinstance(s,str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}',s),
            '저장소 이름은 영문 또는 숫자로 시작하고 영문·숫자·하이픈·밑줄만 사용하세요.')
    return s

def user():
    value=api('user'); owner=value.get('login'); num=value.get('id')
    require(isinstance(owner,str) and re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]{0,79}',owner)
            and type(num) is int and num>0,'개인 GitHub 계정을 확인하지 못했습니다.')
    return owner,num

def url(owner,name): return 'https://github.com/'+owner+'/'+name

def local_remote(owner,name,known):
    # Trust no extra remotes, multiple push URLs, includes, redirects/rewrite, hooks, or implicit mirror push.
    out=call([tool('git'),'config','--local','--no-includes','--name-only','--list']).stdout.lower().splitlines()
    require(not any(k.startswith(('url.','include.','includeif.','http.','credential.','filter.','protocol.','core.gitproxy','core.sshcommand','remote.origin.push','remote.origin.mirror','remote.origin.uploadpack','remote.origin.receivepack')) for k in out),
            '이 실습 저장소에 별도 전송 설정이 있어 중단했습니다.')
    refs=git('remote').splitlines()
    if not refs:return False
    require(known and refs==['origin'],'실습에서 등록하지 않은 remote가 있습니다. 다른 저장소에는 올리지 않습니다.')
    expected=url(owner,name)+'.git'
    require(git('remote','get-url','--all','origin').splitlines()==[expected] and
            git('remote','get-url','--push','--all','origin').splitlines()==[expected],'origin이 검증된 저장소와 다릅니다.')
    return True

def validate(meta,owner,uid,name,rid):
    require(isinstance(meta,dict) and meta.get('private') is True and meta.get('visibility','private')=='private'
            and str(meta.get('full_name','')).casefold()==(owner+'/'+name).casefold()
            and meta.get('owner',{}).get('id')==uid and type(rid) is int and rid>0 and meta.get('id')==rid
            and not meta.get('archived',False) and not meta.get('fork',False),
            'GitHub 계정·저장소 ID·비공개 상태가 확인되지 않아 중단했습니다.')

def plan(name=None):
    head=verified_head();owner,uid=user();prior=state()
    if prior.get('repo_id'):
        require(prior.get('uid')==uid and (name is None or prior['name']==name) and prior['head']==head,
                '이 실습에는 별도의 업로드가 등록되어 있습니다. 기존 계정과 폴더를 확인하세요.')
    name=valid_name(name or (prior.get('name') if prior.get('uid')==uid else None) or ('ibs-figure-workshop-'+secrets.token_hex(4)))
    rid=prior.get('repo_id');local_remote(owner,name,bool(rid))
    meta=api('repos/'+owner+'/'+name,missing=True)
    if rid:validate(meta,owner,uid,name,rid)
    else:require(meta is None,'그 이름의 저장소가 이미 있습니다. 기존 저장소는 사용하지 않습니다. 새 이름으로 미리보세요.')
    obj={'format':1,'owner':owner,'uid':uid,'name':name,'head':head,'repo_id':rid}
    record(obj);print('GitHub 계정: '+owner+'\n저장소: '+name+'\n공개 범위: 비공개(Private)\n커밋: 2개\n파일:')
    # Only list verified tracked paths present in the two known commits.
    names=set(git('ls-tree','-r','--name-only',head).splitlines()) | set(git('ls-tree','-r','--name-only',head+'^').splitlines())
    print('\n'.join('  '+n for n in sorted(names)));print('대상: '+url(owner,name))
    if rid:
        ref=api('repos/'+owner+'/'+name+'/git/ref/heads/main',missing=True)
        if ref and ref.get('object',{}).get('sha')==head:
            print('이 커밋은 이미 비공개 저장소에 올라가 있습니다.');return
    print('아직 업로드하지 않았습니다. 참가자가 이 계정·이름·파일의 업로드를 명시적으로 확인한 후 진행하세요.')

def publish(owner,name):
    name=valid_name(name);head=verified_head();prior=state();who,uid=user()
    require(prior.get('owner')==owner==who and prior.get('uid')==uid and prior.get('name')==name
            and prior.get('head')==head, '계정·이름·커밋에 맞는 사전 확인 기록이 없습니다. 먼저 미리보세요.')
    rid=prior.get('repo_id');has_origin=local_remote(owner,name,bool(rid));path='repos/'+owner+'/'+name
    meta=api(path,missing=True)
    if not rid:
        require(meta is None,'그 이름의 저장소가 이미 있습니다. 기존 저장소에는 업로드하지 않습니다.')
        meta=api('user/repos',['--method','POST','-f','name='+name,'-F','private=true','-F','auto_init=false'])
        rid=meta.get('id');validate(meta,owner,uid,name,rid);prior['repo_id']=rid;record(prior)
    validate(api(path),owner,uid,name,rid)
    # git ls-remote works for an empty repository, unlike some REST ref endpoints.
    address=url(owner,name)+'.git'
    transport=[tool('git'),'-c','core.hooksPath='+os.devnull,'-c','credential.helper=',
               '-c','credential.https://github.com.helper=!gh auth git-credential',
               '-c','http.followRedirects=false']
    listing=call(transport+['ls-remote','--refs',address]).stdout.strip()
    if listing:
        require(listing.split()==[head,'refs/heads/main'],'원격 저장소에 예상 밖 커밋이나 브랜치가 있어 중단했습니다.')
    else:
        require(verified_head()==head,'업로드 직전에 로컬 커밋이 달라졌습니다.')
        # Empty expected ref is an atomic create-only lease, never an overwrite of remote work.
        call(transport+['push','--no-follow-tags','--recurse-submodules=no','--force-with-lease=refs/heads/main:',
                        address,head+':refs/heads/main'])
    updated=api(path);validate(updated,owner,uid,name,rid)
    ref=api(path+'/git/ref/heads/main')
    require(updated.get('default_branch')=='main' and ref.get('object',{}).get('type')=='commit' and ref['object'].get('sha')==head,
            '원격 기본 브랜치와 커밋을 확인하지 못했습니다. 업로드 완료로 간주하지 마세요.')
    if not has_origin:git('remote','add','origin',address)
    print('GitHub 비공개 저장소와 main 커밋을 확인했습니다.\n'+url(owner,name)+'\n'+head)

def main():
    p=argparse.ArgumentParser();sub=p.add_subparsers(dest='action',required=True)
    sub.add_parser('preview').add_argument('name',nargs='?')
    send=sub.add_parser('publish');send.add_argument('owner');send.add_argument('name')
    args=p.parse_args()
    if args.action=='preview':plan(args.name)
    else:publish(args.owner,args.name)

if __name__=='__main__':
    try:main()
    except Stop as error:print(str(error),file=sys.stderr);sys.exit(2)
    except Exception as error:
        print('실습 저장소 또는 검증 기록을 확인하지 못했습니다 ('+type(error).__name__+'). 로컬 비교부터 다시 확인하세요.',file=sys.stderr)
        sys.exit(2)
