# Independent reference calculation. From ibs-demo: Rscript --vanilla verify.R
# Output to console only; the participant does not need R.
d <- read.csv("SYNTHETIC_IBS.csv", fileEncoding="UTF-8-BOM", na.strings=c("", "NA", "N/A"))
stopifnot(!anyDuplicated(d$synthetic_id), identical(sort(unique(d$synthetic_group)), 0:1))
change <- d$baseline_ibs_sss - d$week4_ibs_sss
out <- do.call(rbind, lapply(split(change, d$synthetic_group), function(x)
    c(n_included=sum(!is.na(x)), n_excluded=sum(is.na(x)), mean=mean(x, na.rm=TRUE), sample_sd=sd(x, na.rm=TRUE))))
print(out, digits=10)
p <- read.csv("output/patients.csv")
s <- read.csv("output/summary.csv")
stopifnot(identical(d$synthetic_id, p$synthetic_id), identical(d$synthetic_group,p$synthetic_group),
    isTRUE(all.equal(change, p$improvement, tolerance=1e-10)),
    identical(as.character(s$group), rownames(out)),
    max(abs(as.matrix(s[,colnames(out)]) - out)) < 0.000001)
cat("PASS: every participant and both groups agree.\n")
