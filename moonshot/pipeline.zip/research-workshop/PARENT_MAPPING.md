# What this teaching package retains

Source: Sam AI scientist active runtime d99965ec1cd6924b0993fa8a16e41026a1806c58, verified 2026-11-10. Existing student-collab/StatSam code provenance remains in its original files.

| Parent behavior | Teaching behavior / files |
|---|---|
| Scope, journal fit, research question before writing | templates/research-brief.md; own-topic scope review |
| Claim-evidence ledger, original-source support check | templates/claims.csv; walking output claims.csv |
| Code execution with traceable numbers | walking/compute_case.py, CSV, result.json, RUN_MANIFEST.json |
| Independent reviewer roles, evidence-based adjudication | review-decisions.csv; student-collab critic workflow; no majority vote |
| Preserve meaning after humanizing; post-edit checks | before/revision files; source/number check; lesson.py verify flags modified outputs |
| Final actual artifact check, journal packaging | generated DOCX text parity, hash-bound ZIP; finish.py for own-topic training |
| Browser use through submission and receipt | BROWSER_SUBMISSION.md + local practice; actual journal action needs an enabled agent and real authorization |
| Current materials → progress → decision → evidence → next request | workspace status and START_HERE prompts |

Parent Collab H1 idea / H2 first coauthor feedback / H3 critic decision / H4 second coauthor feedback / H5 final handoff differ from the student fork's five learning checkpoints. Do not import teaching state.json into the parent runtime.

The package is a selective teaching fork, not the full production pipeline. It contains no private manuscript, workspace, patient data, credentials or model account. Runtime environment hashes prove file identity, not scientific validity or real-world consent.
