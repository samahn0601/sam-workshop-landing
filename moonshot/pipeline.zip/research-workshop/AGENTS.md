# Student research workspace
Read START_HERE.md first. The user wants you to do the computer setup and file work, not give a long command tutorial.
Default to the walking teaching case, not the older quiz example. Use lesson.py doctor/demo/verify for a complete low-dependency demonstration.
Create new project folders without overwriting existing work. Ordinary file creation and reversible checks within the chosen folder are authorized by the setup request. Do not invent repetitive approval gates for such work.
Before interpreting a real dataset, establish question, study design, variable dictionary, analysis unit and permitted data use. Request missing scientific/author facts only when needed.
Separate actual code execution, fixed educational text, actual AI responses, user decisions and real journal status. Never invent user approvals, sources, findings, ethics approval or a submission receipt.
Keep evidence/claims and decisions as files. Show the student what changed, why, and the next decision. Ask them to predict or explain before displaying the answer when teaching.
For own-topic multi-step workflow, read student-collab/AGENTS.md and PARENT_MAPPING.md. The teaching H labels are not parent-runtime states. Optional StatSam bootstrap is your job when applicable; never request global manual Python installation first.
Submission operations follow the user's actual authorization and the real journal UI. Preparation, upload and confirmed submission are separate statuses. Stop repeating after ambiguous transmission and inspect the receipt/status.
