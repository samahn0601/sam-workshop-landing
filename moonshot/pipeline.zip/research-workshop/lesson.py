"""Reproducible teaching case. No LLM calls; all inputs are synthetic.

The desktop agent operates these files. Real research requires a separate plan.
"""
from pathlib import Path
import argparse, csv, hashlib, importlib.util, io, json, platform, sys, zipfile
from datetime import datetime, timezone
from xml.sax.saxutils import escape
from xml.etree import ElementTree as ET
ROOT=Path(__file__).resolve().parent
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_json(p,obj): Path(p).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def engine():
    spec=importlib.util.spec_from_file_location('walking_compute',ROOT/'walking/compute_case.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def outdir(): return ROOT/'workspace/walking-demo'
def docx(text, path):
    body=''.join('<w:p><w:r><w:t xml:space="preserve">'+escape(line)+'</w:t></w:r></w:p>' for line in text.splitlines())
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>')
        z.writestr('_rels/.rels','<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>')
        z.writestr('word/document.xml','<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'+body+'</w:body></w:document>')
def manuscript(c):
    return '\n\n'.join(['교육용 합성 자료: 걷기 앱 알림과 걸음수 변화','실제 연구·실제 저널 투고용 원고가 아닙니다.','방법',c['design']['question']+' '+c['design']['intervention']+' / '+c['design']['comparator']+'; 20명/군의 합성 자료.',c['analysis_plan']['primary_outcome']+'. '+c['analysis_plan']['uncertainty']+'.','결과',c['manuscript']['results_paragraph'],'논의',c['manuscript']['discussion_bounded'],'AI 사용 기록','배포 예시의 설명 문장은 AI 지원으로 작성 후 검토했다. 숫자는 동봉 코드를 실행해 계산했다. 학생 자신의 실행·수정·검토 내역은 별도 기록한다.'])
def demo():
    out=outdir()
    if out.exists(): return verify()
    m=engine();rows=m.read_csv(str(ROOT/'walking/synthetic_steps.csv'))
    if not m.selftest(False): raise ValueError('Statistics self-test failed')
    c=m.build_case(rows); expected=json.loads((ROOT/'walking/case.json').read_text(encoding='utf-8'))
    if c['primary_result']!=expected['primary_result']:raise ValueError('Teaching case changed; inspect inputs first')
    out.mkdir(parents=True)
    write_json(out/'case.json',c);write_json(out/'result.json',c['primary_result'])
    with (out/'table1.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['group','n','baseline_mean','followup_mean','change_mean','change_sd'])
        for g in c['groups'].values():w.writerow([g['label'],g['n'],g['baseline']['mean'],g['followup']['mean'],g['change']['mean'],g['change']['sd']])
    r=c['primary_result']; x=lambda v:100+(v+200)/1700*900
    lo,hi=r['ci95']; diff=r['mean_difference']
    ticks=''.join(f'<line x1="{x(v):.2f}" y1="170" x2="{x(v):.2f}" y2="180" stroke="#64736e"/><text x="{x(v):.2f}" y="210" text-anchor="middle">{v}</text>' for v in [0,500,1000,1500])
    svg=f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1100 300" role="img" aria-label="Synthetic mean difference and bootstrap confidence interval"><rect width="1100" height="300" fill="#faf8f2"/><g font-family="Arial,sans-serif" fill="#17323c" font-size="22"><text x="70" y="48">Synthetic case: change difference (notification - control)</text><line x1="{x(0):.2f}" y1="70" x2="{x(0):.2f}" y2="170" stroke="#93a4a0" stroke-dasharray="5 5"/><line x1="{x(lo):.2f}" y1="120" x2="{x(hi):.2f}" y2="120" stroke="#237c72" stroke-width="10"/><circle cx="{x(diff):.2f}" cy="120" r="13" fill="#17323c"/>{ticks}<text x="550" y="260" text-anchor="middle">+{diff:.1f} steps/day; 95% bootstrap CI {lo:.1f} to {hi:.1f}</text></g></svg>'''
    (out/'figure1.svg').write_text(svg,encoding='utf-8')
    (out/'results.md').write_text(c['manuscript']['results_paragraph']+'\n',encoding='utf-8')
    (out/'draft-before.md').write_text(c['manuscript']['discussion_inflated']+'\n',encoding='utf-8')
    (out/'revision.md').write_text(c['manuscript']['discussion_bounded']+'\n',encoding='utf-8')
    (out/'manuscript.md').write_text(manuscript(c)+'\n',encoding='utf-8')
    docx(manuscript(c)+'\n',out/'manuscript.docx')
    with (out/'claims.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['claim_id','claim','source','locator','verification','scope'])
        w.writerows([['C01','4주 변화량의 군 간 평균 차이 +809.0걸음','result.json','mean_difference / ci95','CODE_RECOMPUTED','교육용 합성 자료만'],['C02','실제 선행 연구는 일차의료 성인의 8주 스마트폰 앱 연구','https://pmc.ncbi.nlm.nih.gov/articles/PMC4073723/','Methods: study population and intervention','원문 대조가 필요한 외부 근거','대학생 알림 단독 효과의 증거가 아님'],['C03','알림이 모든 대학생의 건강을 개선한다','없음','걸음수 이외의 건강 결과는 측정하지 않음','REJECTED','측정·대상·기간을 넘어선 주장']])
    (out/'review-decisions.csv').write_text('id,issue,decision,reason\nR1,건강 개선으로 확대,수용,걸음수만 측정\nR2,효과가 지속될 것이라는 추정,수용,장기 추적 없음\nR3,유의하지 않게 바꿔야 한다,기각,검정 결과와 설명은 구분하며 수치는 근거 없이 바꾸지 않음\n',encoding='utf-8-sig')
    write_json(out/'submission-status.json',{'status':'NOT_SUBMITTED','real_research':False,'receipt':None,'note':'교육용 파일 묶음 생성만 완료. 아래 LOCAL_DEMO_RECEIPT는 브라우저 연습에만 사용한다.'})
    record={'status':'TEACHING_DEMO_EXECUTED','real_submission_ready':False,'real_journal_submission':False,'time_utc':datetime.now(timezone.utc).isoformat(),'python':platform.python_version(),'calculation':'Actual Python execution from bundled synthetic CSV','narrative':'Fixed educational text; not a live AI response','input_sha256':sha(ROOT/'walking/synthetic_steps.csv'),'code_sha256':sha(ROOT/'walking/compute_case.py'),'runner_sha256':sha(Path(__file__)),'outputs':{p.name:sha(p) for p in out.iterdir() if p.is_file()}}
    write_json(out/'RUN_MANIFEST.json',record)
    with zipfile.ZipFile(out/'teaching-package.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.iterdir()):
            if p.is_file() and p.suffix!='.zip':z.write(p,p.name)
    return verify()
def verify():
    out=outdir(); record=json.loads((out/'RUN_MANIFEST.json').read_text(encoding='utf-8'))
    for key,p in [('input_sha256',ROOT/'walking/synthetic_steps.csv'),('code_sha256',ROOT/'walking/compute_case.py'),('runner_sha256',Path(__file__))]:
        if sha(p)!=record[key]:raise ValueError('Input or code changed after execution: '+key)
    for name,digest in record['outputs'].items():
        if sha(out/name)!=digest:raise ValueError('Output changed after execution: '+name)
    m=engine(); c=m.build_case(m.read_csv(str(ROOT/'walking/synthetic_steps.csv')))
    if c['primary_result']!=json.loads((out/'result.json').read_text(encoding='utf-8')):raise ValueError('Recalculation mismatch')
    with zipfile.ZipFile(out/'manuscript.docx') as z:
        tree=ET.fromstring(z.read('word/document.xml'));ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        txt='\n'.join(''.join(t.text or '' for t in p.findall('.//w:t',ns)) for p in tree.findall('.//w:p',ns))
    if txt.splitlines()!=(out/'manuscript.md').read_text(encoding='utf-8').splitlines(): raise ValueError('DOCX text mismatch')
    with zipfile.ZipFile(out/'teaching-package.zip') as z:
        expected=set(record['outputs'])|{'RUN_MANIFEST.json'}
        if set(z.namelist())!=expected or any(z.read(n)!=(out/n).read_bytes() for n in expected):raise ValueError('Packaged files changed')
    return {'status':'VERIFIED','recalculated':True,'docx_text_parity':True,'package_integrity':True,'folder':str(out),'result':c['primary_result'],'real_journal_submission':False,'interpretation_requires_review':True}
def doctor():
    ROOT.joinpath('workspace').mkdir(exist_ok=True)
    return {'status':'READY' if sys.version_info>=(3,11) else 'PYTHON_UPGRADE_NEEDED','python':sys.version.split()[0],'case':'walking synthetic demo','dependencies':'Python standard library only','advanced_statsam':'separate optional setup','submission_status':'NOT_SUBMITTED'}
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('command',choices=['doctor','demo','verify']);a=p.parse_args()
    try:print(json.dumps(globals()[a.command](),ensure_ascii=False,indent=2))
    except (OSError,ValueError,KeyError) as exc:print(json.dumps({'status':'HOLD','error':str(exc)},ensure_ascii=False));sys.exit(2)
