"""Read the fixed synthetic workshop CSV. From the kit folder: python examples/SYNTHETIC_analyze.py
Dependencies: numpy, scipy, matplotlib. Writes example-run/ only; never regenerates data.
"""
from pathlib import Path
from datetime import datetime, timezone
import csv, json, hashlib, sys, platform
import numpy as np
import scipy
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

root=Path(__file__).resolve().parent.parent
src=root/'SYNTHETIC_IBS.csv'
out=root/'example-run';out.mkdir(exist_ok=True)
with src.open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
g,x,y=np.array([[float(r[k]) for k in ('synthetic_group','baseline_ibs_sss','week4_ibs_sss')] for r in rows]).T
assert len(set(r['synthetic_id'] for r in rows))==len(rows)==120
assert set(g)=={0.,1.} and int(sum(g))==60 and np.isfinite([g,x,y]).all()
assert ((x>=100)&(x<=450)&(y>=0)&(y<=500)).all()
X=np.column_stack([np.ones(len(y)),g,x]); b=np.linalg.lstsq(X,y,rcond=None)[0]
fit=X@b; residual=y-fit; df=len(y)-X.shape[1]
se=np.sqrt(np.linalg.inv(X.T@X)[1,1]*float(residual@residual/df))
t=stats.t.ppf(.975,df)
ci=[float(b[1]-t*se),float(b[1]+t*se)]
result=dict(dataset='SYNTHETIC',contrast='B-A',unit='points',n_A=int((g==0).sum()),n_B=int((g==1).sum()),
            estimate=float(b[1]),ci95=ci,p=float(2*stats.t.sf(abs(b[1]/se),df)))
(out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
with (out/'SYNTHETIC_table.csv').open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f);w.writerow(['dataset','group','n','baseline_mean','baseline_sd','week4_mean','week4_sd'])
    for group,label in [(0,'A'),(1,'B')]:
        m=g==group;w.writerow(['SYNTHETIC',label,int(m.sum()),x[m].mean(),x[m].std(ddof=1),y[m].mean(),y[m].std(ddof=1)])
fig,ax=plt.subplots(figsize=(7,4),layout='constrained')
for group,label,color in [(0,'A','#325a83'),(1,'B','#27807c')]:
    m=g==group;xx=np.array([x[m].min(),x[m].max()]);ax.scatter(x[m],y[m],s=16,alpha=.6,c=color,label=label)
    ax.plot(xx,b[0]+b[1]*group+b[2]*xx,c=color)
ax.set(title='SYNTHETIC: week 4 and baseline',xlabel='Baseline IBS-SSS (points)',ylabel='Week 4 IBS-SSS (points)');ax.legend()
fig.savefig(out/'SYNTHETIC_figure.png',dpi=140);plt.close(fig)
fig,ax=plt.subplots(1,2,figsize=(9,4),layout='constrained')
ax[0].scatter(fit,residual,s=12);ax[0].axhline(0,c='grey');ax[0].set(xlabel='Fitted score',ylabel='Residual (points)')
stats.probplot(residual,dist='norm',plot=ax[1]);fig.suptitle('SYNTHETIC: residual diagnostics')
fig.savefig(out/'SYNTHETIC_diagnostics.png',dpi=140);plt.close(fig)
record={'dataset':'SYNTHETIC','input':src.name,'input_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),
        'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'utc':datetime.now(timezone.utc).isoformat(),
        'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__}
(out/'SYNTHETIC_run_log.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps(result))
