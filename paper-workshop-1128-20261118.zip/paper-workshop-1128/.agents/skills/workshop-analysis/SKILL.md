---
name: workshop-analysis
description: 고정된 합성 IBS 자료를 분석하고 실제 결과와 의도된 오류를 검사할 때 사용한다.
---

SYNTHETIC_IBS.csv와 plan.md를 읽어. 기존 정답을 복사하지 말고 분석 코드를 작성해줘.
입력 파일은 바꾸지 마. A=0, B=1이고, 4주 점수를 집단과 기저 점수로 설명하는 선형모형이야.
B−A 보정 차이(점), 95% 신뢰구간과 p값을 구하고 표·그림·잔차 진단·실행 기록을 남겨줘.
02_분석_결과형식.md에 맞춰 my-results/result.json을 저장해줘. 코드와 표·그림에도 SYNTHETIC을 표시해줘.
같은 CSV로 다시 실행해 숫자가 일치하는지 확인해줘. 실행하지 못했다면 그 사실을 적어줘.

먼저 python check_result.py tests/SYNTHETIC_sign_error.json을 실행하고, 왜 실패했는지 설명해줘.
그다음 python check_result.py my-results/result.json을 실행해 두 결과를 비교해줘.
검사기·기준값·데이터는 수정하지 마. 내 결과가 다르면 코드 또는 결과 문장의 원인을 찾아줘.
최종적으로 실제로 확인한 파일과 남은 의문을 my-results/verification.md에 기록해줘.
