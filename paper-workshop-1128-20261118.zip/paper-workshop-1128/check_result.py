"""Check the fixed SYNTHETIC workshop result. Standard library only. Read-only."""
import json
import math
import sys
from pathlib import Path

def check(x):
    problems=[]
    if not isinstance(x,dict):return ['JSON object required']
    for k,want in [('dataset','SYNTHETIC'),('contrast','B-A'),('unit','points'),('n_A',60),('n_B',60)]:
        if x.get(k)!=want:problems.append(f'{k}: expected {want!r}, got {x.get(k)!r}')
    # Tolerances allow documented rounding; the target is this particular fixed CSV.
    def close(v,want,tol):
        return type(v) in (int,float) and math.isfinite(v) and abs(v-want)<=tol
    for k,want,tol in [('estimate',-6.13083005049,.0051),('p',.49260022374,.00051)]:
        if not close(x.get(k),want,tol):problems.append(f'{k}: expected {want:.4f}, got {x.get(k)!r}')
    ci=x.get('ci95')
    if not isinstance(ci,list) or len(ci)!=2 or not all(close(v,w,.0051) for v,w in zip(ci,[-23.7700181434,11.5083580424])):
        problems.append('ci95: expected approximately [-23.77, 11.51] points')
    return problems
if __name__=='__main__':
    try:
        obj=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8-sig'))
        issues=check(obj)
    except (IndexError,OSError,ValueError) as e:
        print(f'ERROR: {e}');sys.exit(2)
    print('FAIL | '+'; '.join(issues) if issues else 'PASS | fixed SYNTHETIC workshop result matches')
    sys.exit(int(bool(issues)))
