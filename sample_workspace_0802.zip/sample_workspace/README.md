# sample_workspace

기초 실습①·②(`PROMPT_CARD.md`)에 쓰는 교육용 가상 데이터 폴더. 강의노트 3종(`notes_*.md`)과 가상 성적표(`study_scores.csv`) 모두 실제 인물·환자정보를 포함하지 않는다.

`case_presentation/` — 🅱 트랙 케이스 발표 모드용: 가상 증례(`case_virtual_01_pneumonia.md`) + 발표 골격(`case_template.md`). 전부 창작된 교육용 시나리오이며, 실제 환자 증례는 절대 입력하지 않는다.
