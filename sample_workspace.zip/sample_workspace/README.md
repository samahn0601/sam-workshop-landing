# sample_workspace

기초 실습①·②(`PROMPT_CARD.md`)에 쓰는 교육용 가상 데이터 폴더. 강의노트 3종(`notes_*.md`)과 가상 성적표(`study_scores.csv`) 모두 실제 인물·환자정보를 포함하지 않는다.
