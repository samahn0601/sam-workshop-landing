---
name: start-here
description: >-
  논문 작업의 진입점이자 길잡이(내비게이터). 10단계 지도와 강사 호칭 대응표를 보여주고
  "㉮ 전체 코스"와 "㉯ 골라 타기" 중 방식을 정한 뒤 안내한다. 참가자는 언제든 멈추거나
  건너뛰거나 다른 단계로 갈 수 있고, 진행 위치는 .sam/pipeline_state.json에 저장돼 다음
  세션에서 이어진다. Trigger when the user starts a paper or workshop session, asks
  "어디서부터 / 시작하자 / 논문 쓰자 / 지금 어느 단계지", or is unsure which skill to
  use first. Do not use for a specific stage task — call that stage's skill directly
  (journal-fit-check, verify-reference-essential, critic-multi-persona 등). Input:
  paper_home (신규 또는 진행 중) + (선택) .sam/hitl/paper_profile.json,
  .sam/pipeline_state.json. Output: .sam/hitl/gate_plan.json,
  .sam/pipeline_state.json + 참가자가 고른 단계 진입. Pipeline position: 진입점 /
  전체 10-step 내비게이션. Medical context: 안전 게이트 5개(학습 끄기·환자 데이터·인용
  실재 확인·제출은 사람·의학적 판단)와 Medical Safety·Publication Ethics·⑧⑨ floor는
  방식과 무관하게 강제 — 다만 경고하고 진행하지, 거절하지는 않는다. Trigger keywords:
  시작, 시작하자, 워크숍 시작, 논문 시작, 논문 쓰자, 어디서부터, 어디부터, 처음,
  진입점, 파이프라인 시작, 운전 모드, start, start here, begin, get started,
  kick off, where to start.
---

# start-here — 논문 파이프라인 진입점 (10-step 내비게이터)

> 논문 세션의 **첫 발화 진입점**. 한 번 부르면 (1) 10단계 지도와 강사 호칭 대응표를 보여주고 → (2) 방식(㉮ 전체 코스 / ㉯ 골라 타기)을 정하고 → (3) `gate_plan.json`·`pipeline_state.json`을 만든 뒤 → (4) 참가자가 고른 단계로 안내한다. 참가자가 개별 skill 이름을 몰라도 흐름을 탄다.
>
> ⚠️ **"끝까지 무인 자동"이 아니다.** Claude Code에서 skill은 확정적 워크플로 엔진이 아니라 모델이 자연어나 Skill tool로 트리거하는 비결정적 구조다. 그래서 start-here는 **각 단계를 안내하는 내비게이터**이며, 참가자가 원하지 않으면 다음 단계로 넘어가지 않는다. "정지 없이 진행"은 검토 생략이 아니다.

## 🚦 가장 중요한 원칙 — 참가자가 운전한다

**순서는 권장이지 강제가 아니다.** 참가자는 언제든 다음을 할 수 있다.

- **멈춘다** — "그만", "여기까지", "잠깐" 하면 즉시 멈추고 현재 상태만 요약한다. 다음 단계로 밀어붙이지 않는다.
- **건너뛴다** — "④는 됐고 ⑤부터" 하면, 앞 단계 산출물이 없을 때 **무엇이 없는지 알려주되 하겠다면 그대로 진행**한다.
- **골라 탄다** — 필요한 단계 하나만 쓰고 끝내도 된다. 전체 코스를 완주할 의무가 없다.
- **되돌아간다** — 이전 단계로 돌아가 다시 할 수 있다.
- **오늘 안 끝내도 된다** — 시간이 모자라면 "여기까지 하고 이어서 하시면 됩니다"라고 말한다. 상태는 저장돼 있다.
- **구조를 바꾼다** — 단계나 검토 강도가 안 맞으면 함께 고친다(아래 ⚙ 절).

다음은 하지 않는다.

- ❌ **"먼저 ○○을 하셔야 합니다"라며 요청을 거절하는 것.** 전제가 빠졌으면 알리고 진행한다.
- ❌ 참가자가 멈추라고 했는데 다음 단계를 계속 제안하는 것.
- ❌ 시간을 압박하는 것. "서둘러야 합니다", "시간이 없으니" 같은 말을 하지 않는다.

## 🎯 완주가 목적이 아니다 — 지도와 함께 먼저 말한다

지도를 보여줄 때 **반드시 이 말을 함께** 한다.

> **오늘 목표는 논문 한 편을 완성해서 나가는 것이 아닙니다.**
> 흐름(워크플로우·파이프라인)을 이해하시고, 도구 활용을 익히시고,
> **이 폴더를 그대로 가져가서 이어가시면 됩니다.**
> 그리고 마음에 안 드는 부분은 **직접 고치실 수 있습니다.**

"오늘 안엔 안 됩니다", "불가능합니다" 같은 단정적 표현을 쓰지 않는다. *"오늘 목표는 완성이 아닙니다"* 로 충분하다.

## 언제 부르나

- 새 `paper_home`에서 논문을 시작할 때 ("시작하자", "어디서부터 할까")
- 진행 중 세션을 다시 열어 "지금 어느 단계지?"를 물을 때 (`.sam/pipeline_state.json` 참조해 이어감)
- 특정 단계 작업은 이 skill이 아니라 **해당 단계 skill을 직접** (journal-fit-check, verify-reference-essential, critic-multi-persona 등)

## 절차

### 0) 현재 상태 파악

- `.sam/pipeline_state.json`의 `current_step` 확인 → 있으면 *"지난번 ④까지 하셨습니다. 이어서 할까요, 다른 걸 할까요?"* 로 시작하고, 없으면 신규로 시작한다.
- `.sam/hitl/paper_profile.json` 있으면 로드(없으면 Step 1에서 함께 작성).
- 진행 위치는 각 단계가 끝날 때마다 `.sam/pipeline_state.json`에 저장한다(없으면 만든다).

```json
{"current_step": 4, "current": "④ Draft", "done": [1, 2, 3], "mode": "골라타기", "updated": "YYYY-MM-DDTHH:MM"}
```

### 1) 10단계 지도 + 강사 호칭 대응표

`${CLAUDE_SKILL_DIR}/../_shared/templates/pipeline_map.md`의 10-step 맵과 운전 모드 표를 보여준다. (변수 미확장 시 Claude가 절대경로로 치환)

```
작성 ①Idea → ②Research → ③Story → ④Draft → ⑤Verify ★ → ⑥Critic ★ → ⑦Package
제출·리뷰·마무리   ⑧Submission → ⑨Review → ⑩Wrap
```

- **★ ⑤ 인용 검증과 ⑥ 심사자 비평은 건너뛰지 않기를 권한다**(가짜 인용과 자기 논문의 약점은 스스로 보이지 않는다). 다만 건너뛰겠다면 막지 않는다.
- 지도의 동그란 번호는 **이 팩의 Step 번호**다. 강사가 부르는 이름과는 아래처럼 대응한다.

| 강사가 부르는 이름 | 이 팩의 단계 |
|---|---|
| ① 주제·저널 | Step 1 (Idea Lock) |
| ② 문헌(딥리서치) | Step 2 (Deep Research) |
| ③ 근거·개요 | Step 3 (Story & Outline) |
| ④ 초안 | Step 4 (Draft) |
| ⑤ 인용 검증 ★ | Step 5 (Verify) |
| ⑥ 심사자 비평 ★ | Step 6 (Critic) |
| ⑦ 투고 전 점검 | Step 7 (Humanize & Package) |
| ⑧ 리뷰 대응 | Step 9 (Review Response) |

- **Step 8(투고 워크시트)과 Step 10(마무리)은 이 팩에만 있는 뒷단이다** — 강사 호칭에는 대응하는 번호가 없으니, 물어보면 "투고 준비와 마지막 최종 확인 단계"라고 한 줄로 설명한다.

### 2) 방식 묻기 — 딱 이 두 가지만

> **어떻게 하시겠어요?**
> **㉮ 전체 코스** — Step 1부터 순서대로 안내받기 (처음이면 이쪽)
> **㉯ 골라 타기** — 지금 필요한 것만. 어느 단계가 필요하신가요?
>
> 어느 쪽이든 **중간에 멈추거나 다른 단계로 갈 수 있습니다.**

답이 없으면 **㉮로 시작하되 "언제든 바꿀 수 있다"고 한 번 알린다.** 방식을 캐묻지 않는다. 고른 방식은 `pipeline_state.json`의 `mode`에 적는다.

### 3) 검토 강도(gate_plan) — 기본값으로 두고, 물으면 고친다

검토를 얼마나 자주 받을지는 `.sam/hitl/gate_plan.json`이 정한다. **모드를 캐묻느라 시간을 쓰지 않는다** — 기본값 🛡️표준(H3, 정차 ①⑤⑥⑩)으로 만들고, 참가자가 "너무 자주 물어본다" 또는 "좀 더 자동으로"라고 하면 `hitl-dial-recommender`로 조절한다.

**반드시 아래 형식(`gate_plan.schema.json` 준수)을 그대로 따른다** — 🛡️표준(H3) 예시를 복사해 필요한 부분만 바꾸고, `stops`·`selected_by` 같은 임의 필드는 만들지 않는다:

```json
{
  "preset": "standard", "dial": "H3",
  "medical_floor_override": true, "publication_ethics_floor": true, "submission_review_floor": true,
  "soft_floor_steps": [1, 10],
  "steps": [
    {"n": 1, "name": "Idea Lock", "mode": "review", "locked_reason": "soft floor + Self-Gate A"},
    {"n": 2, "name": "Deep Research", "mode": "auto"},
    {"n": 3, "name": "Story & Outline", "mode": "auto"},
    {"n": 4, "name": "Draft", "mode": "auto"},
    {"n": 5, "name": "Verify", "mode": "review", "locked_reason": "Self-Gate B"},
    {"n": 6, "name": "Critic", "mode": "review", "locked_reason": "Self-Gate C"},
    {"n": 7, "name": "Humanize & Package", "mode": "auto"},
    {"n": 8, "name": "Submission", "mode": "review", "locked_reason": "Submission floor (사람)"},
    {"n": 9, "name": "Review Response", "mode": "review", "locked_reason": "Review floor (사람)"},
    {"n": 10, "name": "Wrap & Next", "mode": "review", "locked_reason": "soft floor + Human Final Gate"}
  ]
}
```
> ⚡ 시간절약 = `preset:"light"`·`dial:"H2"`·정차 ①⑤⑩(⑥ Critic도 `"auto"`). 🚗 전체정차 = 전부 `"review"`. 기본값 🛡️표준(H3).

**방식을 정한 직후 책임 배너 1회**:
> AI는 초안을, 저자는 책임을 집니다. 정차하지 않은 단계도 마지막 요약에서 반드시 확인합니다. (전체 배너 = `pipeline_map.md`)

참가자가 "그만"이라고 하면 gate_plan보다 **참가자 말이 우선**이다.

### 4) 매 단계 종료 훅 (반드시 이 3줄로 마무리)

```
✅ [한 일] — [산출물 파일]
다음 추천: [단계]   ·   다른 걸 하셔도 됩니다
멈추려면 "그만", 다른 단계는 그 이름을 말씀하세요
```

- 참가자가 **"다음"** 하기 전엔 다음 단계로 넘어가지 않는다(정차든 진행이든 동일). 자동으로 다음 skill을 부르지 않는다.
- "다음" 입력 시 다음 단계 skill을 Skill tool로 호출한다. **호출이 불확실하면 멈추지 말고** *"`/[skill-name]` 을 입력하세요"* 로 정확한 명령을 제시(참가자가 막히지 않게).
- gate_plan의 정차(`review`) 단계에선 [승인/수정/계속]을 명시적으로 받는다. `auto` 단계에서도 **종료 훅 3줄은 그대로 출력**한다(어디까지 왔는지는 항상 보이게).

| Step | 단계 skill / 도구 | 정차 |
|---|---|---|
| ① Idea Lock | journal-fit-check | ✋ Self-Gate A |
| ② Deep Research | **Browser pane 딥리서치**(↓ 아래 절) + reporting-guideline-router | 진행 |
| ③ Story & Outline | evidence-harvest-claim-bank → story-design | 진행 |
| ④ Draft | (Code 탭 파일 편집) + section-boundary | 진행 |
| ⑤ Verify | verify-reference-essential + stats-consistency | ✋ Self-Gate B |
| ⑥ Critic | critic-multi-persona + scorecard-9d | ✋ Self-Gate C |
| ⑦ Humanize & Package | humanize-ko/en + desk-reject-precheck (figure-prompt-eng 옵션) | 진행 * (자동 점검 → ⑩서 최종 확인) |
| ⑧ Submission | 🔒 **사람 주도** — submission worksheet 작성 + 포털 강사 데모 | floor (사람) |
| ⑨ Review Response | 🔒 **사람 주도** — 가상 reviewer fixture → response matrix (revision-response 보조) | floor (사람) |
| ⑩ Wrap & Next | hitl-dial-recommender → 🔒 Human Final Gate + 다음 dial | ✋ Human Final Gate |

\* ⑦의 AI 공개문·cover letter는 표준 정차는 아니지만 **Publication Ethics floor**로 어떤 방식이든 저자가 확인한다.
(+ Bonus 병행: **exam-item-builder** = 점심 백그라운드 + Bonus 트랙)

## 📚 Step 2 문헌 딥리서치 — Browser pane으로

> 딥리서치를 *실행*하는 별도 skill은 없다. **네(에이전트)가 Code 탭의 내장 브라우저(Browser pane)를 열어 claude.ai에서 연구 기능을 직접 돌리고 결과를 파일로 저장한다.** 참가자에게 단계를 떠넘기지 말고 **"제가 돌려드릴까요?"** 로 먼저 제안한다.
>
> 이 단계를 빠뜨리면 `02_research/deep_research.md`가 비어, 다음 단계 `evidence-harvest-claim-bank`가 **기억에 의존한 인용(= 날조 참고문헌·desk reject)** 으로 빠진다. 건너뛸 거면 그 위험을 한 줄로 알린다.

### 네가 직접 하는 것 (기본 경로)

1. **Browser pane을 열고** `claude.ai` 로 간다. (Windows `Ctrl+Shift+B` · macOS `Cmd+Shift+B`, 또는 Views 메뉴에서 선택. 같은 키를 다시 누르면 닫힌다. 포커스된 패널 닫기는 Windows `Ctrl+\` · macOS `Cmd+\`)
2. **로그인이 안 돼 있으면 거기서 멈추고 참가자에게 로그인을 요청한다.** 🔒 **비밀번호는 절대 대신 입력하지 않는다** — 사람이 직접 한다.
   - ⚠️ Browser pane은 **개인 브라우저와 분리된 깨끗한 프로필**을 쓴다. 저장된 로그인이 없으므로 **이 창에서 따로 로그인해야 한다**고 안내한다(외부 사이트 로그인은 이 창에서 가능하다).
3. 새 대화에서 **연구(Research) 기능을 켠다.** (연구 기능은 유료 플랜에서 제공된다)
4. 참가자의 연구질문을 넣어 아래를 **그대로 입력·실행**한다:
   ```
   [연구질문]의 핵심 문헌을 찾아줘. 출처마다 저자·연도·저널·DOI(또는 PMID)·핵심 결과(가능하면 원문 1줄 인용)·한계를 정리하고, 최신 가이드라인·체계적 고찰·반박 근거도 포함해줘. 확인 가능한 인용만 — 출처 없는 일반론은 제외.
   ```
   (범위가 넓으면 주제·PICO별로 2~3회 나눠 돌린다)
5. **연구는 몇 분에서 수십 분 걸린다. 중간에 포기하지 말고** 끝날 때까지 기다리며, 가끔 진행 상황을 한 줄로 알린다.
6. 결과가 나오면 **화면 내용을 그대로** 읽어 `paper_home/02_research/deep_research.md` 에 저장한다.

### 🔒 옮겨 적을 때의 철칙

- **요약하거나 줄이지 않는다.** 저자·연도·저널·DOI/PMID는 **원문 그대로** 옮긴다.
- **네가 아는 지식으로 보충하지 않는다. 화면에 있는 것만 저장한다.**
  → 이 줄이 없으면 전사 과정에서 **없던 인용이 섞여 들어간다.** 가장 위험한 실패다.
- 화면에서 못 읽은 부분이 있으면 **"여기는 확인 못 함"** 이라고 표시한다. 메워 넣지 않는다.

### 막힐 때 — 사다리

| 상황 | 이렇게 |
|---|---|
| 로그인 안 됨 | 멈추고 참가자에게 로그인 요청 (비밀번호 대리 입력 금지) |
| 브라우저 조작 **권한 거부** | 참가자가 직접 연구를 돌리게 하고, 끝나면 **"결과 가져와줘"** 로 화면만 읽어 저장 |
| 브라우저 조작이 아예 안 됨 | 참가자가 **결과를 복사해 붙여넣게** 한다 — **결과는 같다.** 여기서 멈추지 않는다 |
| 그 외 | **Claude in Chrome** 확장이 있으면 그것으로 진행한다(기존 로그인 세션을 그대로 쓴다) |

- ⚠️ **Claude는 채팅과 Code 탭이 같은 사용량 한도를 쓴다** — 연구 기능도 그 한도를 소모한다. 한도가 걱정되면 연구 횟수를 나누어 쓰도록 안내한다.
- 🔵 다른 회사 모델을 붙이는 방법은 **워크숍 페이지의 병용 트랙 안내**를 따른다.
- ⚠️ 어느 경로로 모았든 **모든 인용은 Step 5 `verify-reference-essential`로 실재 확인**한다. 기억에 의존한 인용을 만들지 않는다.
- 같은 단계에서 **`reporting-guideline-router`**로 연구설계에 맞는 보고지침(CONSORT/STROBE/PRISMA 등)을 라우팅한다.

수집이 끝나면 → **Step 3 `evidence-harvest-claim-bank`** 로 주장·출처 대장을 만든다.

## ⚙ 도구가 안 맞으면 — 함께 고친다

참가자가 **"이 스킬 별로다", "내 연구엔 이게 안 맞는다", "이 단계는 필요 없다"** 고 하면 **그게 가장 좋은 순간이다.** 얼버무리거나 넘기지 말고 바로 안내한다.

- **skill은 결국 마크다운 한 장이다.** 그렇게 말해준다. 마법이 아니라는 걸 아는 게 핵심이다.
- 이 팩에서 도구를 고치는 skill은 **`hitl-dial-recommender`(검토 강도 조절)** 하나다. "너무 자주 물어본다", "좀 더 자동으로"는 여기로 보낸다.
- 그 밖의 요청("이 스킬이 별로다", "이 단계는 필요 없다", "순서를 바꾸고 싶다")은 skill을 갈아 끼우는 별도 도구 없이 **함께 고친다** — 해당 `SKILL.md` 또는 `.sam/hitl/gate_plan.json`을 열어 **수정안을 diff로 보여주고 승인을 받은 뒤** 바꾼다.
- **파이프라인도 완성품이 아니라 참가자의 초안이다.**

> ⚠️ 무엇을 바꾸든 **차이(diff)를 먼저 보여주고 승인을 받는다. 자동으로 바꾸지 않는다.**

## 🔒 안전선 (방식과 무관하게 강제)

1. **학습 끄기** — 개인 Claude 계정은 **claude.ai 설정의 개인정보 항목에서 모델 학습 허용을 끈다**(설정 경로 `claude.ai/settings/data-privacy-controls`). 메뉴 이름은 **화면 기준으로 한 번 더 확인**한다. Team·Enterprise 좌석에는 이 개인 설정 항목이 해당하지 않는다.
2. **환자 데이터 금지** — 식별 가능한 환자 정보는 **IRB 승인을 받은 연구 데이터여도** 실습 폴더에 넣지 않는다. 발견하면 즉시 중지하고 알린다.
3. **인용 실재 확인** — 어떤 경로로 모았든 모든 인용은 Step 5 `verify-reference-essential`로 확인한다. 거치지 않은 인용은 "미검증"으로 표시한다.
4. **제출은 사람이** — 저널 포털 로그인·제출 버튼·실제 심사 원문은 참가자 본인이 한다. 워크숍 산출물은 **submission-directed이지 submission-ready가 아니다.**
5. **의학적 판단** — 약물 용량·상호작용, IRB·윤리, 임상 가이드라인 관련 서술은 멈추고 저자 확인을 받는다.

이 다섯은 "㉯ 골라 타기"에서도, gate_plan이 `auto`여도 해제되지 않는다. 다만 **경고하고 진행**하지, 작업을 거절하지는 않는다.

추가로 아래 floor는 gate_plan보다 우선한다.

- 🔒 **Medical Safety** — 약물 용량·상호작용, IRB·윤리·환자동의, 임상 가이드라인 변경, R6(mortality/safety/guideline claim) → 강제 정차.
- 🔒 **Publication Ethics** — AI 활용 공개문·authorship·COI·IRB/ethics·data availability·저널 정책 불일치 → 강제 정차.
- 🔒 **⑧ Submission · ⑨ Review** — 포털 자격증명·로그인·Submit 버튼·실제 reviewer 원문은 사람이 수행. 실제 제출은 **⑩ Human Final Gate** 통과 후 본인이 누른다.

## 출력

- `.sam/pipeline_state.json` (현재 위치·방식)
- `.sam/hitl/gate_plan.json` (검토 강도)
- 참가자가 고른 단계로 진입 (㉮면 Step 1 `journal-fit-check`)

## HITL Event Emit

세션 시작 직후 `.sam/hitl/events.jsonl`에 1줄 append:
```json
{"ts":"...","step":0,"event_type":"session_start","skill":"start-here","engine":"claude","category":"orchestration","severity":1,"description":"workshop session started, mode=H3 standard"}
```

## 자주 발생하는 함정

1. **방식을 캐묻다 시간을 쓴다** — 한 번 묻고 답이 없으면 ㉮로 시작한다. 검토 강도는 기본값 🛡️표준(H3)으로 두고 나중에 고친다.
2. **참가자가 멈췄는데 계속 제안한다** — "그만"은 진짜 그만이다.
3. **전제가 없다고 거절한다** — 알리고 진행한다. 거절은 이 워크숍에서 가장 나쁜 실패다.
4. **딥리서치를 건너뛴다** — Step 2가 비면 Step 3이 기억에 의존한 인용으로 빠진다. 건너뛸 거면 그 위험을 한 줄로 알린다.
5. **⑧⑨를 자동으로 넘긴다** — Submission/Review는 floor라 어떤 방식이든 사람이다. 가상 fixture·worksheet로 연습하고 실제 제출은 하지 않는다.
6. **개별 단계 재작업 시 start-here 재호출** — 특정 단계만 다시 할 땐 해당 skill을 직접 부른다(여긴 진입·이어가기 전용).

## 다음 단계

→ 방식이 정해지면 참가자가 고른 단계로 진입한다. ㉮ 전체 코스면 **Step 1 `journal-fit-check`**부터, ㉯ 골라 타기면 참가자가 말한 단계부터. 이후 각 단계는 gate_plan대로 정차·진행하며, 원한다면 **⑩ Wrap(Human Final Gate)**까지 이어간다. 언제 멈추든 상태는 `.sam/pipeline_state.json`에 남는다.
