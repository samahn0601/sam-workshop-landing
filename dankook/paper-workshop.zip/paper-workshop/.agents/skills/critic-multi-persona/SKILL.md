---
name: critic-multi-persona
description: >-
  투고 전 원고를 심사자 관점으로 비평한다. 방법론·통계·논리·구조의 약점을 서로 독립된 블라인드 리뷰어 3인으로 지적하고 수정 목록을 만든다. 사용: "리뷰어처럼 봐줘", "약점 찾아줘", "심사자 시각", "비평해줘". 사용 안 함: 인용 검증, 문장 다듬기.
---

> **라우팅·입출력 정보(원본 description 이관)** — Codex는 skill을 선택한 뒤 이 본문 전체를 읽으므로, 목록 예산을 쓰지 않고도 아래 정보가 그대로 유효하다.
>
> Use this skill when a medical manuscript draft needs reviewer-style critique before submission: methodology weakness, statistics/logic issues, structure problems, and reward-hacking risk. Implemented as a blind three-reviewer panel (R1 methods, R2 statistics/logic, R3 harsh desk editor) run in separate fresh contexts, plus an optional cross-vendor critic, integrated by an Area Chair persona. Trigger when user says "critic", "리뷰어 시각", "심사자처럼 봐줘", "weakness 점검", "area chair", "전문가 비평", "peer review simulation", or operates in Step 6 Multi-Engine Critic of the sam-workshop pipeline. Do not use for reference verification (use verify-reference-essential) or grammar polish (use humanize-en/ko). Input: paper_home/04_draft/manuscript.md (and post-Step-5 verify reports + journal_shortlist.md). Output: paper_home/06_critic/{reviewer_R1.md, reviewer_R2.md, reviewer_R3.md, external_critic.md (optional), area_chair_round1.md, revision_backlog.jsonl}. Pipeline position: sam-workshop Step 6 / Self-Gate C. Medical context: ICMJE manuscript critique standards, RH1-RH4 reward-hacking defense, blind reviewer independence within a single vendor. Trigger keywords: critic, 리뷰어, 비평, peer review, area chair, weakness, reviewer, critique.

# critic-multi-persona (Step 6)

> 블라인드 3인 리뷰 + Area Chair 통합. 리뷰어 셋을 각각 새 컨텍스트에서 원고만 보고 읽게 하고, 통합은 Area Chair가 한다.

## 블라인드 원칙

리뷰어 세 명(R1 방법론 리뷰어, R2 통계·논리 리뷰어, R3 가혹한 데스크 에디터)은 **각각 새 컨텍스트**에서 실행한다. 각 리뷰어에게 주는 입력은 원고 파일과 필요한 참고 파일(저널 후보 파일, 검증 인증서)뿐이다. 초안을 작성한 대화 내용과 다른 리뷰어의 결과는 보여주지 않는다.

이렇게 하는 이유는 두 가지다. 같은 대화 안에서 페르소나만 바꾸면 초안을 쓸 때 세운 전제와 표현이 문맥에 남아 리뷰어 셋이 같은 맹점을 그대로 공유한다. 그리고 모델은 자기가 방금 쓴 글에 관대해져서, 원고를 처음 보는 심사자라면 곧바로 잡아낼 약점을 그냥 지나친다.

리뷰어에게 넘기지 않는 것을 못박아 둔다. 초안 작성 대화, 이전 라운드 비평, 다른 리뷰어의 산출 파일, Area Chair의 지시는 모두 제외한다.

## 실행 강도

- 모델은 **현재 플랜에서 선택 가능한 가장 상위 모델**로, 추론 강도는 **가장 높음**으로 올린다. 약점 탐지는 추론 깊이가 결과를 그대로 바꾸는 단계다.
- 비평이 끝나면 평소 설정으로 되돌린다. 전 과정에서 이 단계만 무겁게 쓴다.
- 구독 티어별 구체 설정(모델 선택·추론 강도·사용량 주의)은 워크숍 페이지의 설정 표를 따른다.

## 모드 · 시간 예산

| 모드 | 시간 | 구성 |
|---|---|---|
| `workshop-mini` | 25분 | 블라인드 3인 리뷰(병렬) + AC 통합 + 저자 판정 |
| `standard` | 45분 | + RH1–RH4 전수 체크, 교차 벤더 비평 1회 |
| `deep-audit` | 70분+ | + 저널-specific mock review, 2라운드 |

`workshop-mini` 기준 단계별 예산은 아래와 같다. 병렬 실행이면 리뷰 3건이 동시에 끝나므로 Phase 1이 짧아진다.

| 단계 | 병렬 실행 | 순차 폴백 |
|---|---|---|
| Phase 1 블라인드 3인 리뷰 | 10분 (동시) | 20분 (각 6~7분) |
| Phase 2 교차 벤더 비평 (선택) | 10분 | 10분 |
| Phase 3 Area Chair 통합 | 10분 | 10분 |
| Phase 4 Self-Gate C 저자 판정 | 5분 | 5분 |

## 리뷰어 구성

| 리뷰어 | 시각 | 출력 | 산출 파일 |
|---|---|---|---|
| **R1: 방법론 리뷰어** | 연구 설계, 표본, 교란, 일반화 가능성 | top 3 weakness | `06_critic/reviewer_R1.md` |
| **R2: 통계·논리 리뷰어** | 통계 보고, 논증 흐름, 인과관계 비약 | top 3 issue | `06_critic/reviewer_R2.md` |
| **R3: 가혹한 데스크 에디터** | 데스크 리젝 사유, novelty, 임상 함의, 저널 fit | 리젝 사유 + top 3 strategic comment | `06_critic/reviewer_R3.md` |
| (선택) **교차 벤더 비평** | 다른 회사 모델의 외부 시각 | top 5 issue | `06_critic/external_critic.md` |
| **Area Chair** | 통합, RH1–RH4 reward hacking 체크 | Must Fix / Should Fix / Optional | `06_critic/area_chair_round1.md` |

## 입력

- `paper_home/04_draft/manuscript.md` (리뷰어 셋 공통 · 필수)
- `paper_home/05_verify/verification_certificate.md` (Step 5 통과 확인)
- `paper_home/03_outline/story_1pager.md` (편집 ↔ 본문 일관성 체크)
- `paper_home/01_design/journal_shortlist.md` (있으면, R3가 Scope fit·Fit verdict·Reject risk 반영)

리뷰어에게 실제로 첨부하는 것은 원고와 위 참고 파일뿐이다. R3에는 `journal_shortlist.md`를 함께 넘기고, R1·R2에는 원고와 검증 인증서만 넘긴다.

## 실행 방식

위에서부터 되는 경로를 쓴다. 사용자에게는 한 문장으로 설명한다. **"리뷰어 세 명을 각각 새 대화에서 따로 읽게 합니다."**

### (a) 웹 대화 3개: ChatGPT Pro 구독자

에이전트가 인앱 브라우저를 직접 조작한다. 참가자에게 단계를 떠넘기지 말고 **"제가 돌려드릴까요?"** 로 먼저 제안한다.

1. 시작 전에 원고에 환자 식별정보가 없는지 확인한다. 있으면 멈추고 알린다.
2. 인앱 브라우저를 열고 `chatgpt.com` 으로 간다.
3. 🔒 **로그인은 사람이 한다. 비밀번호는 절대 대신 입력하지 않는다.** 로그인이 안 돼 있으면 거기서 멈추고 참가자에게 요청한다.
4. 새 대화를 **세 개** 만들고, 각 대화에서 가장 깊은 추론 프리셋을 선택한다.
5. 각 대화에 원고 본문과 페르소나 프롬프트 하나씩을 넣어 실행한다. 한 대화에 두 페르소나를 넣지 않는다.
6. 답이 끝나면 화면 내용을 **그대로** 각 리뷰어 파일(`06_critic/reviewer_R1.md`, `reviewer_R2.md`, `reviewer_R3.md`)로 저장한다.
   🔴 **요약 금지 · 아는 지식으로 보충 금지 — 화면에 있는 것만.** 화면에서 못 읽은 부분은 "여기는 확인 못 함"이라고 표시하고 메워 넣지 않는다.

- 웹 대화 사용량은 Codex 사용량과 별도로 계산되는 것으로 보인다. 구독 안내 화면 기준으로 확인하고 쓴다.
- 권한 거부나 브라우저 조작 실패 시에는 (b)로 내려간다. 여기서 멈추지 않는다.

### (b) Codex 새 스레드 3개: Plus 구독자, 또는 브라우저 경로가 안 될 때

1. Codex에서 **새 스레드 세 개**를 연다. 초안을 쓰던 스레드를 이어 쓰지 않는다.
2. 각 스레드에 원고 파일만 첨부하고 페르소나 프롬프트 하나를 넣어 실행한다.
3. 모델은 가장 상위 모델, 추론 강도는 가장 높음으로 올린다. **끝나면 평소 설정으로 되돌린다.**
4. 결과를 각 리뷰어 파일로 저장한다.

### (c) 폴백: 같은 스레드 순차 (최후)

새 스레드도 열 수 없으면 같은 스레드에서 페르소나 셋을 순차로 발화한다. 이때는 저자에게 한 줄로 알린다. **"같은 스레드에서 돌렸기 때문에 리뷰어들이 초안의 전제를 공유하고, 독립성이 떨어집니다."** 그리고 아래 폴백 절의 External Skeptic 페르소나를 추가한다.

## 페르소나 프롬프트 (Phase 1)

세 프롬프트를 각각 다른 컨텍스트에 하나씩 넣는다. 한 컨텍스트에 두 개를 넣지 않는다.

### R1: 방법론 리뷰어 → `reviewer_R1.md`

```
당신은 이 원고를 처음 보는 외부 심사자입니다. 의학 저널의 방법론 심사자로서
이 원고의 methodology 약점을 top 3 지적하세요. 저자의 의도를 짐작해서 빈칸을
메워주지 말고, 원고에 실제로 쓰여 있는 것만 근거로 판단하세요.

보는 축: 연구 설계의 적절성, 표본과 모집단 정의, 교란 변수 처리, 결측과 탈락,
측정 도구의 타당성, 일반화 가능성, 남이 재현할 수 있는 수준의 방법 기술.

각 지적에 다음을 붙이세요:
- location (section + paragraph)
- issue (구체적)
- severity (Major/Minor)
- suggested_fix
- reward_hacking_risk (RH1-RH4 중 해당 시 표시)

RH1 (한계 나열로 점수 올리기): "limitations" 섹션을 추가만 했는가
RH2 (검증 우회): 결정적 검증 없이 LLM 의견만으로 통과
RH3 (이중 카운트): 같은 이슈를 여러 곳에서 언급해서 점수 분산 회피
RH4 (과장): "first/only/definitive"로 over-claim

(※ RH = reward-hacking. Step 5 verify-reference-essential의 reference 레이어 R1–R6과 별개 명명 — 혼동 금지.)
```

### R2: 통계·논리 리뷰어 → `reviewer_R2.md`

```
당신은 이 원고를 처음 보는 외부 심사자입니다. 의학 저널의 통계·논리 심사자로서
다음을 본문에서 검출하세요. 본문에 근거가 없는 항목은 "본문에서 확인 불가"로
적고, 저자가 당연히 했을 것이라고 가정하지 마세요.

- 통계 보고 형식 (n, %, p, 95% CI 일관성)
- 인과관계 비약 (correlation → causation)
- Effect size 해석 (clinical vs statistical significance)
- 다중비교 보정 누락
- Confounder 미처리
- 초록·본문·표 사이의 수치 불일치

Top 3 issue를 고르고 각각에 location + issue + severity(Major/Minor)
+ suggested_fix + reward_hacking_risk(RH1-RH4 중 해당 시)를 붙이세요.

RH1 (한계 나열로 점수 올리기): "limitations" 섹션을 추가만 했는가
RH2 (검증 우회): 결정적 검증 없이 LLM 의견만으로 통과
RH3 (이중 카운트): 같은 이슈를 여러 곳에서 언급해서 점수 분산 회피
RH4 (과장): "first/only/definitive"로 over-claim
```

### R3: 가혹한 데스크 에디터 → `reviewer_R3.md`

```
당신은 이 원고를 처음 보는 외부 심사자이며, 이 분야에서 가장 가혹한 데스크
에디터입니다. 당신의 기본 판단은 리젝이고, 저자가 그것을 뒤집을 근거를 원고
안에서 제시했는지만 봅니다. 우호적으로 읽어주지 마세요.

먼저 한 줄로 답하세요. 이 원고를 심사자에게 보내지 않고 데스크에서 바로
리젝한다면 그 사유는 무엇입니까. 리젝할 사유가 없다면 "데스크 통과"라고 쓰고
왜 통과인지 한 줄로 쓰세요.

이어서 다음을 판정하세요. journal_shortlist.md가 있으면 그 안의 Scope
fit·Fit verdict·Reject risk를 먼저 읽고 반영하고, Fit verdict가 Risky면
그 사유를 1순위 코멘트로 올리세요.
- 본 저널 scope에 부합하는가?
- Novelty가 독자에게 실제 가치가 있는가, 이미 알려진 것을 다시 말한 것은 아닌가?
- 임상적 함의가 실제 진료를 바꾸는 수준인가?
- Section structure가 ICMJE 및 저널 표준을 준수하는가?
- One-sentence message가 abstract와 일치하는가?

Top 3 strategic comment를 내고 각각에 location + issue + severity(Major/Minor)
+ suggested_fix + reward_hacking_risk(RH1-RH4 중 해당 시)를 붙이세요.
마지막에 accept_likelihood (low/medium/high)와 사유를 쓰세요.
accept_likelihood를 후하게 주지 마세요. 대부분의 원고는 첫 투고에서 low이고,
medium 이상을 줄 때는 그 근거를 원고의 특정 문단에서 인용해 제시하세요.
```

## 교차 벤더 비평 (Phase 2 · 선택)

다른 회사 모델을 하나 붙이면 학습 데이터가 다른 **네 번째 독립 origin**이 되어 Area Chair 입력이 하나 늘어난다. 어느 벤더를 어떻게 연결하는지에 대한 상세는 워크숍 페이지의 병용 트랙 안내에 있다.

```
You are a senior reviewer for a medical journal, seeing this manuscript for the
first time. Read the attached manuscript and identify the top 5 issues that
would matter most to a desk editor and reviewer. For each:
- exact location (section, paragraph)
- issue
- severity (Critical / Major / Minor)
- specific fix
- reward-hacking risk if any

Be terse. No prose. Bullet form.
```

→ 결과 저장 → `paper_home/06_critic/external_critic.md` (legacy `gpt55_critic.md`가 있으면 AC가 함께 읽음)

- 업로드 전 확인: 원고에 환자 식별정보 없음 + (실제 투고 원고면) 외부 업로드에 대한 저널 정책.
- 교차 벤더 출력도 미검증 인용·주장을 담을 수 있으므로 Step 5 검증 원칙이 그대로 적용된다.
- 쓸 수 없으면 건너뛴다. 리뷰어 셋이 서로 독립이면 이 절 없이도 비평은 성립한다.

## Area Chair 통합 (Phase 3)

Area Chair는 리뷰어 파일 세 개와 (있으면) 교차 벤더 비평 파일을 읽어 통합한다. Area Chair는 원고 작성 맥락을 알아도 되지만, 리뷰어의 지적을 저자 편에서 변호하지 않는다.

```
당신은 Area Chair입니다. 다음 입력을 통합하세요:
- 06_critic/reviewer_R1.md
- 06_critic/reviewer_R2.md
- 06_critic/reviewer_R3.md
- 06_critic/external_critic.md (있으면; legacy gpt55_critic.md도 호환)

통합 규칙:
1. 모든 issue를 claim_id 단위로 정리 (location 기반 식별자)
2. 둘 이상이 같이 지적한 것 → Must Fix 후보
3. 한 명만 지적했지만 타당한 것 → Should Fix
4. 한 명만 지적했고 선택적인 것 → Optional
5. 리뷰어끼리 엇갈리는 것 → 저자 판정 항목으로 따로 표에 모으고, 양쪽 논거를
   각각 한 줄로 요약

RH1-RH4 Reward Hacking 체크:
- RH1: limitations만 추가한 척 → reject
- RH2: LLM 의견만으로 통과 → reject
- RH3: 이슈 분산 → reject
- RH4: over-claim → reject

Score-Driven Revert 알림 (scorecard-9d 산출이 **있을 때만**):
- v2 → v3 변경 시 종합 scorecard 비교
- 점수 ↓ → 즉시 revert 권고
- scorecard 산출 없으면 명시적으로 skip — 점수 임의 생성 금지

Output:
- Must Fix 목록 (우선순위 순)
- Should Fix 목록
- Optional 목록
- 저자 판정 항목 (리뷰어 간 불일치)
- Reward hacking으로 reject한 항목 + 사유
```

산출 → `paper_home/06_critic/area_chair_round1.md`

**엇갈리는 지적이 가장 값지다.** 세 리뷰어가 만장일치로 든 항목은 대개 저자도 이미 아는 약점이고, 한 명만 본 것과 서로 반대로 판정한 것이 블라인드 구성으로만 얻는 정보다.

## Phase 4 (Self-Gate C 결정)

본인이:
- [ ] 모든 Must Fix 채택 또는 사유 명시 reject
- [ ] Should Fix 중 시간 허락하는 것 채택
- [ ] 저자 판정 항목 전건 결정 + 사유 기록
- [ ] Reward hacking reject 항목 재검토
- [ ] manuscript.md 즉석 수정

## Output 표준

### `area_chair_round1.md`
```markdown
# Area Chair Round 1

## Must Fix (우선순위 순)
| # | claim_id | location | issue | engine | suggested_fix |
|---|---|---|---|---|---|
| 1 | C-Methods-3 | Methods §3.2 | 교란 변수 미보정 | R1+R2 | 다변량 분석 추가 |
| 2 | ... |

## Should Fix
| ... |

## 저자 판정 항목 (리뷰어 간 불일치)
| # | claim_id | location | issue | 지적한 쪽 논거 | 반대쪽 논거 |
|---|---|---|---|---|---|
| 1 | C-Disc-1 | Discussion §5.1 | 임상 함의 과대 | R3: 진료 변경 근거 부족 | R1: 표본 내에서는 타당 |

## Reward Hacking Rejected
| # | original | reject reason |
|---|---|---|
| 1 | "여러 limitations 추가하여 점수 ↑ 의도" | R1 detected: cosmetic only |

## Score Comparison (v2 → v3 if applicable)
| 차원 | v2 | v3 (예상) |
|---|---|---|
| 방법론적 엄밀성 | 3 | 4 |
```

### `revision_backlog.jsonl` (v1.2 — 표준 포맷 강제)

Area Chair가 채택한 모든 항목 + reward-hacking으로 거부한 항목 모두 한 줄씩 JSONL로 emit. humanise/drift-check가 입력으로 사용하므로 **다음 필드 모두 필수**.

| 필드 | 타입 | 의무 | 설명 |
|---|---|:---:|---|
| `id` | string | ✓ | "AC-01", "AC-02" 형식 순차 |
| `section` | string | ✓ | "§3", "abstract", "references" 등 위치 |
| `severity` | enum | ✓ | "major" / "minor" |
| `accepted` | boolean | ✓ | true=채택, false=reject |
| `action` | string | ✓ | 1문장 명령형 ("Add failure-mode statement per step") |
| `origin` | string | ✓ | 원 리뷰어 식별자 ("R1-02+R3-01" 형식; 교차 벤더는 `EXT-01`) |
| `claim_id` | string | — | claim_bank 참조 시 (있으면) |
| `reward_hacking_reason` | string | — | reject 시 사유 (RH1-RH4 표시 또는 자유 텍스트; legacy 산출의 R1-R4 표기는 읽기 호환) |
| `score_impact` | object | — | `{"dim_2_methods": "+1"}` 형식 (scorecard-9d 연동 시) |

#### 예시

```jsonl
{"id":"AC-01","section":"§2","severity":"major","accepted":true,"action":"Add failure-mode statement per step","origin":"R1-02+R3-01"}
{"id":"AC-08","section":"references","severity":"minor","accepted":true,"action":"Drop duplicate Ref 13; renumber","origin":"R3-04"}
{"id":"AC-XX","section":"§7","severity":"minor","accepted":false,"action":"Inflate limitations list","origin":"R1-rh","reward_hacking_reason":"R1: limitations만 추가하여 점수 ↑ 의도"}
```

#### 검증

`humanize-en/ko`는 `accepted: true`만 입력으로 받음. `accepted: false`는 audit trail로만 보존하며 본인 사후 검토용. 포맷 위반 시 humanise skill이 `revision_backlog_format_invalid` 카테고리로 HITL event emit.

→ **v1.2 NEW**: 본 포맷은 v1.1 reference run에서 비공식 사용된 포맷을 정식화한 것. v1.1 critic 산출은 후방 호환되며, v1.2부터 신규 critic 산출은 본 spec 의무 준수.

## HITL Event Emit

각 critic 의견 채택/거절 시:
```json
{"ts":"...","step":6,"gate":"C_verify_critic","event_type":"critique_decision","skill":"critic-multi-persona","engine":"blind_reviewers_R1R2R3+external","category":"methods_critique","severity":3,"description":"Multivariate adjustment missing","decision":"accepted","backlog_id":"AC-01"}
```

## 결정적 vs LLM 분리

전부 LLM. 단:
- Reward hacking 체크는 **rule-based** (RH1-RH4 정의 기반)
- Score comparison은 **결정적** (수치 비교 — scorecard-9d 산출 있을 때만)

## 폴백: External Skeptic (최종)

새 컨텍스트도 교차 벤더도 쓸 수 없어 같은 대화에서 순차로 돌린 경우에는 네 번째 페르소나 "External Skeptic"을 추가한다.

```
당신은 이 원고와 아무 이해관계가 없는 외부 회의주의자입니다. 가장 의심스러운
주장 3개를 찾아 각각 reject 사유를 제시하세요. R1/R2/R3가 못 본 사각지대를
노리세요.
```

같은 대화 안에서 나온 비평은 독립 origin이 아니다. `revision_backlog.jsonl`의 `origin`에 `-seq`를 붙여 순차 라운드임을 남기고, 저자에게 독립성이 낮은 라운드였다는 사실을 한 줄로 알린다. 엔진 다양성이 줄어 같은 맹점을 공유할 수 있으나, 워크숍 산출은 가능하다.

## Floor (절대 위임 불가)

- 임상 권고에 영향: AC가 채택해도 본인 최종 결정
- IRB / 윤리: AC 의견과 무관하게 본인 검토
- Reward hacking 거부: AC가 reject한 것 중 본인이 valid하다 판단하면 다시 채택 가능 (단 사유 명시)
- 리뷰어 간 불일치: AC가 한쪽을 고르지 않는다. 저자 판정 항목으로 남기고 본인이 결정

## Self-Gate C 체크리스트

- [ ] Must Fix 100% 처리
- [ ] 저자 판정 항목 전건 결정
- [ ] Score-Driven Revert 발동 시 본인 ratify
- [ ] Reward hacking reject 항목 본인 검토
- [ ] manuscript.md 수정 반영

## 자주 발생하는 함정

1. **리뷰어에게 초안 대화를 그대로 넘김** — 블라인드가 깨지는 가장 흔한 경로. 넘기는 것은 원고 파일과 참고 파일뿐이다
2. **AC가 모든 지적을 채택** — 거꾸로 reward hacking. 본인 판단 무 → reject 일부 정당
3. **세 리뷰어 결과가 서로 너무 비슷** — 대화 이력이 섞였거나 원고 외 파일을 넘겼는지 먼저 확인. 순차 폴백 경로였다면 예상된 결과이므로 교차 벤더나 External Skeptic으로 보강
4. **R3가 too positive** — accept_likelihood가 medium 이상인데 데스크 리젝 사유가 비어 있으면 다시 요구한다. 리젝 사유를 한 줄이라도 쓰게 하는 것이 이 페르소나의 존재 이유다
5. **Score 비교 없이 진행** — scorecard-9d 산출이 있으면 v2/v3 비교 필수, 없으면 명시적으로 skip(임의 점수 금지)

## 다음 단계

→ Self-Gate C 통과 → Step 7 Humanize & Package (figure brief는 step 7 옵션)
