"""Education only. Fabricated data. No clinical or therapeutic inference.

Run: python SYNTHETIC_IBS_demo.py
Dependencies: numpy scipy matplotlib
Prespecified demo model: followup ~ intercept + synthetic_group + baseline.
This is a teaching example, not a statistician-approved clinical analysis.
"""
from pathlib import Path
import csv,json,hashlib,sys,platform
import numpy as np
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT=Path(__file__).resolve().parent
SEED=20261128
rng=np.random.default_rng(SEED)
n=120
group=np.repeat([0,1],n//2);rng.shuffle(group)
baseline=np.clip(rng.normal(280,65,n),100,450).round(1)
followup=np.clip(40+0.72*baseline-12*group+rng.normal(0,48,n),0,500).round(1)
csvpath=OUT/'SYNTHETIC_IBS.csv'
with csvpath.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['synthetic_id','synthetic_group','baseline_ibs_sss','week4_ibs_sss'])
 w.writerows(zip(range(1,n+1),group,baseline,followup))
X=np.column_stack([np.ones(n),group,baseline])
beta=np.linalg.lstsq(X,followup,rcond=None)[0]
resid=followup-X@beta;df=n-X.shape[1]
variance=float(resid@resid/df);cov=variance*np.linalg.inv(X.T@X);se=np.sqrt(np.diag(cov))
tcrit=stats.t.ppf(.975,df);ci=[float(beta[1]-tcrit*se[1]),float(beta[1]+tcrit*se[1])]
pval=float(2*stats.t.sf(abs(beta[1]/se[1]),df))
# Separate algebraic calculation checks numerical execution, not model validity.
beta_check=np.linalg.solve(X.T@X,X.T@followup)
assert np.allclose(beta,beta_check,rtol=1e-10,atol=1e-10)
assert np.isfinite(X).all() and np.isfinite(followup).all()
groups=[]
for g in [0,1]:
 m=group==g
 groups.append({'group':g,'n':int(m.sum()),'baseline_mean':float(baseline[m].mean()),'baseline_sd':float(baseline[m].std(ddof=1)),'week4_mean':float(followup[m].mean()),'week4_sd':float(followup[m].std(ddof=1))})
with (OUT/'SYNTHETIC_table.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=list(groups[0]));w.writeheader();w.writerows(groups)
with (OUT/'SYNTHETIC_model.csv').open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.writer(f);w.writerow(['term','coefficient','standard_error','ci95_lower','ci95_upper','p_value'])
 for j,term in enumerate(['Intercept','Group B vs A','Baseline IBS-SSS']):
  w.writerow([term,float(beta[j]),float(se[j]),float(beta[j]-tcrit*se[j]),float(beta[j]+tcrit*se[j]),float(2*stats.t.sf(abs(beta[j]/se[j]),df))])
result={'label':'SYNTHETIC — teaching example only','seed':SEED,'n':n,'generation':{'group_names':{'0':'A','1':'B'},'formula_before_clipping':'40 + 0.72 * baseline - 12 * group + Normal(0,48)','group_coefficient_before_clipping':-12,'baseline_normal_mean':280,'baseline_normal_sd':65,'baseline_clip':[100,450],'followup_clip':[0,500]},'model':'week4 = intercept + synthetic_group(1 vs 0) + baseline','group_coefficient':float(beta[1]),'ci95':ci,'p_value':pval,'groups':groups,'checks':{'direct_identifier':'none','missing_values':0,'score_range':[0,500],'independent_algebra_difference':float(np.max(np.abs(beta-beta_check)))},'limitations':['No patient data','No treatment effect inference','n=120 is a teaching choice, not a sample-size calculation','Rerun agreement does not validate study design or model assumptions']}
(OUT/'SYNTHETIC_results.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(9,5.0625),layout='constrained')
colors=['#235A9F','#25888C']
for g in [0,1]:
 m=group==g
 ax.scatter(baseline[m],followup[m],s=22,alpha=.66,color=colors[g],label=f'Synthetic group {g} (n={m.sum()})')
 xx=np.array([100,450]);ax.plot(xx,beta[0]+beta[1]*g+beta[2]*xx,color=colors[g],lw=2)
ax.set(xlabel='Baseline IBS-SSS (points)',ylabel='Week 4 IBS-SSS (points)',xlim=(75,475),ylim=(0,500),title='SYNTHETIC DATA · Teaching example only')
ax.legend(frameon=False,loc='upper left');ax.grid(alpha=.12)
fig.savefig(OUT/'SYNTHETIC_figure.png',dpi=200);fig.savefig(OUT/'SYNTHETIC_figure.svg');plt.close(fig)
fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
axes[0].scatter(X@beta,resid,s=18,alpha=.65,color=colors[0]);axes[0].axhline(0,color='#566477',lw=1)
axes[0].set(xlabel='Fitted value',ylabel='Residual',title='Residuals vs fitted')
stats.probplot(resid,dist='norm',plot=axes[1]);axes[1].set_title('Residual normal Q-Q')
fig.suptitle('SYNTHETIC DATA — diagnostics for inspection, not a validity certificate')
fig.savefig(OUT/'SYNTHETIC_diagnostics.png',dpi=160);plt.close(fig)
manifest={'data_sha256':hashlib.sha256(csvpath.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'python':platform.python_version(),'numpy':np.__version__,'scipy':__import__('scipy').__version__,'matplotlib':matplotlib.__version__,'seed':SEED}
(OUT/'SYNTHETIC_run_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
print(json.dumps({'n':n,'group_coefficient':round(float(beta[1]),3),'ci95':[round(v,3) for v in ci],'p_value':round(pval,4),'validation':'two algebraic calculations agree; not clinical validation'},ensure_ascii=False))
